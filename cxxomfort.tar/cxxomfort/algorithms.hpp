#ifndef CXXOMFORT_ALGORITHMS_HPP
#define CXXOMFORT_ALGORITHMS_HPP
#include "algorithm.hpp"
#endif
