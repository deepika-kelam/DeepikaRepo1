#ifndef CXXOMFORT_EXTRAS_LOCALFN_HPP
#define CXXOMFORT_EXTRAS_LOCALFN_HPP
/*
 * Implementación de funciones "locales" para usar
 * junto con algoritmos STL y similares.
 *
 * Funciona por medio de tres macros:
 * LOCAL_FUNCTION y LOCAL_FUNCTION_WITH_TYPE crean una función local,
 * y LOCAL_FUNCTION_NAME le da el nombre a la variable.
 *
 * Modo de uso:
vector<int> Lista;
CXXO_LOCALFN( bool(int) ) (int x0) {
    // do something and return a bool
} CXXO_LOCALFN_NAME (mi_fn);
find_if (begin(Lista), end(Lista), mi_fn);

Salida es equivalente al siguiente código:

vector<int> Lista;
struct implementation_defined : public ::cxxomfort::extras::fn_wrapper< bool(int) >::o_iface {
    typename (...)::o_iface::result_type operator () (int x0) {
    // do something and return a bool
    }
} LF_mi_fnXob; 
implementation_defined::base_type mi_fn (LF_mi_fnXob);
find_if (begin(Lista), end(Lista), mi_fn);


 * Dependencias:
 * * tipos de función como argumentos de plantilla
 *
 */
#include <cxxomfort/config.hpp>

#if (CXXOMFORT_CXX_STD < 2011)
    #define CXXOMFORT_USING_LOCALFN
#elif (CXXO_COMPILER_SUPPORT_local_types==0)
    #define CXXOMFORT_USING_LOCALFN
#else // using C++11 mode
#endif

//
// #defines for localfn construction
//

#define LF_JOIN_IMPL2(a,b) a##b
#define LF_JOIN_IMPL(a,b) LF_JOIN_IMPL2(a,b)
#define LF_JOIN(a,b) LF_JOIN_IMPL(a,b)

#define LF_EXP(...) __VA_ARGS__
#define LF_ARG1_(X,...) X
#define LF_ARG2_(X,Y,...) LF_EXP(LF_ARG1_(Y,LF_EXP(__VA_ARGS__)))
#define CXXO_LF_MEMBER(n) n ; 
#define CXXO_LF_CTORARGS(n) n ,
#define LF_INIT(n) n(n) ,

#define CONCATENATE(arg1, arg2)   CONCATENATE1(arg1, arg2)
#define CONCATENATE1(arg1, arg2)  CONCATENATE2(arg1, arg2)
#define CONCATENATE2(arg1, arg2)  arg1##arg2

#define FOR_EACH_0(what, x, ...) 
#define FOR_EACH_1(what, x, ...) what(x)
#define FOR_EACH_2(what, x, ...)\
  what(x)\
  LF_EXP(FOR_EACH_1(what,  __VA_ARGS__))
#define FOR_EACH_3(what, x, ...)\
  what(x)\
  LF_EXP(FOR_EACH_2(what, __VA_ARGS__))
#define FOR_EACH_4(what, x, ...)\
  what(x)\
  LF_EXP(FOR_EACH_3(what,  __VA_ARGS__))
#define FOR_EACH_5(what, x, ...)\
  what(x)\
 LF_EXP(FOR_EACH_4(what,  __VA_ARGS__))
#define FOR_EACH_6(what, x, ...)\
  what(x)\
  LF_EXP(FOR_EACH_5(what,  __VA_ARGS__))
#define FOR_EACH_7(what, x, ...)\
  what(x)\
  LF_EXP(FOR_EACH_6(what,  __VA_ARGS__))
#define FOR_EACH_8(what, x, ...)\
  what(x)\
  LF_EXP(FOR_EACH_7(what,  __VA_ARGS__))

#define FOR_EACH_NARG(...) FOR_EACH_NARG_(__VA_ARGS__, FOR_EACH_RSEQ_N())
#define FOR_EACH_NARG_(...) LF_EXP(FOR_EACH_ARG_N(__VA_ARGS__)) 
#define FOR_EACH_ARG_N(_1, _2, _3, _4, _5, _6, _7, _8, N, ...) N 
#define FOR_EACH_RSEQ_N() 8, 7, 6, 5, 4, 3, 2, 1, 0

#define FOR_EACH_(N, what, x, ...) CONCATENATE(FOR_EACH_, N)(what, x, __VA_ARGS__)
#define FOR_EACH(what, x, ...) FOR_EACH_(FOR_EACH_NARG(x, __VA_ARGS__), what, x, __VA_ARGS__)



#if defined CXXOMFORT_USING_LOCALFN
#if defined (CXXOMFORT_NOTICES)
    #if (CXXOMFORT_NOTICES > 1)
    #pragma message CXXO_NOTICE("enabled local functor helpers" )
    #endif
#endif



namespace cxxomfort {
namespace extras {

/*
 * Virtual Function Method
 */

struct localfn_base {};
struct no_type {};

template <typename T>
struct fn_wrapper ;


template <typename R>
struct fn_wrapper<R()> : public localfn_base {
    public:
    typedef R result_type;
    struct o_iface {
        typedef R return_type;
        typedef R result_type;
        //virtual ~o_iface() {} // only needed to suppress -Weffc++ warning
        inline virtual R operator() () { return R(); };
        fn_wrapper base () const;
        typedef fn_wrapper base_type;
    };
    explicit fn_wrapper (o_iface& fn) : func_(&fn) {}
    inline R operator () () const { return (*func_)(); }
    private:
    o_iface* func_;

};

template <typename R, typename T>
struct fn_wrapper<R(T)> : public localfn_base {
    public:
    typedef R result_type;
    struct o_iface {
        typedef R return_type;
        typedef R result_type;
        typedef T arg1_type;
        //virtual ~o_iface() {} // only needed to suppress -Weffc++ warning
        inline virtual R operator() (T) {return R(); };
        fn_wrapper base () const;
        typedef fn_wrapper base_type;
    };
    explicit fn_wrapper (o_iface& fn) : func_(&fn) {}
    inline R operator() (T t) const { return (*func_)(t); }
    private:
    o_iface* func_;
};

template <typename R, typename T1, typename T2>
struct fn_wrapper<R(T1,T2)> : public localfn_base {
    public:
    typedef R result_type;
    struct o_iface {
        typedef R result_type;
        typedef T1 arg1_type;
        typedef T2 arg2_type;
        typedef fn_wrapper base_type;
        //virtual ~o_iface() {} // only needed to suppress -Weffc++ warning
        inline virtual R operator() (T1,T2) { return R(); };
        fn_wrapper base () const;
    };
    explicit fn_wrapper (o_iface& fn) : func_(&fn) {}
    inline R operator() (T1 t1, T2 t2) { return (*func_)(t1,t2); }
    private:
    o_iface* func_;
};

template <typename R, typename T1, typename T2, typename T3>
struct fn_wrapper<R(T1,T2,T3)> : public localfn_base {
    public:
    typedef R result_type;
    struct o_iface {
        typedef R result_type;
        typedef T1 arg1_type;
        typedef T2 arg2_type;
        typedef T3 arg3_type;
        //virtual ~o_iface() {} // only needed to suppress -Weffc++ warning
        inline virtual R operator() (T1,T2,T3) {return R(); };
        fn_wrapper base () const;
    };
    explicit fn_wrapper (o_iface& fn) : func_(&fn) {}
    inline R operator() (T1 t1, T2 t2, T3 t3) const { return (*func_)(t1,t2,t3); }
    private:
    o_iface* func_;
};

template <typename R, typename T1, typename T2, typename T3, typename T4>
struct fn_wrapper<R(T1,T2,T3,T4)> : public localfn_base {
    public:
    typedef R result_type;
    struct o_iface {
        typedef R result_type;
        typedef T1 arg1_type;
        typedef T2 arg2_type;
        typedef T3 arg3_type;
        typedef T4 arg4_type;
        //virtual ~o_iface() {} // only needed to suppress -Weffc++ warning
        inline virtual R operator() (T1,T2,T3,T4) {return R(); };
        fn_wrapper base () const;
    };
    explicit fn_wrapper (o_iface& fn) : func_(&fn) {}
    inline R operator() (T1 t1, T2 t2, T3 t3, T4 t4) const { return (*func_)(t1,t2,t3,t4); }
    private:
    o_iface* func_;
};

template <typename R, typename T1, typename T2, typename T3, typename T4, typename T5>
struct fn_wrapper<R(T1,T2,T3,T4,T5)> : public localfn_base {
    public:
    typedef R result_type;
    struct o_iface {
        typedef R result_type;
        typedef T1 arg1_type;
        typedef T2 arg2_type;
        typedef T3 arg3_type;
        typedef T4 arg4_type;
        typedef T5 arg5_type;
        //virtual ~o_iface() {} // only needed to suppress -Weffc++ warning
        inline virtual R operator() (T1,T2,T3,T4,T5) {return R(); };
        fn_wrapper base () const;
    };
    explicit fn_wrapper (o_iface& fn) : func_(&fn) {}
    inline R operator() (T1 t1, T2 t2, T3 t3, T4 t4, T5 t5) const { return (*func_)(t1,t2,t3,t4,t5); }
    private:
    o_iface* func_;
};

//
// C++03 local function, stateless, type can be "anonymous"
// this can not be used in MSVC, even with typeof hack
//

#define CXXO_LOCALFN0(localsig) \
struct : public ::cxxomfort::extras::fn_wrapper< localsig >::o_iface { \
  typedef ::cxxomfort::extras::fn_wrapper< localsig > fn_type;        \
  fn_type::result_type operator ()
// la firma de la funcion debe ser completada, causa 1 repetición

#define CXXO_LOCALFN0_NAME(VDecl) \
} LF_##VDecl##Xob; \
typedef CXXO_DECLTYPE(LF_##VDecl##Xob) VDecl##_t;  \
/*::cxxomfort::extras::fn_wrapper< localsig >*/ VDecl##_t::base_type VDecl (LF_##VDecl##Xob)

//
// C++03 local function, can have state, needs to have a type nam,
// can have bound arguments (but the binding needs to be coded explicitly)
// (this is the "normal" implementation of localfn)
//
#if defined(_MSC_VER)
#pragma warning( push )
#pragma warning( disable:4003 ) // insufficient args to macro
#endif

#define CXXO_LOCALFN_BIND(...) LF_EXP(FOR_EACH(LF_INIT,__VA_ARGS__)) _reserved(0) {}

#define CXXO_LOCALFN_(x,localsig,...) \
struct x : public ::cxxomfort::extras::fn_wrapper< localsig >::o_iface {   \
 FOR_EACH(CXXO_LF_MEMBER/*LF_BINDER*/,__VA_ARGS__)                              \
 void* _reserved;  \
 typedef ::cxxomfort::extras::fn_wrapper< localsig > fn_type;              \
 fn_type::result_type operator ()
// la firma de la funcion debe ser completada, causa 1 repetición

#define CXXO_LOCALFN(x,localsig,...) LF_EXP(CXXO_LOCALFN_(x,localsig,__VA_ARGS__))

// gives an argument list to initialize the function object
#define CXXO_LOCALFN_INIT(x,VDecl,...) \
} LF_##x##Xob __VA_ARGS__ 

#define CXXO_LOCALFN_NAME(x,VDecl) } \
x::base_type  VDecl (LF_##x##Xob)

#define CXXO_LOCALFN_NAME_DEF(x,VDecl,...) } \
LF_##x##Xob __VA_ARGS__ ; \
x::base_type VDecl (LF_##x##Xob)


#if defined(_MSC_VER)
#pragma warning( pop ) // insufficient args to macro
#endif

} //~extras
}


#else 
//
// CXX11 localfn: this is just an anonymous struct
//

// <functional> and <type_traits> must be included for this to work:

#define CXXO_LOCALFN_BIND(...) LF_EXP(FOR_EACH(LF_INIT,__VA_ARGS__)) _reserved(0) {}

#define CXXO_LOCALFN(xtag,localsig,...) struct xtag { \
    typedef std::function< localsig >::result_type R;  \
    FOR_EACH(CXXO_LF_MEMBER/*LF_BINDER*/,__VA_ARGS__)                              \
    void* _reserved; \
    inline R operator()

#define CXXO_LOCALFN_INIT(x,VDecl,...) \
} VDecl __VA_ARGS__ 

#define CXXO_LOCALFN_NAME(xtag,VDecl) } /* struct */ VDecl 

#define CXXO_LOCALFN_NAME_EXT(xtag,VDecl,...)  \
} VDecl __VA_ARGS__ 

#define CXXO_LOCALFN0(localsig) \
struct {                                            \
    typedef std::function< localsig >::result_type R;       \
    inline R operator()

#define CXXO_LOCALFN0_NAME(VDecl)                         \
} /* struct*/ VDecl

#define CXXO_LOCALFN_NAME_DEF(x,VDecl,...) \
} VDecl __VA_ARGS__ ; \



#endif // (CXX11)

//
// Undef the macros unneeded
//

//#undef CONCATENATE
//#undef CONCATENATE1
//#undef CONCATENATE2

#undef LF_JOIN_IMPL2
#undef LF_JOIN_IMPL
#undef LF_JOIN


#endif // CXXOMFORT_EXTRAS_LOCALFN_HPP
