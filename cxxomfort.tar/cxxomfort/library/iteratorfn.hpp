#ifndef CXXOMFORT_CXXO_ITERATORFN_HPP
#define CXXOMFORT_CXXO_ITERATORFN_HPP
#include <cxxomfort/config.hpp>
#include <cxxomfort/base.hpp>
#include <iterator>
#include <functional>
//#include <type_traits>

namespace cxxomfort {


/**
 * constant_iterator
 * iterates over nothing, it just stays "pointing" to the same place
 */
template <typename T>
struct constant_iterator {
    typedef std::reference_wrapper<T const> V;
    typedef std::bidirectional_iterator_tag iterator_category;
    typedef T value_type;
    typedef size_t difference_type;
    typedef T* pointer;
    typedef T& reference;
    
    // "end" state
    constant_iterator () CXXO_NOEXCEPT : v(), b(false) {}
    explicit constant_iterator (T const& t): v(t), b(true) {}
    T const& operator* () const {
        return v.get();
    }
    
    constant_iterator& operator++() { return *this; }
    constant_iterator operator++(int) { return *this; }

    constant_iterator& operator--() { return *this; }
    constant_iterator operator--(int) { return *this; }

    friend bool operator== (constant_iterator const& c1, constant_iterator const& c2) CXXO_NOEXCEPT {
        return (c1.b==c2.b==false) or (c1.b==c2.b==true and c1.v==c2.v);
    }

    friend bool operator!= (constant_iterator const& c1, constant_iterator const& c2) CXXO_NOEXCEPT {
        return !(c1==c2);
    }

    private:
    V const v;
    bool b;
};


/**
 * recursive_iterator<T,N> 
 * iterator that dereferences N times before dereferencing to its value
 * (N == 0 -> normal pointer dereference, N == 1 -> one dereference before pointer dereference, etc)
 */

template <typename T, unsigned N>
struct recursive_iterator {
    
};

template <typename T> struct recursive_iterator<T,0> {
    T iterator;
};


template <typename I, typename F>
struct function_iterator {
};


}

#endif
