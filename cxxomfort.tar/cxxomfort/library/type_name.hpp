#ifndef CXXOMFORT_TYPE_NAME_HPP
#define CXXOMFORT_TYPE_NAME_HPP
#include <cxxomfort/base.hpp>

/**
 * @file library/type_name.hpp
 * @brief Type naming and identification utilities in cxxomfort.
 * @ingroup independent-utilities
 */

#include <typeinfo>
#include <type_traits> // remove_reference, etc
#include "../util/type_traits.hpp"
#include <string>
#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC || CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_CLANG)
    #include <cxxabi.h>
#endif

namespace cxxomfort {
namespace detail_demangle {

// Thanks much to ′灵魂L.眼神 for making me notice this had to be made static!
static std::string job (const char* name) {
#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC || \
     CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_CLANG)
    char buf[1024];
    size_t size=sizeof(buf);
    int status;
    char* res = abi::__cxa_demangle (name,
                                 buf,
                                 &size,
                                 &status);
    buf[sizeof(buf) - 1] = 0;
    return std::string(res);
#else
    return (name);
#endif
}


} //detail_demangle::

#if defined _MSC_VER
#pragma warning (push)
#pragma warning (disable: 4505) // 'cxxomfort::typeid_demangle' : unreferenced local function has been removed
#endif

//! Demangle a @c typeid() expression if demangling is available
//! @ingroup independent-features
static std::string typeid_demangle (std::type_info const& ti) {
    return detail_demangle::job( ti.name() );
}

#if defined _MSC_VER
#pragma warning (pop)
#endif


//! Demangle a typename, recovering information about const / volatile too.
//! @ingroup independent-features
template <typename T>
std::string type_name () {
    using namespace std;
    typedef typename remove_reference<T>::type TnR;
    std::string r( typeid_demangle(typeid(T)) );
    if (is_const<TnR>::value) { r+= " const"; }
    if (is_volatile<TnR>::value) { r+= " volatile"; }
    if (is_lvalue_reference<T>::value) { r+= "&"; }
    if (is_rvalue_reference<T>::value) { r+= "&&"; }
    return r;
}

} //cxxomfort::


#endif
