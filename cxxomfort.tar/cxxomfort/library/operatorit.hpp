#ifndef CXXOMFORT_CXXO_OPERATORIT_HPP
#define CXXOMFORT_CXXO_OPERATORIT_HPP

/**
 * @file library/operatorit.hpp
 * @brief Implementations and additions of ${operator}_it functoids similar to <functional>.
 * @addtogroup independent-features
 * 
 * Interfaces defined in this file:
 *
 * * preincrement, predecrement
 * * plus_it, minus_it, multiplies_it, divides_it, modulus_it.
 * * leftshift_it, rightshift_it.
 * * comma_it.
 * * 
 *
 */

#include <cxxomfort/cxxomfort.hpp>
#include CXXO_INCLUDE_SYS(functional)

namespace cxxomfort {
namespace functional {

template <typename T>
struct preincrement
:std::unary_function<T,T> {
    typedef T argument_type;
    typedef T result_type;
    T& operator() (T& t) const { ++t; return t; }
};

template<> struct preincrement<void> {
    template <typename T>
    T& operator() (T& t) const { ++t; return t; }
};

template <typename T>
struct predecrement
:std::unary_function<T,T> {
    typedef T argument_type;
    typedef T result_type;
    T& operator() (T& t) const { --t; return t; }
};

template<> struct predecrement<void> {
    template <typename T>
    T& operator() (T& t) { --t; return t; }

};


#define CXXO_DEF_OPERATORIT(Name,Sym) \
template <typename It, typename Ot=It> \
struct Name : plus<int> {              \
    typedef It result_type;            \
    inline It& operator() (It& l, Ot const& r) const {   \
        return l Sym r;       \
    }                         \
};                            \


/**
 * @ingroup independent-features
 * @{
 */

CXXO_DEF_OPERATORIT(plus_it,+=);
CXXO_DEF_OPERATORIT(minus_it,-=);
CXXO_DEF_OPERATORIT(multiplies_it,*=);
CXXO_DEF_OPERATORIT(divides_it,/=);
CXXO_DEF_OPERATORIT(modulus_it,%=);
CXXO_DEF_OPERATORIT(leftshift_it,<<=);
CXXO_DEF_OPERATORIT(rightshift_it,>>=);
/**
 * @}
 */

#undef CXXO_DEF_OPERATORIT

}
} // cxxomfort

#endif

