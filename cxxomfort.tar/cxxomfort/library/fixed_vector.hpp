#ifndef CXXOMFORT_IMPL_FIXED_VECTOR_HPP
#define CXXOMFORT_IMPL_FIXED_VECTOR_HPP
/**
 * @file fixed_vector.hpp
 * @brief Implementation of a fixed-size variant of vector<>.
 * @author Luis Machuca Bezzaza
 * @sa dynarray
 *
 */


#include <cxxomfort/base.hpp>
#include <cxxomfort/sequences.hpp> // is_iterator
#include <iterator>
#include <algorithm>
#include <stdexcept>
#include <memory>


namespace cxxomfort{

template <typename T, typename Alloc> class fixed_vector;

/**
 * @brief Dynamic array (aka fixed vector) container for C++.
 * @anchor fixed_vector
 * @ingroup independent-features
 *
 * A @c fixed_vector is a container of contiguous storage of elements
 * of type @e T.
 * It behaves much like a <code>vector<T></code> except there is no resize or
 * reserve support - the size of the container is fixed at construction time.
 *
 * Part of the spirit of this kind of "missing" container is what originated
 * n2648's "dynarray". However that proposal goes far beyond the mere
 * concept of a "fixed vector".
 *
 * An instance of fixed_vector<T> stores elements of type T.
 * The elements of a fixed_vector are stored contiguously, meaning that if d
 * is an fixed_vector<T> then it obeys the identity
 * &a[n] == &a[0] + n for all 0 <= n < N."
 *
 * A @c fixed_vector  presents the some of the same interface convenients as
 * other standard containers:
 *
 * * except where specified, no members throw
 * * copy constructor and iterator constructor
 * * indexed accesors (@c at() and @c operator[] ) with usual semantics
 * * iteration member accesors and types
 * * nonmember equality comparison operators
 * 
 * The following features are missing at present:
 * 
 * * Allocator support.
 * 
 *
 */
template <typename T, typename Alloc=std::allocator<T> > class fixed_vector {
    typedef fixed_vector<T>  this_type;
    private:
    typedef Alloc        alloc_t;
    typedef std::allocator_traits<Alloc>     alloc_traits;
    typedef typename alloc_t::pointer        storage_pt;


    public:
    typedef T            value_type;         ///< type of contained value
    typedef size_t       size_type;
    typedef ptrdiff_t    difference_type;
    typedef value_type&       reference;
    typedef value_type const& const_reference;
    typedef value_type*       pointer;
    typedef const value_type* const_pointer;
    // see if those should be changed to checked iterators?
    typedef T*           iterator;           ///< @c iterator type
    typedef T const*     const_iterator;     ///< @c const_iterator type
    typedef std::reverse_iterator<iterator> reverse_iterator;
    typedef std::reverse_iterator<const_iterator> const_reverse_iterator;

    public:

    fixed_vector (); ///< default-constructor
    explicit fixed_vector (size_type N);     ///< (1) count-constructor
    fixed_vector (size_type N, T const& v);  ///< (3) count-constructor
    fixed_vector (fixed_vector const &V);        ///< (5) copy-constructor
    //! iterator-constructor
    template <typename It>
    fixed_vector (It ini, It fin, typename std::enable_if<is_iterator<It>::value,bool>::type* = nullptr);

#if (CXXOMFORT_CXX_STD >= 2011) || defined(DOXYGEN_DOC)
    fixed_vector (std::initializer_list<T> const&) CXXO_NOEXCEPT;             ///< (7) initializer_list-ctor
#endif

    fixed_vector (CXXO_RV_REF(fixed_vector) p) CXXO_NOEXCEPT;  ///< move-constructor

    ~fixed_vector ();                                 ///< destructor

    fixed_vector& operator= (fixed_vector rhs);
    
    size_type       max_size () const CXXO_NOEXCEPT { return m_sz; }
    size_type       size () const CXXO_NOEXCEPT { return m_sz; } ///< size of container
    bool            empty () const CXXO_NOEXCEPT { return m_p == nullptr && m_sz == 0; } // nothrow

    //! access of storage buffer
    const T*        data () const CXXO_NOEXCEPT { return m_p; } // nothrow
    T*              data () CXXO_NOEXCEPT { return m_p; } // nothrow

    //! checked access to element at index @em idx
    const_reference at (size_t idx) const {
        if (m_sz <= idx) throw std::out_of_range("fixed_vector at(size_t) const");
        return m_p[idx];
    }
    //! @overloads at
    reference at (size_t idx) {
        if (m_sz <= idx) throw std::out_of_range("fixed_vector at(size_t)");
        return m_p[idx];
    }

    //! direct access to element at index @em idx
    const_reference operator[] (size_t idx) const CXXO_NOEXCEPT { // nothrow
        return m_p[idx];
    }
    //! @overloads operator[]
    reference operator[] (size_t idx) CXXO_NOEXCEPT { // nothrow
        return m_p[idx];
    }

    const_reference front () const CXXO_NOEXCEPT { return m_p[0]; } // nothrow
    reference       front () CXXO_NOEXCEPT { return m_p[0]; } // nothrow
    const_reference back  () const CXXO_NOEXCEPT { return m_p[m_sz-1]; } // nothrow
    reference       back  () CXXO_NOEXCEPT{ return m_p[m_sz-1]; } // nothrow

    //@ Iterator to the beginning
    const_iterator  cbegin () const CXXO_NOEXCEPT { return m_p; } // nothrow
    //@ Iterator to the beginning
    const_iterator  begin  () const CXXO_NOEXCEPT { return cbegin(); } // nothrow
    //@ @overloads begin
    iterator        begin  () CXXO_NOEXCEPT { return m_p; } // nothrow
    const_iterator  cend   () const CXXO_NOEXCEPT { return m_p+m_sz; } // nothrow
    //@ Iterador apuntando al final+1.
    const_iterator  end    () const CXXO_NOEXCEPT { return cend(); } // nothrow
    //* @overloads end
    iterator        end    () CXXO_NOEXCEPT { return m_p+m_sz; } // nothrow

    const_reverse_iterator    rbegin () const CXXO_NOEXCEPT {
        return const_reverse_iterator(this->end());
    }
    reverse_iterator     rbegin () CXXO_NOEXCEPT {
        return reverse_iterator(this->end());
    }
    const_reverse_iterator     rend () const CXXO_NOEXCEPT {
        return const_reverse_iterator(this->begin());
    }
    reverse_iterator     rend () CXXO_NOEXCEPT {
        return reverse_iterator(this->begin());
    }

    //! fill with copies of value @em v
    void fill (T const& v) {
        for (iterator i= this->begin(); i != this->end(); ++i) {*i= v;}
    }

    //! swap
    void swap (fixed_vector<T,Alloc> & rhs) {
        std::swap(this->m_p, rhs.m_p);
        std::swap(this->m_sz, rhs.m_sz);
        //std::swap(this->m_a, rhs.m_a);
    }

    //! assign copy of another vector
    fixed_vector& assign (fixed_vector rhs) CXXO_NOEXCEPT {
        this->swap(rhs);
        return *this;
    }

    private:
    size_t m_sz;
    T* m_p;
    //Alloc m_a;

    T* alloc (size_type n) {
        return reinterpret_cast<T*>( new char [n * sizeof(T)] );
    }
    
    void release (size_type n) {
    }

};

//
// default constructor
//
template <typename T, typename Alloc>
fixed_vector<T,Alloc>::fixed_vector ()
: m_p ( nullptr ), m_sz(0) {
}

//
// copy constructor
//
template <typename T, typename Alloc>
fixed_vector<T,Alloc>::fixed_vector (fixed_vector const &V) // strong_throw
: m_p ( alloc(V.m_sz) ), m_sz(V.m_sz) {
    size_t i;
    try {
        using namespace std;
        uninitialized_copy(V.begin(), V.end(), this->begin());
    } catch(...) {

        delete[] m_p; m_p= nullptr;
        throw; // rethrow
    }// ~catch
}


// Constructor cantidad (N)
template <typename T, typename Alloc>
fixed_vector<T,Alloc>::fixed_vector (size_type N) // strong_throw
: m_sz(N), m_p ( alloc(N) ) {
    //size_t i;
    try {
        using namespace std;
        uninitialized_fill(m_p, m_p+m_sz, T());
    } catch(...) {
        delete[] m_p; m_p= nullptr;
        throw; // rethrow
    }//~catch
}

template <typename T, typename Alloc>
fixed_vector<T,Alloc>::fixed_vector (size_type N, T const& v) // strong_throw
: m_sz(N), m_p ( alloc(N) ) {
    using namespace std;
    size_t i= 0;
    try {
        uninitialized_fill(m_p, m_p+m_sz, v);
    } catch(...) {
        delete[] m_p; m_p= nullptr;
        throw; // rethrow
    }//~catch
}


template <typename T, typename Alloc>
template <typename It>
fixed_vector<T,Alloc>::fixed_vector (It ini, It fin, typename std::enable_if<is_iterator<It>::value,bool>::type*)
:  m_sz ( std::distance(ini, fin) ), m_p (alloc(m_sz)) {
    using namespace std;
    try {
        //m_p= alloc(m_sz);
        uninitialized_copy(ini, fin, m_p);
    } catch (...) {
        delete[] m_p; m_p= nullptr;
        throw; // rethrow
    }
}

#if (CXXOMFORT_CXX_STD >= 2011)
// This assumes none of the involved constructors will throw!
template <typename T, typename Alloc>
fixed_vector<T,Alloc>::fixed_vector (std::initializer_list<T> const& L) // shouldnt_throw
: m_p ( alloc(std::distance(L.begin(),L.end())) ), m_sz( std::distance(L.begin(),L.end()) ) {
    std::uninitialized_copy(L.begin(), L.end(), m_p);
}
#endif

// Move constructor
template <typename T, typename Alloc>
fixed_vector<T,Alloc>::fixed_vector (CXXO_RV_REF( fixed_vector ) p)  CXXO_NOEXCEPT // shouldnt_throw
: m_p(p.m_p), m_sz(p.m_sz) {
    p.m_p= nullptr;
    p.m_sz= 0;
}


// Destructor
template <typename T, typename Alloc>
fixed_vector<T,Alloc>::~fixed_vector () {
    if (m_p==nullptr && m_sz==0)  return; // empty, nothing to do
    using namespace std;
    typedef typename conditional < std::is_const<T>::value ,
        char const*,
        char*>
    ::type buffertype;
    for (size_t i=0; i < m_sz; ++i) {
        (m_p+i)->~T();
    }
    delete[] reinterpret_cast<buffertype>(m_p);
    m_p= nullptr;
}

template <typename T, typename Alloc>
fixed_vector<T,Alloc>& fixed_vector<T,Alloc>::operator= (fixed_vector<T,Alloc> rhs) {
    return this->assign(rhs);
}

template <typename T, typename Alloc>
inline bool operator== (fixed_vector<T,Alloc> const& a, fixed_vector<T,Alloc> const& b) {
    return ( a.size() == b.size() ) && std::equal(a.begin(), a.end(), b.begin()) ;
}

template <typename T, typename Alloc>
inline bool operator!= (fixed_vector<T,Alloc> const& a, fixed_vector<T,Alloc> const& b) {
    return !(a==b);
}

}//~cxxomfort

#endif
