#ifndef CXXOMFORT_IMPL_I12N_HPP
#define CXXOMFORT_IMPL_I12N_HPP
#include <cxxomfort/config.hpp>
/**
 * @file cxxomfort/impl/i12n.hpp
 * @brief Implements <code>= {...}</code>-like initialization semantics for containers.
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 * @ingroup independent-features
 * 
 * Defines the dual macros @c CXXO_I12N_BEG and @c CXXO_I12N_END 
 * that provide initialization semantics for containers similar to the 
 * initializer_list constructors in C++11.
 * 
 * For documentation see @link Features/I12N @endlink .
**/

#if (CXXOMFORT_CXX_STD < 2011)

    #if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
    #pragma message CXXO_NOTICE ("enabled container initialization helper")
    #endif

#include <iterator>
#include <valarray>

namespace cxxomfort {

namespace i12n_detail {

template <typename Container> struct I12N_for {
    typename Container::value_type const* starter;
    typename Container::value_type const* ender;
    template <size_t N>
    explicit I12N_for (typename Container::value_type const (&arr)[N]) 
    : starter(arr), ender(std::end(arr)) {
    }
};

template <typename T> struct I12N_for < std::valarray<T> > {
    typedef std::valarray<T> VT;
    typename VT::value_type const* starter;
             size_t                 ender;
    template <size_t N>
    explicit I12N_for (typename std::valarray<T>::value_type const (&arr)[N]) 
    : starter(arr), ender(N) { 
    }

};

}
}


#define CXXO_I12N_BEG(Type,Name) typedef std::remove_cv<Type>::type Name##0ncv; static const Name##0ncv::value_type Name##0init []
#define CXXO_I12N_END(Type,Name) ; Type Name ((Name##0init), cxxomfort::i12n_detail::I12N_for< Name##0ncv >(Name##0init).ender)

// If compiler supports variadic macros, this can be used:
#if (CXXO_COMPILER_SUPPORT_va_args==1 )
#define CXXO_I12N_SEQ(Type,Name,...) CXXO_I12N_BEG(Type,Name) =  __VA_ARGS__ CXXO_I12N_END(Type,Name)
#endif

/*
 * Mode of use:

vector<int> vn CXXO_SQ_BEG(vn) = {1, 2, 3, 4} CXXO_SQ_END(vn);

 *
 */
#else
//! Begins a sequence initialization construct
    #define CXXO_I12N_BEG(Type,Name) Type  Name
//! Finishes a sequence initialization construct
    #define CXXO_I12N_END(Type,Name)
//! Variadic sequence initialization construct
    #define CXXO_I12N_SEQ(Type,Name,...)  Type Name ({__VA_ARGS__});

#endif // c++11

#endif
