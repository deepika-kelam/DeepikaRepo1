#ifndef CXXOMFORT_FOREACH_HPP
#define CXXOMFORT_FOREACH_HPP

/**
 * @file cxxomfort/extras/foreach.hpp
 * @brief Implements backwards-compatible range-for functionality
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 *
 * Interfaces implemented in this file:
 *
 * * CXXO_FOREACH
 *
 * When in C++11 mode, the @c foreach just expands to the new
 * "range for" expression, acting natively.
 *
 * @see http://www.artima.com/cppsource/foreach.html
 */

#include <cxxomfort/config.hpp> // c++11

#if 0

// GNU C++ < 4.6 doesn't support new foreach even in C++0x mode
/*
#elif (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_GCC)
    // GCC version
    #if (CXXOMFORT_COMPILER_VERSION < 405) || !(CXXOMFORT_CXX_EMULATION < 2011)
    #define CXXOMFORT_USING_FOREACH_EMULATION 1
    #endif

*/
#else 

#if (CXXOMFORT_CXX_STD < 2011 || CXXO_COMPILER_SUPPORT_foreach == 0)
#define CXXOMFORT_USING_FOREACH_EMULATION 1
#endif


#endif
// compiler ID

#if (!defined(CXXOMFORT_USING_FOREACH_EMULATION))
    #define CXXOMFORT_IMPLEMENTS_n2930 CXXO_REDIRECT_NATIVE()

    #define CXXO_FOREACH(VDecl,CDecl) for (VDecl : CDecl)
    // end c++11
#else
    #define CXXOMFORT_IMPLEMENTS_n2930 CXXO_EMULATION()

    #if defined(CXXOMFORT_NOTICES)
        #if (CXXOMFORT_NOTICES > 1)
        #pragma message CXXO_NOTICE("enabled foreach iteration support.")
        #endif
    #endif

#if defined(__GNUC__)
    #include "../impl/foreach_gcc.hpp"
#else
    #include "../impl/foreach_artima.hpp"
#endif

/*
 * For any other compiler, we use Artima article's basic solution
 * up to Page 2, that is, support for evaluating the container
 * only once. Any support further than that (eg.: working with
 * returned values) seems to require Boost at the moment.
 *
 * The code that follows here is a modification of the original
 * Artima article "listing_1.cpp" modified to suit the use of
 * cxxomfort's capabilities.
 *
 * - modifications from page 2 of the article to evaluate the
 * container expression once.
 * - support from iterator.hpp to use global begin(), end(),
 * which allows it to trivially support eg.: C arrays and strings.
 *
 */

    // end c++11 / c++03
#endif

#if defined(DOXYGEN_DOC)
/**
 * @def CXXO_FOREACH(itemdecl,collection)
 * @brief Foreach loop construct that iterates over @p collection .
 * @ingroup independent-features
 *
 * A foreach macro declares iteration over @p collection , which can be
 * any STL-compatible sequence, using @p itemdecl as the iterating item.
 *
 * Usage is as follows:
 *
 * @code
 * list<int> L = {2, 3, 5, 7, 11};
 * CXXO_FOREACH (int x, L) {
 *   cout<< x<< ' ';
 * }
 * @endcode
 * 
 * * In C++11 mode, this expands to the native <code>for (itemdecl : collection)</code> 
 * range-for iteration, incurring in no cost.
 * * In C++03 mode, this expands to a type-erasure based solution similar to 
 * <code>for (unspecified_iterator b = begin(collection), e = end(collection) ; b != e ; ++b) if(itemdecl) ...</code>; 
 * this has cost of one @c virtual function call in compilers that do not offer "typeof" emulation, 
 * and cost of one static function call level in compilers that do.
 */
#define CXXO_FOREACH(itemdecl,collection) for (implementation_specific_arguments;;)

#endif // doc

#endif
