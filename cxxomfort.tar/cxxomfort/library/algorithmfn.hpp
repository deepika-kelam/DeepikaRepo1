#ifndef CXXOMFORT_CXXO_ALGORITHMFN_HPP
#define CXXOMFORT_CXXO_ALGORITHMFN_HPP
#include <cxxomfort/config.hpp>
#include <cxxomfort/base.hpp>
#include <algorithm>
#include <iterator>

namespace cxxomfort {
namespace algorithm {

namespace detail {

template<class It, class Pred>
It find_last_if (It ini, It fin, Pred f, std::forward_iterator_tag) {
    using namespace std;
    It ret(fin);
    for (; ini != fin; ++ini) {
        if (f(*ini)) { ret= ini; }
    }
    return ret;
}

template<class It, class Pred>
It find_last_if (It ini, It fin, Pred f, std::bidirectional_iterator_tag) {
    using namespace std;
    It ret(fin);
    for (; ini != fin; --fin) {
        It t= prev(fin,1);
        if (f(*t)) { return t; }
    }
    return ret;
}

} // .detail::

//! Finds the last item that fulfills @c f .
template <typename Iter, typename Pred>
Iter find_last_if (Iter ini, Iter fin, Pred f) {
    typedef const typename std::iterator_traits<Iter>::iterator_category cat;
    return detail::find_last_if(ini, fin, f, cat());
}


//! count_while proposal
//! https://groups.google.com/a/isocpp.org/forum/?fromgroups#!topic/std-proposals/bXrQrkBw59c
template <class InputIterator, class UnaryPredicate>
typename std::iterator_traits<InputIterator>::difference_type
count_while (InputIterator first, InputIterator last, UnaryPredicate pred) {
    typename std::iterator_traits<InputIterator>::difference_type ret = 0;
    while (first!=last && pred(*first)) {
        ++ret;
        ++first;
    }
    return ret;
}

//! transform_inplace
template <typename FIter, typename F>
FIter transform_inplace (FIter ini, FIter fin, F f) {
    for (; ini != fin; ++ini) {
        *ini= f(*ini);
    }
    return ini;
}

//! transform elements up to n times
template <typename IIterator, typename OIterator, typename Op, typename Integer>
inline OIterator transform_n (IIterator ini, Integer n, OIterator dest, Op g) {
    for (Integer i(0); i < n; ++i) { *dest= g(*ini); }
    return dest;
}


/**
 * count_frequencies
 * */

} // .algorithm::
}

#endif
