#ifndef CXXOMFORT_PAIR03_HPP
#define CXXOMFORT_PAIR03_HPP
#include <cxxomfort/config.hpp>
#include <cxxomfort/base.hpp>
#include <utility> // std::pair

//////////////////////////////////////////////////

//
// Implementation of pair<> with C++11 semantics
// for C++03 only
//
//#include <tuple>

namespace cxxomfort {

#if (CXXOMFORT_CXX_STD >= 2011)
    using std::pair;
    using std::make_pair;
#else



/**
 * @brief Tag indicator for piecewise construction in @c pair .
 */
const struct piecewise_construct_t {} piecewise_construct = {};

template <typename A, typename B> class pair {
    typedef pair<A,B> this_t;
    CXXO_COPYABLE_MOVABLE(pair);
    public:
    // pair () {} // trivial
    pair (A const& a, B const& b) 
    : first(a), second(b) {}
    template <typename C1, typename C2>
    pair (CXXO_RV_REF(C1) x, CXXO_RV_REF(C2) y) 
    : first(std::forward<C1>(x)), second(std::forward<C2>(y)) {}
    pair (pair const& p) 
    : first(p.first), second(p.second) {} // trivial
    template <typename C1, typename C2>
    pair (pair<C1,C2> const& p) 
    : first(p.first), second(p.second) {}
    pair (CXXO_RV_REF(pair) p) 
    : first(std::move(p.first)), second(std::move(p.second)) {}
    template <typename Tuple1, typename Tuple2>
    pair (/* typename std::enable_if< is_tuple<Tuple1>::value && is_tuple<Tuple2>::value, piecewise_construct_t>::type */
        piecewise_construct_t, Tuple1 t1, Tuple2 t2);

    //~pair () {} // trivial
    
    pair& operator= (pair const& p) {
        first= p.first;
        second= p.second;
        return *this;
    }
    
    template <typename C1, typename C2>
    pair& operator= (pair<C1,C2> const& p) {
        first= p.first;
        second= p.second;
        return *this;
    }

    void swap (pair& other) {
        using std::swap;
        swap(first, other.first);
        swap(second, other.second);
    }
    
    public:
    typedef A first_type;
    typedef B second_type;
    A first;
    B second;

}; //pair

//! make_pair idiom
template <typename A, typename B>
pair<A,B> make_pair(A const& a, B const& b) {
    return pair<A,B>(a,b);
}


template <typename A, typename B, typename C, typename D> inline
bool operator== (pair<A,B> const& p, pair<C,D> const& q) {
    return (p.first==q.first && p.second==q.second);
}

template <typename A, typename B, typename C, typename D> inline
bool operator!= (pair<A,B> const& p, pair<C,D> const& q) {
    return !(p==q);
}

template <typename A, typename B> inline
bool operator< (pair<A,B> const& p, pair<A,B> const& q) {
    return (p.first < q.first) ? true : (p.second < q.second);
}

template <typename A, typename B> inline
bool operator> (pair<A,B> const& p, pair<A,B> const& q) {
    return q < p;
}


#if 0 // requires tuple support
//
// piecewise tuple constructor for pair
//

#define _Ty(X) typename X##0, typename X##1, typename X##2, typename X##3, typename X##4, typename X##5, typename X##6, typename X##7, typename X##8, typename X##9 

namespace detail_pair_piecewise {

template <typename T, typename Tuple, size_t Size> struct builder;

template <typename T, typename Tuple> struct builder<T,Tuple,0> {
    builder (Tuple const& v) : v_(v) {}
    operator T () const {
        return T( );
    }
    Tuple const& v_;
};

template <typename T, typename Tuple> struct builder<T,Tuple,1> {
    builder (Tuple const& v) : v_(v) {}
    operator T () const {
        using std::get;
        return T( get<0>(v_) );
    }
    Tuple const& v_;
};

template <typename T, typename Tuple> struct builder<T,Tuple,2> {
    builder (Tuple const& v) : v_(v) {}
    operator T () const {
        using std::get;
        return T( get<0>(v_) , get<1>(v_) );
    }
    Tuple const& v_;
};

template <typename T, typename Tuple> struct builder<T,Tuple,3> {
    builder (Tuple const& v) : v_(v) {}
    operator T () const {
        using std::get;
        return T( get<0>(v_) , get<1>(v_) , get<2>(v_) );
    }
    Tuple const& v_;
};

template <typename T, typename Tuple> struct builder<T,Tuple,4> {
    builder (Tuple const& v) : v_(v) {}
    operator T () const {
        using std::get;
        return T( get<0>(v_) , get<1>(v_) , get<2>(v_), get<3>(v_) );
    }
    Tuple const& v_;
};

template <typename T, typename Tuple> struct builder<T,Tuple,5> {
    builder (Tuple const& v) : v_(v) {}
    operator T () const {
        using std::get;
        return T( get<0>(v_) , get<1>(v_) , get<2>(v_), get<3>(v_), get<4>(v_) );
    }
    Tuple const& v_;
};

} //detail_pair_piecewise::

template <typename A, typename B>
template <typename Tuple1, typename Tuple2>
pair<A,B>::pair (
typename std::enable_if
        < is_tuple<Tuple1>::value && is_tuple<Tuple2>::value, piecewise_construct_t
        >::type
    , Tuple1 tp, Tuple2 tq)
: first( detail_pair_piecewise::builder<A, Tuple1, std::tuple_size<Tuple1>::value>(tp))
, second(detail_pair_piecewise::builder<B, Tuple2, std::tuple_size<Tuple2>::value>(tq))
{
}


#undef _Ty

#endif // requires tuple support

#endif

}

#endif
