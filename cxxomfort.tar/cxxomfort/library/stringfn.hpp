#ifndef CXXOMFORT_CXXO_STRINGFN_HPP
#define CXXOMFORT_CXXO_STRINGFN_HPP

/**
 * @file stringfn.hpp
 * @brief cxxomfort's string-related functions
 * @ingroup independent-features
 * 
 * C++'s string public interface kinda sucks so we 
 * add some functions to complement it here. 
 * While they are intended to work with std::string, 
 * they should be able to work well with any char-type.
 * 
 * Interfaces defined in this file:
 * 
 * * join
 * * (TBA) split
 * * (TBA) substr
 * * l_trim, r_trim
 * * trim
 * 
 */

#include <cstring>
#include <string>
#include <sstream>
#include <cxxomfort/algorithm.hpp>

namespace cxxomfort {
namespace string {

/**
 * Joins all contents from [ini,fin) into a string.
 * @ingroup independent-features
 */
template <typename String, typename Iterator1, typename Iterator2>
String join (String const& sep, Iterator1 ini, Iterator2 fin) {
    String ret;
    if (ini != fin) {
        std::stringstream ss; //<- needs to change to be generic
        ss<< *ini++;
        for(; ini != fin; ++ini) {
            ss<< sep<< *ini;
        }
        ret= ss.str();
    }
    return ret;
}

//! @overloads join
template <typename Iterator1, typename Iterator2> inline 
std::string join (std::string const& sep, Iterator1 ini, Iterator2 fin) {
    return join<std::string>(sep,ini,fin);
}


template <typename String, typename Pred>
void l_trim (String& s, Pred p) {
    using namespace std;
    // we find L = first position in s where p(L) is false
    // we use string's erase function (or just a copy constructor)
    typename String::iterator L = find_if_not(begin(s), end(s), p);
    if (L == end(s)) return;
    s= String(L, end(s));
}


template <typename String, typename Pred>
void r_trim (String& s, Pred p) {
    using namespace std;
    // we find L = last position in s where p(L) is true
    // we use string's erase function (or just a copy constructor)
    typename String::reverse_iterator L = find_if_not(s.rbegin(), s.rend(), p);
    if (L == s.rend()) return;
    s= String(s.rend().base(), L.base());
}

template <typename String, typename Pred>
void trim (String& s, Pred p) {
    l_trim(s,p);
    r_trim(s,p);
}


}
} // cxxomfort


#endif
