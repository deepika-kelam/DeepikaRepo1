#ifndef CXXOMFORT_CXXO_TUPLEFN_HPP
#define CXXOMFORT_CXXO_TUPLEFN_HPP
/**
 * @file library/tuplefn.hpp
 * @brief cxxomfort's tuple-related functions
 * @ingroup independent-features
 *
 * Interfaces defined:
 * 
 * * is_tuple
 * * tuple_shift
 * * tuple_pop
 */

#include <tuple>
#include "../impl/14-integer_sequence.hpp"

namespace cxxomfort {
namespace tuple {


//
// is_tuple -- for specializations of calls based on tuples in C++03
//

//! @addtogroup independent-features
template <typename T> struct is_tuple: traits::false_type {};

#if (CXXOMFORT_CXX_STD >= 2011) || \
 (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_GCC && CXXOMFORT_CXX_EMULATION == 2011)

//! Inherits from @c true_type  if @p T  is a <code>std::tuple</code>.
template <typename... Args> struct is_tuple< std::tuple<Args...> >
: traits::true_type {};

#else // c++03

// assume implementation of tuple in tr1 and supports at least 10 elements
template <typename T1> struct is_tuple <std::tuple<T1> >
: traits::true_type {};
template <typename T1, typename T2> 
struct is_tuple <std::tuple<T1,T2> >
: traits::true_type {};
template <typename T1, typename T2, typename T3> 
struct is_tuple <std::tuple<T1,T2,T3> >
: traits::true_type {};
template <typename T1, typename T2, typename T3, typename T4> 
struct is_tuple <std::tuple<T1,T2,T3,T4> >
: traits::true_type {};
template <typename T1, typename T2, typename T3, typename T4, typename T5> 
struct is_tuple <std::tuple<T1,T2,T3,T4,T5> >
: traits::true_type {};
template <typename T1, typename T2, typename T3, typename T4, typename T5, typename T6> 
struct is_tuple <std::tuple<T1,T2,T3,T4,T5,T6> >
: traits::true_type {};
template <typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7> 
struct is_tuple <std::tuple<T1,T2,T3,T4,T5,T6,T7> >
: traits::true_type {};
template <typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8> 
struct is_tuple <std::tuple<T1,T2,T3,T4,T5,T6,T7,T8> >
: traits::true_type {};
template <typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8, typename T9> 
struct is_tuple <std::tuple<T1,T2,T3,T4,T5,T6,T7,T8,T9> >
: traits::true_type {};

// if compiler supports variadics, we can extend this
#if (CXXO_EMULATION_variadic==1)
template <typename T0, typename T1, typename T2, typename T3, typename T4
        , typename T5, typename T6, typename T7, typename T8, typename T9, typename... TArgs> 
struct is_tuple <std::tr1::tuple<T0,T1,T2,T3,T4,T5,T6,T7,T8,T9,TArgs...> >
: traits::true_type {};
#endif

#endif


/*
 * tuple_pop: removes the last type from a tuple
 */
#if (0 && CXXOMFORT_CXX_STD >= 2011)

//! Pops (discards) the rightmost type in a tuple.
//! @ingroup independent-utilities
template <typename AF, typename Args..., typename Indices...>
std::tuple<Args...> tuple_pop (std::tuple<Args...,AF> && _tuple) {
    using namespace std;
    return make_tuple( forward<Args...>(get<Indices...>(_tuple));
}
#else
template <typename A0, typename A1>
std::tuple<A0> tuple_pop (std::tuple<A0,A1> const& t) {
    using std::get;
    return std::make_tuple( get<0>(t) );
}
template <typename A0, typename A1, typename A2>
std::tuple<A0,A1> tuple_pop (std::tuple<A0,A1,A2> const& t) {
    using std::get;
    return std::make_tuple( get<0>(t), get<1>(t) );
}
template <typename A0, typename A1, typename A2, typename A3>
std::tuple<A0,A1,A2> tuple_pop (std::tuple<A0,A1,A2,A3> const& t) {
    using std::get;
    return std::make_tuple( get<0>(t), get<1>(t), get<2>(t) );
}
template <typename A0, typename A1, typename A2, typename A3, typename A4>
std::tuple<A0,A1,A2,A3> 
tuple_pop (std::tuple<A0,A1,A2,A3,A4> const& t) {
    using std::get;
    return std::make_tuple( get<0>(t), get<1>(t), get<2>(t), get<3>(t) );
}
template <typename A0, typename A1, typename A2, typename A3, typename A4, typename A5>
std::tuple<A0,A1,A2,A3,A4> 
tuple_pop (std::tuple<A0,A1,A2,A3,A4,A5> const& t) {
    using std::get;
    return std::make_tuple( get<0>(t), get<1>(t), get<2>(t), get<3>(t), get<4>(t) );
}

// c++03 impl
#endif

/*
 * tuple_shift: removes the first type from a tuple
 */

#if (0 && CXXOMFORT_CXX_STD >= 2011)

//! Shifts a tuple one type to the left, discarding the leftmost type.
//! @ingroup independent-utilities
template <typename A1, typename... Args, typename... Indices>
std::tuple<Args...> tuple_shift (std::tuple<A1,Args...> && _tuple) {
    using namespace std;
    return make_tuple( forward<Args...>(get<Indices...>(_tuple));
}
#else
// c++03 impl
template <typename A0, typename A1>
std::tuple<A1> tuple_shift (std::tuple<A0,A1> const& t) {
    using std::get;
    return std::make_tuple( get<1>(t) );
}
template <typename A0, typename A1, typename A2>
std::tuple<A1,A2> tuple_shift (std::tuple<A0,A1,A2> const& t) {
    using std::get;
    return std::make_tuple( get<1>(t), get<2>(t) );
}
template <typename A0, typename A1, typename A2, typename A3>
std::tuple<A1,A2,A3> tuple_shift (std::tuple<A0,A1,A2,A3> const& t) {
    using std::get;
    return std::make_tuple( get<1>(t), get<2>(t), get<3>(t) );
}

#endif



//
// tuple_call (f, Tuple)
// calls f for each member of Tuple
//
#if (CXXOMFORT_CXX_STD >= 2011)
template <typename F, typename Tuple, typename std::enable_if< cxxomfort::tuple::is_tuple<Tuple>::value, F>::type>
F
#else
template <typename F, typename Tuple>
typename std::enable_if< cxxomfort::tuple::is_tuple<Tuple>::value, F>::type // F
#endif
tuple_call (F& f, Tuple& t) {
    return f;
}

}
} // cxxomfort::

#endif
