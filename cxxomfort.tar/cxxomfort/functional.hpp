#ifndef CXXOMFORT_FUNCTIONAL_HPP
#define CXXOMFORT_FUNCTIONAL_HPP

/**
 * @file functional.hpp
 * @brief Implementations and additions tied to <functional>.
 * 
 * Interfaces defined in this file:
 *
 * * bit_and, bit_or, bit_not as per C++14.
 * * transparent plus, minus, multiplies, divides, modulus as per C++14.
 *
 */

#include <cxxomfort/base.hpp>
#include CXXO_INCLUDE_SYS(functional)

#if (defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1))
    #pragma message CXXO_NOTICE("enabled <functional> support.")
#endif

// The bit_and and sibling functors from <functional> are missing in MSVC 2008
#if (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_MSC && CXXOMFORT_COMPILER_VERSION <= 150)
    #include "impl/03-functional_bit.hpp"
#endif

/**
 * @addtogroup functional
 * @{
 */


/**
 * @}
 */

#include "./impl/14-functional-transparent.hpp"
//#include "./impl/17-notfn.hpp"

#endif
