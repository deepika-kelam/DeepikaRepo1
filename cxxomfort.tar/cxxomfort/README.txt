cxxcomfort Library for C++
--------------------------

C++ backports of nifty C++11 utilities (and more)
by Luis Machuca Bezzaza

Cxxomfort is a small, header-only library that backports features from more recent C++ Standards to previous ones, for example C++11 features are backported to C++03.

It was written to facilitate my working with the evolving C++ standard as I was getting back into the language, but it evolved to fulfill a more general purpose. 

It is intended to reduce the amount and stress of code rewrite while at the same time assisting in backwards and forwards portability of code.

Documentation
-------------

Check the repository's web interface - 
http://ryan.gulix.cl/fossil.cgi/cxxomfort

It includes code samples and a listing of Nxxxx proposals or features of C++11, C++14, C++1y that are added to this library.

Installation
------------

The overall installation procedure is as simple as this:

* clone repo
* open repo
* add the internal 'cxxomfort/' path to your compiler's #include settings

Usage
-----

Check the repository's web page as well as the 
C++ Reference wiki for information of various features that this 
library can provide:

* cxxomfort -- http://ryan.gulix.cl/fossil.cgi/cxxomfort/
* C++ Reference -- http://en.cppreference.com/

License
-------

Read LICENSE.txt
