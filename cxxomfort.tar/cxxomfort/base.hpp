#ifndef CXXOMFORT_BASE_HPP
#define CXXOMFORT_BASE_HPP
/**
 * @file cxxomfort/base.hpp
 * @brief Minimal cxxomfort setup.
 * 
 * For more complete cxxomfort setup (includes more headers, adds new names 
 * and functions) include "cxxomfort.hpp".
 */

#include "config.hpp"

// -- Cxxomfort basic features, always enabled by default --
#include "./base/alignof.hpp" // alignof impl
#include "./base/nullptr.hpp" // nullptr
#include "./base/static_assert.hpp" // static_assert
#include "./base/cstdint.hpp" // c++11 integer types ([u]intNN_t)
#include "./base/iterator.hpp" // iter. accessors (begin/end, next/prev)
#include "./base/explicit_cast.hpp" // explicit cast operator
#include "./base/move.hpp" // move emulation
#include "./library/i12n.hpp" // { sequence } initialization emulation

#endif

/**
 * @page base-features
 * 
 * The set of basic features of cxxomfort. 
 * These features are included automatically when 
 * <code>#include <cxxomfort/base.hpp></code> is included 
 * or any of the cxxomfort headers are included.
 */
