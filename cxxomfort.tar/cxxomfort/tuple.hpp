#ifndef CXXOMFORT_TUPLE_HPP
#define CXXOMFORT_TUPLE_HPP
/**
 * @file cxxomfort/tuple.hpp
 * @brief Implementations for <tuple> in C++
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 *
 * Interfaces defined in this header:
 *
 * * cxxomfort::is_tuple
 * * tuple2function_t
 * * function2tuple_t
 * * tuple2array
 * * get<T> for std::tuple
 * * cxxomfort::apply(tuple,function)
 *
 */

#include "base.hpp"
#include "utility.hpp" // index_sequence
#include <tuple> // d'uh
#include <array> // array <-> tuple conversions
#include <cxxomfort/library/tuplefn.hpp> // is_tuple

#if (defined(CXXOMFORT_NOTICES) && CXXOMFORT_NOTICES > 1)
    #pragma message CXXO_NOTICE("enabled <tuple> support")
#endif

/*
 * Given a tuple T<T1,T2,...>, obtain the function signature R(T1,T2,...)
 */


/**
 * @brief Convert from tuple type to function signature.
 * 
 * Given a tuple of the form T<T1,T2,...>,
 * obtain a function signature R(T1,T2,...) 
 */

namespace cxxomfort {

    template <typename Ret, typename Tuple> struct tuple2function_t {};



#if (CXXOMFORT_CXX_STD >= 2011)
    template <typename R, typename... Args>
    struct tuple2function_t< R, std::tuple<Args...> > {
        typedef R(type)(Args...);
    };

#else // c++03

    template <typename R, typename T0> struct tuple2function_t< R,std::tuple<T0> > {
        typedef R(type)(T0);
    };

    template <typename R, typename T0, typename T1> struct tuple2function_t< R,std::tuple<T0,T1> > {
        typedef R(type)(T0,T1);
    };
    template <typename R, typename T0, typename T1, typename T2> 
    struct tuple2function_t< R,std::tuple<T0,T1,T2> > {
        typedef R(type)(T0,T1,T2);
    };
    template <typename R, typename T0, typename T1, typename T2, typename T3> 
    struct tuple2function_t< R,std::tuple<T0,T1,T2,T3> > { typedef R(type)(T0,T1,T2,T3); 
    };
    template <typename R, typename T0, typename T1, typename T2, typename T3, typename T4> 
    struct tuple2function_t< R,std::tuple<T0,T1,T2,T3,T4> > { typedef R(type)(T0,T1,T2,T3,T4); 
    };
    template <typename R, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5> 
    struct tuple2function_t< R,std::tuple<T0,T1,T2,T3,T4,T5> > { typedef R(type)(T0,T1,T2,T3,T4,T5); 
    };
    template <typename R, 
        typename T0, typename T1, typename T2, typename T3, typename T4, 
        typename T5, typename T6> 
    struct tuple2function_t< R,std::tuple<T0,T1,T2,T3,T4,T5,T6> > { 
        typedef R(type)(T0,T1,T2,T3,T4,T5,T6); 
    };
    template <typename R, 
        typename T0, typename T1, typename T2, typename T3, typename T4, 
        typename T5, typename T6, typename T7> 
    struct tuple2function_t< R,std::tuple<T0,T1,T2,T3,T4,T5,T6,T7> > { 
        typedef R(type)(T0,T1,T2,T3,T4,T5,T6,T7); 
    };
    template <typename R, 
        typename T0, typename T1, typename T2, typename T3, typename T4, 
        typename T5, typename T6, typename T7, typename T8> 
    struct tuple2function_t< R,std::tuple<T0,T1,T2,T3,T4,T5,T6,T7,T8> > { 
        typedef R(type)(T0,T1,T2,T3,T4,T5,T6,T7,T8); 
    };
    template <typename R, 
        typename T0, typename T1, typename T2, typename T3, typename T4, 
        typename T5, typename T6, typename T7, typename T8, typename T9> 
    struct tuple2function_t< R,std::tuple<T0,T1,T2,T3,T4,T5,T6,T7,T8,T9> > { 
        typedef R(type)(T0,T1,T2,T3,T4,T5,T6,T7,T8,T9); 
    };

#endif

} // cxxomfort::


/**
 * @brief Convert from function signature type to tuple type.
 * 
 * Given a function signature R(T1,T2,...), 
 * obtain a tuple of the form T<T1,T2,...>
 */

namespace cxxomfort {

    template <typename FnSig> struct function2tuple_t {};

#if (CXXOMFORT_CXX_STD >= 2011) 

    template <typename... Args, typename R>
    struct function2tuple_t<R(Args...)> {
        typedef std::tuple<Args...> type;
    };

#else // c++03

    template <typename T0, typename R>
    struct function2tuple_t<R(T0)> {
        typedef std::tuple<T0> type;
    };
    template <typename T0, typename T1, typename R>
    struct function2tuple_t<R(T0,T1)> {
        typedef std::tuple<T0,T1> type;
    };
    template <typename T0, typename T1, typename T2, typename R>
    struct function2tuple_t<R(T0,T1,T2)> {
        typedef std::tuple<T0,T1,T2> type;
    };
    template <typename T0, typename T1, typename T2, typename T3, typename R>
    struct function2tuple_t<R(T0,T1,T2,T3)> {
        typedef std::tuple<T0,T1,T2,T3> type;
    };
    template <typename T0, typename T1, typename T2, typename T3, typename T4, typename R>
    struct function2tuple_t<R(T0,T1,T2,T3,T4)> {
        typedef std::tuple<T0,T1,T2,T3,T4> type;
    };
    template <typename T0, typename T1, typename T2, typename T3, typename T4, 
        typename T5, typename R>
    struct function2tuple_t<R(T0,T1,T2,T3,T4,T5)> {
        typedef std::tuple<T0,T1,T2,T3,T4,T5> type;
    };
    template <typename T0, typename T1, typename T2, typename T3, typename T4, 
        typename T5, typename T6, typename R>
    struct function2tuple_t<R(T0,T1,T2,T3,T4,T5,T6)> {
        typedef std::tuple<T0,T1,T2,T3,T4,T5,T6> type;
    };

#endif


} // cxxomfort::

//
// tuple to array
//

namespace cxxomfort {
namespace tuple {

template <typename Tuple>
struct _tuple2array_cnv_t {
    // Tuple is a tuple
    static_assert (is_tuple<Tuple>::value, "tuple_to_array: T must be a tuple");
    typedef /* typename std::decay<Tuple>::type */ Tuple InTuple;
    static const size_t _S = std::tuple_size<InTuple>::value;
    typedef typename std::tuple_element<0,Tuple>::type U;
    private:
    
    template <unsigned U>
    struct _notenabled;
    
    public:
    
    _tuple2array_cnv_t (Tuple const& t): _t(t) {}
    // conversion operator to an array of the same size as the tuple
#if (1 && ( CXXOMFORT_CXX_STD >= 2011 || (CXXOMFORT_CXX_EMULATION == 2011 && CXXO_EMULATION_variadic && CXXO_EMULATION_rvref)))
    template<size_t... I>
    std::array<U,_S> get_array (std::index_sequence<I...>) const {
        using std::get;
        using std::forward;
        return std::array<U,_S> { get<I>((_t))... };
    }


    template <typename Indices = std::make_index_sequence<std::tuple_size<InTuple>::value> >
    operator std::array<U,_S> () const {
        return get_array(Indices());
    }


#else
#define CXXO_m_cnv_array(n) operator typename std::conditional< _S==n, std::array<U,n> , _notenabled<n> >::type
    CXXO_m_cnv_array(1) () const {
        using namespace std;
        array<U,1> ret= { get<0>(_t) };
        return ret;
    }
    CXXO_m_cnv_array(2) () const {
        using namespace std;
        array<U,2> ret= { get<0>(_t), get<1>(_t) };
        return ret;
    }
    CXXO_m_cnv_array(3) () const {
        using namespace std;
        array<U,3> ret= { get<0>(_t), get<1>(_t), get<2>(_t) };
        return ret;
    }
    CXXO_m_cnv_array(4) () const {
        using namespace std;
        array<U,4> ret= { get<0>(_t), get<1>(_t), get<2>(_t), get<3>(_t) };
        return ret;
    }

    CXXO_m_cnv_array(5) () const {
        using namespace std;
        array<U,5> ret= { get<0>(_t), get<1>(_t), get<2>(_t), get<3>(_t), get<4>(_t) };
        return ret;
    }

#undef CXXO_m_cnv_array
#endif
    private:
    Tuple const& _t;
};

template <typename T>
_tuple2array_cnv_t<T> tuple2array (T const& t) {
    return _tuple2array_cnv_t<T>(t);
}

/*
 * array to tuple
 */

template <typename T> struct tuple_of_array_size;

template <typename T0> struct tuple_of_array_size< std::array<T0,1> > {
    typedef std::tuple<T0>  type;
};
template <typename T0> struct tuple_of_array_size< std::array<T0,2> > {
    typedef std::tuple<T0,T0>  type;
};
template <typename T0> struct tuple_of_array_size< std::array<T0,3> > {
    typedef std::tuple<T0,T0,T0>  type;
};
template <typename T0> struct tuple_of_array_size< std::array<T0,4> > {
    typedef std::tuple<T0,T0,T0,T0>  type;
};
template <typename T0> struct tuple_of_array_size< std::array<T0,5> > {
    typedef std::tuple<T0,T0,T0,T0,T0>  type;
};
template <typename T0> struct tuple_of_array_size< std::array<T0,6> > {
    typedef std::tuple<T0,T0,T0,T0,T0,T0>  type;
};
template <typename T0> struct tuple_of_array_size< std::array<T0,7> > {
    typedef std::tuple<T0,T0,T0,T0,T0,T0,T0>  type;
};
template <typename T0> struct tuple_of_array_size< std::array<T0,8> > {
    typedef std::tuple<T0,T0,T0,T0,T0,T0,T0,T0>  type;
};
template <typename T0> struct tuple_of_array_size< std::array<T0,9> > {
    typedef std::tuple<T0,T0,T0,T0,T0,T0,T0,T0,T0>  type;
};
template <typename T0> struct tuple_of_array_size< std::array<T0,10> > {
    typedef std::tuple<T0,T0,T0,T0,T0,T0,T0,T0,T0,T0>  type;
};


template <typename T>
struct _array2tuple_cnv_t {};

template <typename T, size_t N>
struct _array2tuple_cnv_t< std::array<T,N> > {
    private:
    // Tuple is a tuple
    //static_assert (is_tuple<Tuple>::value, "tuple_to_array: T must be a tuple");
    private:
    std::array<T,N> const& _a;

    typedef /* typename std::decay<Tuple>::type */ std::array<T,N> InArray;
    typedef typename InArray::value_type U;
    template <unsigned U>
    struct _notenabled;
    public:


    _array2tuple_cnv_t (InArray const& a): _a(a) {}


#if (1 && ( CXXOMFORT_CXX_STD >= 2011 || (CXXOMFORT_CXX_EMULATION == 2011 && CXXO_EMULATION_variadic && CXXO_EMULATION_rvref)))
    template <size_t... I>
    typename tuple_of_array_size< InArray>::type get_tuple (std::index_sequence<I...>) const {
        return std::make_tuple(_a[I]...);
    }

    template <typename Indices = std::make_index_sequence<N> >
    operator typename tuple_of_array_size< InArray >::type () const {
        return std::move(get_tuple(Indices()));
    }

#else

#define CXXO_m_cnv_tuple(n) operator typename std::conditional< N==n \
    , typename tuple_of_array_size< std::array<T,n> >::type, _notenabled<n> > \
    ::type

    CXXO_m_cnv_tuple(1) () const { return std::make_tuple( _a[0] ); }
    CXXO_m_cnv_tuple(2) () const { return std::make_tuple( _a[0], _a[1] ); }
    CXXO_m_cnv_tuple(3) () const { return std::make_tuple( _a[0], _a[1], _a[2] ); }
    CXXO_m_cnv_tuple(4) () const { return std::make_tuple( _a[0], _a[1], _a[2], _a[3] ); }
    CXXO_m_cnv_tuple(5) () const { return std::make_tuple( 
        _a[0], _a[1], _a[2], _a[3], _a[4] 
    ); }
    CXXO_m_cnv_tuple(6) () const { return std::make_tuple( 
        _a[0], _a[1], _a[2], _a[3], _a[4], _a[5] 
    ); }
    CXXO_m_cnv_tuple(7) () const { return std::make_tuple
        ( _a[0], _a[1], _a[2], _a[3], _a[4], _a[5], _a[6] 
    ); }
    CXXO_m_cnv_tuple(8) () const { return std::make_tuple
        ( _a[0], _a[1], _a[2], _a[3], _a[4], _a[5], _a[6], _a[7] 
    ); }
    CXXO_m_cnv_tuple(9) () const { return std::make_tuple
        ( _a[0], _a[1], _a[2], _a[3], _a[4], _a[5], _a[6], _a[7], _a[8] 
    ); }
    CXXO_m_cnv_tuple(10) () const { return std::make_tuple
        ( _a[0], _a[1], _a[2], _a[3], _a[4], _a[5], _a[6], _a[7], _a[8], _a[9] 
    ); }
    
#undef CXXO_m_cnv_tuple

#endif

};

template <typename T, size_t N>
_array2tuple_cnv_t<std::array<T,N> > array2tuple (std::array<T,N> const& a) {
    return _array2tuple_cnv_t< std::array<T,N> >(a);
}

} //cxxomfort::tuple
} //


#include "impl/14-tuple_get_type.hpp" // std::get<T> (tuple<>)
#include "impl/14-tuple_apply.hpp" // std::apply (Function, tuple<>)

#endif

