#ifndef CXXOMFORT_LIMITS_HPP
#define CXXOMFORT_LIMITS_HPP
/**
 * @file cxxomfort/limits.hpp
 * @brief Compile-time expressions for integral @c <limits> values in C++
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 *
 * Interfaces defined in this header:
 *
 * * cxxomfort::integral_limits
 *
 */

#include "./config.hpp"
#include "./base.hpp"
#include "./type_traits.hpp"
#include "./util/meta.hpp"
#include <limits>
//#include <type_traits>
#if (defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1))
#pragma message CXXO_NOTICE("enabled <limits> support.")
#endif


namespace cxxomfort {

namespace impl {
template <uintmax_t N, size_t base=2> struct log_ {
    static const size_t value = 1 + log_<N/base, base>::value;
};

template <size_t base>
struct log_<1, base> {
    enum { value = 0 };
};

template <size_t base>
struct log_<0, base> {
    enum { value = 0 };
};


}


template <typename T>
struct integral_limits {
    static_assert (std::is_integral<T>::value, "integral_limits is only defined for compiler integral types");
};

#define SPECIA_IMPL(Ty_,Min_,Max_) \
template <> struct integral_limits<Ty_>           \
: public std::numeric_limits<Ty_> {               \
    typedef std::numeric_limits<Ty_> Base_;       \
    static const Ty_ const_min= Min_;             \
    static const Ty_ const_max= Max_;             \
    template <unsigned short B> struct digits_base {   \
        static const unsigned short value=             \
        /* (digits - is_signed) / impl::log_<B>::value; */  \
        impl::log_<const_max,B>::value;   \
    };                                            \
}

SPECIA_IMPL(bool,false,true);
SPECIA_IMPL(signed int,INT_MIN,INT_MAX);
SPECIA_IMPL(unsigned int,0,UINT_MAX);
SPECIA_IMPL(char,CHAR_MIN,CHAR_MAX);
SPECIA_IMPL(signed char,SCHAR_MIN,SCHAR_MAX);
SPECIA_IMPL(unsigned char,0,UCHAR_MAX);
SPECIA_IMPL(signed short,SHRT_MIN,SHRT_MAX);
SPECIA_IMPL(unsigned short,0,USHRT_MAX);
SPECIA_IMPL(signed long,LONG_MIN,LONG_MAX);
SPECIA_IMPL(unsigned long,0,ULONG_MAX);
SPECIA_IMPL(signed long long,LLONG_MIN,LLONG_MAX);
SPECIA_IMPL(unsigned long long,0,ULLONG_MAX);

#undef SPECIA_IMPL

}


#endif
