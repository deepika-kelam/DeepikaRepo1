#ifndef CXXOMFORT_EXTRAS_HPP
#define CXXOMFORT_EXTRAS_HPP
/* This header file includes the available, finalized 
 * extras features.
 * (Non-finalized features have to be added explicitly)
 */

#include "base.hpp"

#include "./extras/array_ref.hpp" // array_ref implementation (n3334)
#include "./extras/auto.hpp" // decltype(), auto emulation
#include "./extras/dynarray.hpp" // dynarray aka fixed_vector implementation
#include "./extras/foreach.hpp" // for (var: range) emulation
#include "./extras/localfn.hpp" // local functors in templated calls implementation

#endif

