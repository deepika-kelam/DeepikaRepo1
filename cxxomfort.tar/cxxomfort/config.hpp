#ifndef CXXOMFORT_CONFIG_HPP
#define CXXOMFORT_CONFIG_HPP
/**
 * @file cxxomfort/config.hpp
 * @brief Configuration file for cxxomfort-library.
 * @author Luis Machuca Bezzaza
 *
 * This file contains configuration macros used by the cxxomfort library
 * and it is not intended to be directly used.
 */

//! Library version and release date as YYYYMM
#define CXXOMFORT_DATE 201707
//! Defines the library version (WARNING: to be deprecated)
#define CXXOMFORT_VERSION 52

#define CXXO_STRINGIZE_IMPL(x) #x
#define CXXO_STRINGIZE(x) CXXO_STRINGIZE_IMPL(x)
#define CXXO_JOIN(x,y) x##y

//
// Standard Mode
//

//! Year of the standard in use (the year part in @c __cplusplus ).
#define CXXOMFORT_CXX_STD (__cplusplus/100)
//! Year of the standard emulated when the compiler is in emulation mode.
#define CXXOMFORT_CXX_EMULATION 0

// Notices Mode
//#if !defined(CXXOMFORT_NOTICES)
//#define CXXOMFORT_NOTICES 0
//#endif

//
// This section detects the compiler type, major and minor version
// and assigns them for macros for easy evaluation.
//

#define CXXO_VALUE_COMPILER_GCC 101
#define CXXO_VALUE_COMPILER_DIGITALMARS 102
#define CXXO_VALUE_COMPILER_MSC 103
#define CXXO_VALUE_COMPILER_CLANG 104

//
// Set different flags according to the features 
// supported by the compiler
//

//! If compiler includes tr1/random header in c++03 mode
#define CXXO_COMPILER_SUPPORT_tr1_random 0
//! If compiler includes tr1/type_traits header in c++03 mode
#define CXXO_COMPILER_SUPPORT_tr1_type_traits 0
//! If compiler provides support for @c __typeof__ in C++03.
#define CXXO_COMPILER_SUPPORT_typeof 0
//! If compiler provides support for variadic macros (<code>__VA_ARG__</code>).
#define CXXO_COMPILER_SUPPORT_va_args 0

//! If compiler provides support for alignment tools (@c alignas , etc).
#define CXXO_COMPILER_SUPPORT_alignment_tools 0
//! If compiler provides support for @c alignof(T) .
#define CXXO_COMPILER_SUPPORT_alignof 0
//! If compiler provides support for <code>[[__attribute__]]</code>.
#define CXXO_COMPILER_SUPPORT_attribute (CXXOMFORT_CXX_STD >= 2011)
//! If compiler supports new (type-deduction) semantics for @c auto .
#define CXXO_COMPILER_SUPPORT_auto (CXXOMFORT_CXX_STD>=2011)
//! If compiler provides support for @c constexpr .
#define CXXO_COMPILER_SUPPORT_constexpr (CXXOMFORT_CXX_STD>=2011)
//! If compiler supports @c decltype(expr) .
#define CXXO_COMPILER_SUPPORT_decltype (CXXOMFORT_CXX_STD>=2011)
//! If compiler provides support for <code>=default</code>-ed and <code>=delete</code>-d members.
#define CXXO_COMPILER_SUPPORT_default_delete (CXXOMFORT_CXX_STD>=2011)
//! If compiler provides support for scoped enumerations ie.: <code>enum class...</code>.
#define CXXO_COMPILER_SUPPORT_enum_class (CXXOMFORT_CXX_STD>=2011)
//! If compiler provides support for <code>explicit operator ...</code> casts.
#define CXXO_COMPILER_SUPPORT_explicit_operator (CXXOMFORT_CXX_STD>=2011)
//! If compiler provides support for range-for.
#define CXXO_COMPILER_SUPPORT_foreach (CXXOMFORT_CXX_STD>=2011)
//! If compiler provides support for @c std::initializer_list .
#define CXXO_COMPILER_SUPPORT_initializer_list (CXXOMFORT_CXX_STD>=2011)
//! If compiler provides support for local and unnamed types as template arguments.
#define CXXO_COMPILER_SUPPORT_local_types (CXXOMFORT_CXX_STD>=2011)
//! If compiler provides support for @c noexcept *AND* is_noexcept-traits.
#define CXXO_COMPILER_SUPPORT_noexcept (CXXOMFORT_CXX_STD>=2011)
//! If compiler provides support for @c nullptr  and @c std::nullptr_t .
#define CXXO_COMPILER_SUPPORT_nullptr (CXXOMFORT_CXX_STD>=2011)
//! If compiler provides support for @c T&& .
#define CXXO_COMPILER_SUPPORT_rvref (CXXOMFORT_CXX_STD>=2011)
//! If compiler provides support for @c static_assert .
#define CXXO_COMPILER_SUPPORT_static_assert (CXXOMFORT_CXX_STD>=2011)
//! If compiler provides support for the new C++11 std algorithms.
#define CXXO_COMPILER_SUPPORT_std_cxx11_algorithms 0
//! If compiler provides support for the new C++11 helpers std::begin, std::end.
#define CXXO_COMPILER_SUPPORT_std_iterator_helpers 0
//! If compiler provides support for std::next, std::prev.
#define CXXO_COMPILER_SUPPORT_std_iterator_helpers_next_prev 0
//! If compiler provides support for the new C++11 helpers std::enable_if, std::conditional.
#define CXXO_COMPILER_SUPPORT_std_metaprogramming_helpers 0
//! If compiler provides support for the <code>std::is_[trivially|nothrow]_...</code> traits.
#define CXXO_COMPILER_SUPPORT_std_is_trivially 0
//! If compiler provides support for C++11's 'common_type'.
#define CXXO_COMPILER_SUPPORT_std_cxx11_common_type 0
//! If compiler provides support for the "is_constructible", "is_assignable", and similar traits.
#define CXXO_COMPILER_SUPPORT_std_cxx11_constructible_traits 0
//! If compiler provides support for trailing return types.
#define CXXO_COMPILER_SUPPORT_trailing_returns (CXXOMFORT_CXX_STD>=2011)
//! If compiler provides support for @c unique_ptr<T> .
#define CXXO_COMPILER_SUPPORT_unique_ptr 0
//! If compiler provides support for variadic templates.
#define CXXO_COMPILER_SUPPORT_variadic (CXXOMFORT_CXX_STD>=2011)

//! If compiler provides support for C++14's relaxed form of @c constexpr .
#define CXXO_COMPILER_SUPPORT_constexpr_relaxed (CXXOMFORT_CXX_STD>=2014)
//! If compiler supports <functional> 's transparent functors.
#define CXXO_COMPILER_SUPPORT_functional_transparent (CXXOMFORT_CXX_STD >= 2014)
//! If compiler provides support for "integer_sequence".
#define CXXO_COMPILER_SUPPORT_integer_sequence (CXXOMFORT_CXX_STD >= 2014)



//------------------------------------------------

// Detect CXX_STD and operation mode (initial)

/*
#if (__cplusplus >= 201103L && __cplusplus < 201402L)
    #undef  CXXOMFORT_CXX_STD
    #define CXXOMFORT_CXX_STD 2011
#elif (__cplusplus >= 201402L)
    #undef  CXXOMFORT_CXX_STD
    #define CXXOMFORT_CXX_STD 2014
#endif
*/

/*
 * Detect compilers and apply specific configurations.
 */
#if 0
#elif defined(__clang__)
    #include "./config/clang.hpp"
#elif defined(__GNUC__)
    #include "./config/gcc.hpp"
#elif defined(_MSC_VER)
    #include "./config/msc.hpp"
#else

// this is an unknown / unsupported compiler, assume things just work™.
    #define CXXOMFORT_COMPILER_ID 0
    #define CXXOMFORT_COMPILER_VERSION 0
    #define CXXO_NOTICE(msg) _Pragma(message ("WARNING - " msg))
    #if defined(CXXOMFORT_NOTICES)
        #pragma message CXXO_WARNING("Found an undetermined compiler.")
    #endif
#endif

#if (defined(CXXOMFORT_NOTICES))
    #pragma message CXXO_NOTICE("compiler found : " CXXO_STRINGIZE(CXXOMFORT_COMPILER_ID) "." CXXO_STRINGIZE(CXXOMFORT_COMPILER_VERSION)  )
    #pragma message CXXO_NOTICE("library mode   : ver=" CXXO_STRINGIZE(CXXOMFORT_DATE) " std=" CXXO_STRINGIZE(CXXOMFORT_CXX_STD) ",emu=" CXXO_STRINGIZE(CXXOMFORT_CXX_EMULATION) )

/*
 * Set up more friendly messages
 */
    #if (CXXOMFORT_NOTICES > 1)
    #if (CXXOMFORT_CXX_STD == 2014)
        #pragma message CXXO_NOTICE("detected C++14 or above mode")
    #elif (CXXOMFORT_CXX_STD == 2011)
        #pragma message CXXO_NOTICE("detected C++11 mode")
    #elif (CXXOMFORT_CXX_STD > 1 && CXXOMFORT_CXX_STD < 2011)
        #pragma message CXXO_NOTICE("detected C++03 or basic mode")
    #endif

    #if (CXXOMFORT_CXX_EMULATION == 2011) 
        #pragma message CXXO_NOTICE("running in emulation / c++0x mode (c++11)")
    #elif (CXXOMFORT_CXX_EMULATION == 2014)
        #pragma message CXXO_NOTICE("running in emulation / c++1y mode (c++14)")
    #endif
    
    #endif // friendly notices

#endif

//
// Macros that conditionally generate code for C++11, C++14

#if (CXXOMFORT_CXX_STD < 2011)
    #define CXXOMFORT_CXX11_CODE(cxx11,none) none
    #define CXXOMFORT_CXX14_CODE(cxx14,none) none

#elif (CXXOMFORT_CXX_STD == 2011)
    #define CXXOMFORT_CXX11_CODE(cxx11,none) cxx11
    #define CXXOMFORT_CXX14_CODE(cxx14,none) none


#elif (CXXOMFORT_CXX_STD == 2014)
    #define CXXOMFORT_CXX11_CODE(cxx11,none) none
    #define CXXOMFORT_CXX14_CODE(cxx14,none) cxx14

#endif

//
// Set the local arch name from a series of recognized values
//
#define CXXO_VALUE_ARCH_arm      9000
#define CXXO_VALUE_ARCH_arm64    9064
#define CXXO_VALUE_ARCH_i686    10686
#define CXXO_VALUE_ARCH_i586    10586
#define CXXO_VALUE_ARCH_i486    10486
#define CXXO_VALUE_ARCH_i386    10386
#define CXXO_VALUE_ARCH_ia64    11064
#define CXXO_VALUE_ARCH_amd64   13064


#  if defined(__i686__) || (defined(_M_IX86) && (_M_IX86==600))
    #define CXXOMFORT_ARCHITECTURE CXXO_VALUE_ARCH_i686
#elif defined(__i586__) || (defined(_M_IX86) && (_M_IX86==500))
    #define CXXOMFORT_ARCHITECTURE CXXO_VALUE_ARCH_i586
#elif defined(__i486__) || (defined(_M_IX86) && (_M_IX86==400))
    #define CXXOMFORT_ARCHITECTURE CXXO_VALUE_ARCH_i486
#elif defined(__i386__) || (defined(_M_IX86) && (_M_IX86==300))
    #define CXXOMFORT_ARCHITECTURE CXXO_VALUE_ARCH_i586
#elif defined(__arm__) || defined(_M_ARM) || defined (__thumb__)
    #define CXXOMFORT_ARCHITECTURE CXXO_VALUE_ARCH_arm
#else
    #define CXXOMFORT_ARCHITECTURE 0
#endif

/*
 * Set the location of the default C++ system headers so that they can be
 * #included directly and distinguished from the system wrappers in cstd/
 */
#if defined(_WIN32) && defined(_MSC_VER)
    // MSVC at least contains a folder named 'include' in VC.
    #define CXXO_INCLUDE_SYS(NAME) <../../VC/include/NAME>
    //#define CXXO_INCLUDE_SYS(NAME) <NAME>
    #if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
        #pragma message CXXO_WARNING("Using Windows+MSC include paths")
    #endif
#elif defined(__linux__) || defined(__GNUC__)
    // here we take advantage that the compiler include path contains two
    // subdirectories: bits/ and tr1/
    #define CXXO_INCLUDE_SYS(NAME) <bits/../tr1/../NAME>
    #if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
        #pragma message CXXO_WARNING("Using bits/../tr1/../<version> include paths")
    #endif
#else
    //#warning (" cxxomfort - taking ???? include path")
    // with no better information we just bet that the
    // includes live in the standard directory
    // warning: this might cause an endless #include loop if used with the
    // cstd/ wrapper headers
    #if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
        #pragma message CXXO_WARNING("Using default include paths")
    #endif
    #define CXXO_INCLUDE_SYS(NAME) <NAME>
#endif

//
// ---------------------------------------------------------
//

// Macros to conditionally generate keywords

//
// CXXO_CONSTEXPR
// Evaluates to constexpr where constexpr is supported
#if (CXXOMFORT_CXX_STD < 2011 && CXXO_COMPILER_SUPPORT_constexpr == 0)
#define CXXO_CONSTEXPR
#else
#define CXXO_CONSTEXPR constexpr
#endif

//
// CXXO_NOEXCEPT
// Evaluates to noexcept where noexcept is supported
#if (CXXOMFORT_CXX_STD < 2011 && CXXO_COMPILER_SUPPORT_noexcept == 0)
#define CXXO_NOEXCEPT
#else
#define CXXO_NOEXCEPT noexcept
#endif

//
// CXXO_NOEXCEPTNOTHROW
// Evaluates to noexcept where noexcept is supported, and to throw() in C++03
#if (CXXOMFORT_CXX_STD < 2011 && CXXO_COMPILER_SUPPORT_noexcept == 0)
#define CXXO_NOEXCEPTNOTHROW throw() 
#else
#define CXXO_NOEXCEPTNOTHROW noexcept
#endif

//
// CXXO_NOEXCEPT_COND(...)
// Evaluates to the noexcept of the condition in C++11 onwards, and to nothing in C++03
#if (CXXOMFORT_CXX_STD < 2011 && CXXO_COMPILER_SUPPORT_noexcept == 0)
#define CXXO_NOEXCEPT_COND(...)
#else
#define CXXO_NOEXCEPT_COND(...) noexcept(...)
#endif

//
// ---------------------------------------------------------
//

/*
 * Set up the minimal configuration.
 * This loads three headers whose features are used all across this library.
 */
#include CXXO_INCLUDE_SYS(cstddef) // namespace std, etc
#include CXXO_INCLUDE_SYS(cstdlib) // basic system
#include CXXO_INCLUDE_SYS(iterator) // basics for iterator

#include "config/_has.hpp"
#define _CXXOMFORT_IMPLEMENTS(nn) (( CXXO_JOIN(CXXOMFORT_IMPLEMENTS_n,nn) > 0))
#define CXXOMFORT_IMPLEMENTS(nn) _CXXOMFORT_IMPLEMENTS(nn)

// this command in a shell reveals all nxxxx proposals implemented by this library:
// find -type f -iname '*.hpp' | xargs egrep -o "CXXOMFORT_IMPLEMENTS_n([0-9]+)\b"

/*
 * Utility macro to declare variadic (pseudovariadic in C++03) template members
 */
#include "impl/pseudovariadic.hpp"
 

/*
 * Set up macros for defaulted and deleted members
 * usage:
class Foo {
    private:
    CXXOMFORT_DELETED_COPY_CTOR( Foo );
    public:
    ...
};
 * 
 */

/*
namespace cxxomfort {
#if (CXXO_COMPILER_SUPPORT_default_delete==1)
    #define CXXOMFORT_DEFAULTED_CTOR(FooName) public: FooName () = default
    #define CXXOMFORT_DELETED_CTOR(FooName) public: FooName () = delete
    #define CXXOMFORT_DELETED_COPY_CTOR(FooName) FooName (FooName const&) = delete
    #define CXXOMFORT_DELETED(__VA_ARGS__) private: __VA_ARGS__ = delete

template <class T> class NonCopyable {
    protected:
    NonCopyable () {}
    ~NonCopyable () {} /// Protected non-virtual destructor
    public:
    NonCopyable (const NonCopyable &) = delete;
    NonCopyable & operator = (const NonCopyable &) = delete;
};

#else
    #define CXXOMFORT_DEFAULTED_CTOR(FooName) public: FooName () {}
    #define CXXOMFORT_DELETED_CTOR(FooName) private: FooName ()
    #define CXXOMFORT_DELETED_COPY_CTOR(FooName) private: FooName (FooName const&)
    #define CXXOMFORT_DELETED(...) private: __VA_ARGS__
template <class T> class NonCopyable {
    protected:
    NonCopyable () {}
    ~NonCopyable () {} /// Protected non-virtual destructor
    private:
    NonCopyable (const NonCopyable &);
    NonCopyable & operator = (const NonCopyable &);
};

#endif // default_delete
}
*/

//
// ---------------------------------------------------------
//

//
// Library information
//
namespace cxxomfort {
//! Information about the library support
const struct info { 
    enum {
    //! library version
    version = CXXOMFORT_VERSION , 
    date = CXXOMFORT_DATE, 
    //! compiler identification code
    compilerid = CXXOMFORT_COMPILER_ID ,
    //! compiler version code (usually <code>100*major+minor</code>)
    compilerversion = CXXOMFORT_COMPILER_VERSION ,
    //! value of the standard
    cxx_std = CXXOMFORT_CXX_STD ,
    //! level of support of C++11 features in C++11 emulation / c++0x mode
    cxx_emulation = CXXOMFORT_CXX_EMULATION , 
    cplusplus = __cplusplus
    };
    
    /* struct */ 
} $ = {};

template <typename SS> 
static void output_info (SS& os) {
    os<< "(cxxomfort="<< $.version<< " date="<< $.date<< " compilerid="<< $.compilerid<< " compilerversion="<< $.compilerversion
      << " cplusplus="<< $.cplusplus<< " std="<< $.cxx_std<< " emulation="<< $.cxx_emulation<< " )";
    //return os;
}

#if 0 // uncomment only for diagnostics and wiki work
template <typename SS> 
static void output_info_row (SS& os) {
    using namespace std;
    os<< "    <code>"<< setw(3)<< setfill(' ')<< $.compilerid<< "</code>";
    os<< " <code>"<< setw(4)<< setfill('0')<< $.compilerversion<< setfill(' ')<< "</code>";
    os<< "  </td><td>  <code>"<< setw(4)<< $.cxx_std<< "</code>  </td><td>  <code>"<< setw(4)<< $.cxx_emulation<< "</code>  </td>"
    ;
    //return os;
}
#endif

// ~::cxxomfort
}

#endif
