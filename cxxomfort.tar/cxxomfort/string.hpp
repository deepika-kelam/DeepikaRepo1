#ifndef CXXOMFORT_STRING_HPP
#define CXXOMFORT_STRING_HPP
/**
 * @file cxxomfort/string.hpp
 * @brief Implementations and additions tied to <string>.
 * Interfaces defined in this header:
 *
 * * to_string and others
 *
 */


/**
 * @addtogroup string
 * @{
 */

#include "impl/11-to_string.hpp"
#include "impl/to_basic_string_variadic.hpp"
// #include "impl/string.hpp" // custom string functions

/**
 * @}
 */

#endif
