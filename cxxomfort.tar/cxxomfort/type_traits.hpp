#ifndef CXXOMFORT_TYPE_TRAITS_HPP
#define CXXOMFORT_TYPE_TRAITS_HPP
/**
 * @file cxxomfort/type_traits.hpp
 * @brief Implementations and additions tied to <type_traits>.
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 *
 * Interfaces defined in this header in namespace std:
 * 
 * * @c is_lvalue_reference (in c++03 mode)
 * * @c {add,remove}_lvalue_reference (in c++03 mode)
 * * @c decay  (in c++03 mode)
 * * @c common_type  (in c++03 mode)
 * * @c is_trivially_{default_constructible,copy_constructible,destructible}  (in c++03 mode)
 * * @c is_nothrow_{default_constructible,copy_constructible_destructible} (in c++03 mode)
 * * @c is_trivial , @c is_literal_type
 * * @c is_move_constructible (in c++03 mode)
 * * @c is_null_pointer (from c++14)
 * * @c make_void (from c++17)
 *
 *  * TODO: TR1 fixes for c++03 (eg.: is_trivial) should go to a separate forwarding library.
 * 
 */

#include "utility.hpp" // declval
#include <type_traits>
#include "util/type_traits.hpp"
#include "using.hpp" // bring TR1 in

#if (defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1))
#pragma message CXXO_NOTICE("enabled <type_traits> support.")
#endif


/*
 * TR1 traits missing in c++03 in implementations 
 * is_literal_type, is_trivial, etc
 */


#if 0
#elif (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_GCC)

    #if (!defined(__GXX_EXPERIMENTAL_CXX0X__) )
        #define CXXO_LACKS_make_signed 1
    #endif
#elif (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_CLANG)
    #if (CXXOMFORT_CXX_STD < 2011)
        #define CXXO_LACKS_make_signed 1
    #endif
#else 
#endif

#if defined(CXXO_LACKS_make_signed)
namespace std { namespace tr1 {
    using cxxomfort::traits::make_signed;
    using cxxomfort::traits::make_unsigned;
} }
#endif // bring missing make_signed, make_unsigned to tr1


//
// lvalue_reference traits mirrored in C++03 mode
//

#if (CXXOMFORT_CXX_STD < 2011 && CXXOMFORT_CXX_EMULATION == 0)
    #define CXXO_MIRROR_LVALUE_REFERENCE
#else
    #if (defined(__GNUC__) && !defined(__GXX_EXPERIMENTAL_CXX0X__))
        #define CXXO_MIRROR_LVALUE_REFERENCE
    #endif
#endif
#if defined(CXXO_MIRROR_LVALUE_REFERENCE)
namespace std {
    template <typename T> struct is_lvalue_reference
    : std::tr1::is_reference<T> {};
    
    template <typename T>
    struct add_lvalue_reference
    : std::tr1::add_reference<T> {};

    template <typename T>
    struct remove_lvalue_reference
    : std::tr1::remove_reference<T> {};


    template <typename T>
    struct is_rvalue_reference { static const bool value = false; };

}
#endif
#undef CXXO_MIRROR_LVALUE_REFERENCE

/*
 * decay for C++03
 */

#if ( (CXXOMFORT_CXX_STD < 2011) && (CXXOMFORT_CXX_EMULATION == 0 ) )
namespace std {
template< typename T >
struct decay {
    private:
    typedef typename std::remove_reference<T>::type U;
    public:
    typedef typename std::conditional< 
        std::is_array<U>::value,
        typename std::remove_extent<U>::type*,
        typename std::conditional< 
            std::is_function<U>::value,
            typename std::add_pointer<U>::type,
            typename std::remove_cv<U>::type
        >::type
    >::type type;
};


}
#endif

/*
 * Triviality / Throwness traits
 * (is_trivially_..., is_nothrow_...)
 * 
 */
#include "util/traits_tn.hpp"

//
// is_trivially_... missing in GCC 4.7 despite announcing C++11 mode
//

#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC && CXXOMFORT_COMPILER_VERSION==407 && CXXOMFORT_CXX11_EMULATION>0)
namespace std {
    template <typename T> struct is_trivially_default_constructible
    : integral_constant<bool, __has_trivial_constructor(T)> {};

    template <typename T> struct is_trivially_copy_constructible
    : integral_constant<bool, __has_trivial_copy(T)> {};

    template <typename T> struct is_trivially_move_constructible
    : integral_constant<bool, is_scalar<T>::value > {};

    template <typename T> struct is_trivially_copy_assignable 
    : integral_constant<bool, __has_trivial_assign(T)> {};

    template <typename T> struct is_trivially_destructible
    : integral_constant<bool, __has_trivial_destructor(T)> {};

}
#endif

/*
 * Common_type
 */
#include "util/traits_ct.hpp"


#if 0 // -- is_constructible
//
// "variadic" is_constructible, is_assignable implementation
//

//#include "impl/is_constructible.hpp"


namespace cxxomfort {
namespace detail {

    template<std::size_t N>
    struct dummy;
    
    typedef struct { char a; } yes_t;
    typedef struct { char b[2]; } no_t;


#if defined(_MSC_VER)
// MSVC does not support the SFINAE required for the constructor expressions 
// to work (error C2564 function-style conversion takes only one argument)
// so for MSVC we just make the is_constructible traits return false 
// for all >1-argument cases.
// At most what we can do is to provide a couple of specializations, 
// given we are implementors and thus are not limited by 
// the specializations rule on namespace std.

#define CONSTRUCTIBLE_IMPL_FORM_BEGIN(...) \
    
#define CONSTRUCTIBLE_IMPL_FORM_END(...) \
    public:           \
    static const bool value = sizeof(test< __VA_ARGS__ >(0)) \
    == sizeof(yes_t); \


template <typename T, typename A1, typename A2, typename A3, typename A4, typename A5>
struct constructible5 : false_type {};

template <typename T, typename A1, typename A2, typename A3, typename A4>
struct constructible4 : false_type {};

template <typename T, typename A1, typename A2, typename A3>
struct constructible3 : false_type {};

template <typename T, typename A1, typename A2>
struct constructible2 : false_type {};

template<typename T, typename A1>
struct constructible1 {
    CONSTRUCTIBLE_IMPL_FORM_BEGIN();

    template<typename Tp1, typename Arg1_>
    static typename
    std::enable_if<(sizeof(Tp1( declval<Arg1_>()), 1) > 0), yes_t>::type test(int);

    template<typename, typename>
    static no_t test(...);

    CONSTRUCTIBLE_IMPL_FORM_END(T,A1);
};

template <typename T>
struct constructible0 {
    CONSTRUCTIBLE_IMPL_FORM_BEGIN();

    template<typename Tp1>
    static typename
    std::enable_if<(sizeof(Tp1(), 1) > 0), yes_t>::type test(int);

    template<typename, typename>
    static no_t test(...);

    CONSTRUCTIBLE_IMPL_FORM_END(T);
};


template<typename T, typename Arg1>
struct assignable {
    //typedef typename std::add_const<Arg1>::type A1Const;

    template<typename Tp1, typename Arg1_>
    static typename
    std::enable_if<(sizeof(declval<Tp1>()= declval<Arg1_>(), 1) > 0), yes_t>::type test(int);

    template<typename, typename>
    static no_t test(...);

    public:
    static const bool value = sizeof(test<T, Arg1>(0)) == sizeof(yes_t);
};

#else
// not on MSVC

#define CONSTRUCTIBLE_IMPL_FORM_BEGIN()          \
    template <typename X>                        \
    static yes_t                                 \
    test(dummy<sizeof(     \

#define CONSTRUCTIBLE_IMPL_FORM_END()            \
    )>*);                                        \
                                                 \
    template<typename X>                         \
    static no_t                                  \
    test(...);                                   \
                                                 \
    static const bool value = sizeof(            \
        test<T>(0)) == sizeof(yes_t);               \
    typedef ::cxxomfort::traits::                \
        integral_constant<bool,value> type;      \


template <typename T, typename A1, typename A2, typename A3, typename A4, typename A5>
struct constructible5 {
    CONSTRUCTIBLE_IMPL_FORM_BEGIN()
    (X) ( std::declval<A1>(), std::declval<A2>(), std::declval<A3>(), std::declval<A4>(), std::declval<A5>() )
    CONSTRUCTIBLE_IMPL_FORM_END();
};

template <typename T, typename A1, typename A2, typename A3, typename A4>
struct constructible4 {
    CONSTRUCTIBLE_IMPL_FORM_BEGIN()
    (X) ( std::declval<A1>(), std::declval<A2>(), std::declval<A3>(), std::declval<A4>() )
    CONSTRUCTIBLE_IMPL_FORM_END();
};

template <typename T, typename A1, typename A2, typename A3>
struct constructible3 {
    CONSTRUCTIBLE_IMPL_FORM_BEGIN()
    (X) ( std::declval<A1 const>(), std::declval<A2 const>(), std::declval<A3 const>() )
    CONSTRUCTIBLE_IMPL_FORM_END();
};

template <typename T, typename A1, typename A2>
struct constructible2 {
    CONSTRUCTIBLE_IMPL_FORM_BEGIN()
    X ( std::declval<A1 const>(), std::declval<A2 const>() )
    CONSTRUCTIBLE_IMPL_FORM_END();
};

template <typename T, typename A1>
struct constructible1 {
    CONSTRUCTIBLE_IMPL_FORM_BEGIN()
    X ( std::declval<A1 const>() )
    CONSTRUCTIBLE_IMPL_FORM_END();
};

template <typename T, typename U>
struct assignable {
    CONSTRUCTIBLE_IMPL_FORM_BEGIN()
    std::declval<X>() = std::declval<X>()
    CONSTRUCTIBLE_IMPL_FORM_END()
};

#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC && CXXOMFORT_COMPILER_VERSION<406)
template <typename U> struct assignable<void,U> {
    static const bool value= false;
};
#endif

template <typename T>
struct constructible0 {
    CONSTRUCTIBLE_IMPL_FORM_BEGIN()
    X
    CONSTRUCTIBLE_IMPL_FORM_END();
};



#endif



#undef CONSTRUCTIBLE_IMPL_FORM_BEGIN
#undef CONSTRUCTIBLE_IMPL_FORM_END

}
} cxxomfort::

#endif // -- is_constructible


/*
 * is_null_pointer (was added in C++14)
 */
#if ( (CXXOMFORT_CXX_STD < 2014) ) 
    #define CXXO_enable_is_null_pointer
#endif
#if (defined(CXXO_enable_is_null_pointer) && CXXOMFORT_CXX_STD == 2011 && CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_CLANG)
    #undef CXXO_enable_is_null_pointer
#endif
#if (defined(CXXO_enable_is_null_pointer) && CXXOMFORT_CXX_EMULATION == 2011 && CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC)
    #undef CXXO_enable_is_null_pointer
#endif

#if (defined(CXXO_enable_is_null_pointer))
namespace std {
    using ::cxxomfort::traits::is_null_pointer;
}
#endif


/*
 * make_void (c++17)
 */
#include "impl/17-void_t.hpp"


/*
 * is_move_constructible for C++03, we seek for RV_REF constructors
 */

#if (CXXOMFORT_CXX_STD < 2011) \
|| /* also missing in clang in C++11 mode */ \
(CXXOMFORT_CXX_STD==2011 && CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_CLANG && CXXOMFORT_COMPILER_VERSION<=304)  \
|| /* also missing in gcc in C++11 mode */ \
(CXXOMFORT_CXX_EMULATION==2011 && CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC && CXXOMFORT_COMPILER_VERSION<=408)

namespace std {
    template <typename T>
    struct is_trivially_move_constructible 
    : std::is_scalar<T> {};

}
#endif

#if (CXXOMFORT_CXX_STD < 2011)
namespace std {
    template <typename T>
    struct is_nothrow_move_constructible
    : std::is_scalar<T> {};

}
#endif

/*
 * is_move_constructible
 */
#if (CXXOMFORT_CXX_STD < 2011)
namespace std {
    template <typename T>
    struct is_move_constructible 
    : std::integral_constant<bool, 
        is_scalar<T>::value && !(is_same<T,void>::value) 
    > {};

}
#endif



//
// underlying_type
//
#include "various.hpp" // integral_of_size

#if 0
#elif (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_GCC)
    // Add underlying_type approximation for GCC < 4.7 in any mode
    // see http://stackoverflow.com/questions/9343329/how-to-know-underlying-type-of-class-enum/10956467#10956467
    #if (CXXOMFORT_COMPILER_VERSION < 407)
        #define CXXOMFORT_USING_underlying_type 1
    #elif (CXXOMFORT_COMPILER_VERSION >= 407 && CXXOMFORT_CXX_STD < 2011 )
        #define CXXOMFORT_USING_underlying_type 1
    #endif
#elif (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_CLANG)
    #if (CXXOMFORT_CXX_STD >= 2011)
    #else
        #define CXXOMFORT_USING_underlying_type 1
    #endif

#endif // support for underlying_type

#if defined(CXXOMFORT_USING_underlying_type)
    #include <type_traits>
    #if defined (CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
        #pragma message CXXO_WARNING( " cxxomfort library - enabled underlying_type helper" )
    #endif

    namespace std {
    template< typename TpEnum >
    struct underlying_type {
        typedef typename ::cxxomfort::integral_of_size<sizeof(TpEnum)>::type tsize_t;
        typedef typename std::conditional<
            (TpEnum( -1 ) < TpEnum( 0 )),
            typename std::make_signed< tsize_t >::type,
            typename std::make_unsigned< tsize_t >::type
            >::type type;
    };

    }

#else // At this point there should be full C++11 support for underlying_type
#endif // underlying_type

#endif // #include guard
