#ifndef CXXOMFORT_FORWARD_LIST_HPP
#define CXXOMFORT_FORWARD_LIST_HPP
/**
 * @file cxxomfort/extras/forward_list.hpp
 * @brief Implements C++11's "forward_list" in C++03.
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 *
 * Interfaces defined in this header:
 *
 * * forward_list (from C++11)
 * 
 * This header contains a partial implementation of C++11's 
 * "forward_list" sequence container based off my old code for a former 
 * "ListaEnlazada" class.
 * 
 * To invoke this in a standard manner, the header @c <forward_list> is 
 * provided in cstd/ directory.
 * 
 * 
**/
// An implementation of forward_list<> based off 
// my former ListaEnlazada class.
//
// Dependencies:
//  * cxxomfort
//  * allocator_traits en TR1

#include <cxxomfort/config.hpp>
#include <cxxomfort/base.hpp>
#include <stdexcept>
#include <iterator>
#include <memory>

namespace cxxomfort {

namespace detail_fwlist {
    struct sl_node_base { 
        sl_node_base *next;
        sl_node_base () : next(nullptr) {}
        sl_node_base (sl_node_base * p) : next(p) {}
    };
    template <typename T> struct sl_node;
    template <typename T, bool> class iterator_base;
}

/**
 * @brief Implementation of C++11's forward_list , made compatible with C++03.
 * @addtogroup forward_list
 * 
 * Differences from the standard's provided:
 * 
 * * Operator move-assignment is not available.
 * * Members merge, sort, unique and resize are not yet available.
 * * A member push_back is provided, which allows for tail insertion in O(1) time.
 * * Relational operators other than (in)equality are not provided.
 * 
 */

template <typename T, typename A = std::allocator<T> >
class forward_list {
    private:
    typedef detail_fwlist::sl_node_base   node_t;
    typedef detail_fwlist::sl_node<T>     nodeT_t;
    typedef typename A::template rebind<nodeT_t>::other node_alloc_t;
    typedef std::allocator_traits<node_alloc_t> alloc_traits;


    public:
    typedef typename A::size_type size_type;
    typedef ptrdiff_t difference_type;
    typedef T                 value_type;
    typedef A                 allocator_type;
    typedef value_type&       reference;
    typedef const value_type& const_reference;
    typedef typename std::allocator_traits<A>::pointer pointer;
    typedef typename std::allocator_traits<A>::const_pointer const_pointer;
    typedef detail_fwlist::iterator_base<T,false>    iterator;
    typedef detail_fwlist::iterator_base<T,true>     const_iterator;

    private:
    CXXO_COPYABLE_MOVABLE(forward_list);
    
    public:
    forward_list () CXXO_NOEXCEPT;                //< default-ctor
    forward_list (forward_list const&);           //< copy-ctor
    forward_list (forward_list const&, A const&); //< realloc copy constructor
    explicit forward_list 
    (size_t, T const& t= T(), A const& a = A());  //< element-ctor
    template <typename I> forward_list 
    (I, I, A const& a = A());                     //< sequence-ctor
    forward_list (CXXO_RV_REF(forward_list));     //< move-ctor
#if defined(CXXOMFORT_CXX11_MODE)
    explicit forward_list (std::initializer_list<T> const&);          //< init-list-ctor
#endif
    ~forward_list ();                             //< destructor

    forward_list& operator= 
    (CXXO_COPY_ASSIGN_REF(forward_list));                   //< copy-assignment
    forward_list& operator= (CXXO_RV_REF(forward_list));    //< move-assignment
#if defined(CXXOMFORT_CXX11_MODE)
    forward_list& operator= (init_list_t);        //< init-list assignment
#endif

    void  assign (size_type, T const&); //< assign multiple copies of a value
    template <typename Iterator>
    void  assign (Iterator,Iterator);   //< assign a sequence
#if defined(CXXOMFORT_CXX11_MODE)
    void  assign (std::initializer_list<T> const&);    //< assign a init-list
#endif
    
    allocator_type  get_allocator () const;  //< direct access to allocator
    
    bool       empty () const;          //< check if empty
    //size_t     size () const;           //< current size; not in std
    size_type  max_size () const;       //< max size

    const_reference front () const;     //< direct access to front
    reference       front ();           //< direct access to front
    
    const_iterator  cbegin () const CXXO_NOEXCEPT;     //< read-only iteration from begin
    const_iterator  begin ()  const CXXO_NOEXCEPT { return cbegin(); }
    const_iterator  cend ()   const CXXO_NOEXCEPT;     //< read-only iteration mark end
    const_iterator  end ()    const CXXO_NOEXCEPT { return cend(); }
    iterator        begin () CXXO_NOEXCEPT;            //< mutating iteration from begin
    iterator        end ()   CXXO_NOEXCEPT;            //< mutating iteration mark end
    
    //const_iterator  cbefore_begin () const;  //< read-only iteration mark before begin
    const_iterator  before_begin () const CXXO_NOEXCEPT;    //< read-only iteration mark before begin
    iterator        before_begin () CXXO_NOEXCEPT;          //< mutating iteration mark before begin

    void  push_front (T const&);        //< insert at begin
    void  push_front (CXXO_RV_REF(T));  //< insert at begin (by move)
    void  push_back (T const&);         //< insert at end, constant time; not in std
//    void  push_back (CXXO_RV_REF(T));   // insert at end, constant time (by move); not in std
    void  pop_front ();                 //< erase at begin

    CXXO_PSEUDOVARIADIC_MEMBER(void , emplace_front , );

    iterator   insert_after (const_iterator, T const&);          //< insert
    iterator   insert_after (const_iterator, CXXO_RV_REF(T));    //< insert (by move)
    iterator   insert_after (const_iterator, size_type, T const&);    //< insert multiple copies
    template< class I >
    iterator   insert_after (const_iterator pos, I ini, I fin);  //< insert a sequence
#if (CXXOMFORT_CXX_STD >= 2011)
    iterator   insert_after (const_iterator, std::initializer_list<T> const&);         //< insert a init-list
#else

#endif

    // emplace_after( p, ...)

    iterator   erase_after (const_iterator);           //< erase after position
    iterator   erase_after (const_iterator, const_iterator);     //< erase a sequence of elements

    void       clear ();                //< erase everything - return to defaulted state
    void       swap (forward_list&);    //< swap contents with another list

#if 0 // pending
    void       resize (size_type);
    void       resize (size_type, T const&);
    
    void  merge (forward_list&);
    void  merge (CXXO_RV_REF(forward_list));
    template <typename Compare>
    void  merge (forward_list&, Compare);
    template <typename Compare>
    void  merge (CXXO_RV_REF(forward_list), Compare);
    
    void  splice (const_iterator, forward_list&);
    void  splice (const_iterator, forward_list&, const_iterator src);
    void  splice (const_iterator, forward_list&, const_iterator ini, const_iterator fin); 
#endif

    void       splice_after (const_iterator, forward_list &); // 1
    void       splice_after (const_iterator, forward_list &, const_iterator); // 2
    
    void       remove (T const&);
    template <typename Cond>
    void       remove_if (Cond c);

#if 0 // pending
    void  sort ();  
    template <typename Compare>
    void  sort (Compare);

    void  reverse ();
    
    void  unique ();
    template <typename Compare>
    void  unique (Compare);
#endif    

    private:
    node_t          _p_bb, *_p_last;
    node_alloc_t    alloc;

    static nodeT_t *N (node_t* p) { return static_cast<nodeT_t*>(p); }
    static node_t  *U (nodeT_t *p) { return static_cast<node_t*>(p); }

    node_t*    insert_after (node_t *p, T const&);
    node_t*    in_unlink_after (node_t *p);

    template <typename I> void in_uninitialized_copy(I,I);

    void            in_uninitialized_fill_n (size_t, T const&);
    void            in_link_after (node_t*, node_t*);
    void            in_readjust_last ();
    node_t*    in_destroy (nodeT_t*);
    
} /* forward_list */ ;

template <typename T1, typename A1, typename T2, typename A2>
bool operator== (forward_list<T1,A1> const& a, forward_list<T2,A2> const& b);

template <typename T1, typename A1, typename T2, typename A2>
bool operator!= (forward_list<T1,A1> const& a, forward_list<T2,A2> const& b);


} // cxxomfort::

#include "impl/forward_list-impl.hpp"


#endif
