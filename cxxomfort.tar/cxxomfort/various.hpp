#ifndef CXXOMFORT_UTILITIES_HPP
#define CXXOMFORT_UTILITIES_HPP
/**
 * @file cxxomfort/utilities.hpp
 * @author Luis Machuca Bezzaza
 * @brief Implements a set of library-specific utilities for cxxomfort, 
 * not mapped to C++03 or C++11 facilities.
 * 
 * ==No other base cxxomfort feature should depend on these utilities==
 * 
 * Interfaces defined in this file:
 * 
 * * is_any
 * * is_pair
 * * integer_of_size
 * * static_and, static_or
 * * function_arity
 * * result_of_function
 * * invoke_tuple_t
 * 
 */

#include "config.hpp"
#include "base.hpp"   // sized integer types
#if defined (CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
#pragma message CXXO_NOTICE("enabled various built-in utilities")
#endif
//////////////////////////////////////////////////
// The purpose of the utilities here is, for the most part, to assist in 
// choosing types or functions programatically for the types of objects, 
// so as to avoid depending on "auto"-like features to make code readable
// (and writable!).

namespace cxxomfort {
//! Inherits from @c true_type  if @p T  is a <code>std::pair</code>.
template <typename T> struct is_pair: std::false_type {};
template <typename A, typename B> struct is_pair< std::pair<A,B> >: std::true_type {};
}


/*
 * integral_of_size
 * 
 * @brief Query if an integral with the given size exists
 * 
 */

namespace cxxomfort {

template <unsigned S> struct integral_of_size { 
    static const bool value = false; 
    typedef void type; 
};

template <> struct integral_of_size<sizeof(char)> { 
    static const bool value= true;
    typedef int8_t type; 
};
template <> struct integral_of_size<sizeof(int16_t)> { 
    static const bool value= true;
    typedef int8_t type; 
};
template <> struct integral_of_size<sizeof(int32_t)> { 
    static const bool value= true;
    typedef int32_t type; 
};
template <> struct integral_of_size<sizeof(int64_t)> { 
    static const bool value= true;
    typedef int32_t type; 
};

} //cxxomfort::


#include "util/type_traits.hpp"
#include "util/meta.hpp"      // enable_if, etc...
#include "utility.hpp"
#include "using.hpp"


/*
 * is_any_of
 */
namespace cxxomfort {

#if (CXXOMFORT_CXX_STD >= 2011 || CXXO_COMPILER_SUPPORT_variadic==1)
template<typename T, typename... Rest>
struct is_any_of : std::false_type {};

template<typename T, typename First>
struct is_any_of<T, First> 
: std::is_same<T, First> {};

template<typename T, typename First, typename... Rest>
struct is_any_of<T, First, Rest...>
: std::integral_constant<bool, std::is_same<T, First>::value || is_any_of<T, Rest...>::value> {};

#else

template <typename T, typename T0, typename T1=void, typename T2=void, typename T3=void, typename T4=void, typename T5=void, typename T6=void, typename T7=void, typename T8=void, typename T9=void>
struct is_any_of
: std::integral_constant<bool, std::is_same<T,T0>::value || is_any_of<T, T1,T2,T3,T4,T5,T6,T7,T8,T9>::value> {};


template <typename T, typename T0>
struct is_any_of<T,T0> : std::is_same<T,T0> {};

#endif

} //cxxomfort::



/*
 * static_if_all, static_if_any
 * @brief Given T and a list of traits Traits..., check if T instantiates all / anyTraits... to true_type
 */

namespace cxxomfort {

#if (CXXOMFORT_CXX_STD >= 2011)
/*
template <typename T, template <typename> class Trait1, template <typename> class... Traits>
struct static_if_all {
    static const bool value = Trait1<T>::value and static_if_all<T,Traits...>::value;
};

template <typename T, template <typename> class Trait1>
struct static_if_all<T,Trait1> {
    static const bool value = Trait1<T>::value;
};


template <typename T, template <typename> class Trait1, template <typename> class... Traits>
struct static_if_any {
    static const bool value = Trait1<T>::value or static_if_all<T,Traits...>::value;
};

template <typename T, template <typename> class Trait1>
struct static_if_any<T,Trait1> {
    static const bool value = Trait1<T>::value;
};
*/

template <typename Tr1, typename... Traits>
struct static_all_of
: std::integral_constant<bool, (Tr1::value and static_all_of<Traits...>::value)> {
};


template <typename Tr1, typename Tr2>
struct static_all_of<Tr1,Tr2>
: std::integral_constant<bool, (Tr1::value and Tr2::value)> {
};

template <typename Tr1, typename... Traits>
struct static_if_any
: std::integral_constant<bool, (Tr1::value or static_if_any<Traits...>::value)> {
};

template <typename Tr1, typename Tr2>
struct static_if_any<Tr1,Tr2>
: std::integral_constant<bool, (Tr1::value or Tr2::value)> {
};

#else

template <typename Tr1, typename Tr2, typename Tr3=std::false_type, typename Tr4=std::false_type, typename Tr5=std::false_type>
struct static_if_all
: std::integral_constant<bool, (Tr1::value and Tr2::value and Tr3::value and Tr4::value and Tr5::value)> {
};

template <typename Tr1, typename Tr2, typename Tr3=std::false_type, typename Tr4=std::false_type, typename Tr5=std::false_type>
struct static_if_any
: std::integral_constant<bool, (Tr1::value or Tr2::value or Tr3::value or Tr4::value or Tr5::value)> {
};

#endif

} // cxxomfort::


namespace cxxomfort {

#if (CXXOMFORT_CXX_STD >= 2011)
/*
 * compose <int&, add_const, remove_reference>
 * would evaluate to:
 * add_const<int&>::type --> T1
 * then remove_reference<T1>::type --> type
 */
template <typename T, template <typename> class Conv1, template <typename> class... Conversions>
struct static_compose {
    private:
    typedef typename Conv1<T>::type T1;
    public:
    typedef typename static_compose<T1,Conversions...>::type type;
};

template <typename T, template <typename> class Conv1>
struct static_compose<T,Conv1> {
    typedef typename Conv1<T>::type type;
};

#endif

}



#if 0
//
// piecewise tuple constructor for cxxomfort pair
//
#include "utility.hpp"
#include <tuple>

namespace cxxomfort {


#define _Ty(X) typename X##0, typename X##1, typename X##2, typename X##3, typename X##4, typename X##5, typename X##6, typename X##7, typename X##8, typename X##9 

namespace detail_pair_piecewise {

template <typename T, typename Tuple, size_t Size> struct builder;

template <typename T, typename Tuple> struct builder<T,Tuple,0> {
    builder (Tuple const& v) : v_(v) {}
    operator T () const {
        return T( );
    }
    Tuple const& v_;
};

template <typename T, typename Tuple> struct builder<T,Tuple,1> {
    builder (Tuple const& v) : v_(v) {}
    operator T () const {
        using std::get;
        return T( get<0>(v_) );
    }
    Tuple const& v_;
};

template <typename T, typename Tuple> struct builder<T,Tuple,2> {
    builder (Tuple const& v) : v_(v) {}
    operator T () const {
        using std::get;
        return T( get<0>(v_) , get<1>(v_) );
    }
    Tuple const& v_;
};

template <typename T, typename Tuple> struct builder<T,Tuple,3> {
    builder (Tuple const& v) : v_(v) {}
    operator T () const {
        using std::get;
        return T( get<0>(v_) , get<1>(v_) , get<2>(v_) );
    }
    Tuple const& v_;
};

template <typename T, typename Tuple> struct builder<T,Tuple,4> {
    builder (Tuple const& v) : v_(v) {}
    operator T () const {
        using std::get;
        return T( get<0>(v_) , get<1>(v_) , get<2>(v_), get<3>(v_) );
    }
    Tuple const& v_;
};

template <typename T, typename Tuple> struct builder<T,Tuple,5> {
    builder (Tuple const& v) : v_(v) {}
    operator T () const {
        using std::get;
        return T( get<0>(v_) , get<1>(v_) , get<2>(v_), get<3>(v_), get<4>(v_) );
    }
    Tuple const& v_;
};

}

template <typename A, typename B>
template <typename Tuple1, typename Tuple2>
pair<A,B>::pair (
/*typename std::enable_if
        < is_tuple<Tuple1>::value && is_tuple<Tuple2>::value, piecewise_construct_t
        >::type
*/ piecewise_construct_t
    , Tuple1 tp, Tuple2 tq)
: first( detail_pair_piecewise::builder<A, Tuple1, std::tuple_size<Tuple1>::value>(tp))
, second(detail_pair_piecewise::builder<B, Tuple2, std::tuple_size<Tuple2>::value>(tq))
{
}


#undef _Ty


} //cxxomfort::

#endif



//
// function_return_type
// (because result_of does not take plain function types)
//

namespace cxxomfort {
template <typename Sig> struct result_of_function ;

template <typename R> struct result_of_function<R()> {
    typedef R type;
};

template <typename R, typename A1> struct result_of_function<R(A1)>
: result_of_function<R()> {};
template <typename R, typename A1, typename A2> struct result_of_function<R(A1,A2)>
: result_of_function<R()> {};
template <typename R, typename A1, typename A2, typename A3> 
struct result_of_function<R(A1,A2,A3)> : result_of_function<R()> {};
template <typename R, typename A1, typename A2, typename A3, typename A4> 
struct result_of_function<R(A1,A2,A3,A4)> : result_of_function<R()> {};
template <typename R, typename A1, typename A2, typename A3, typename A4, typename A5> 
struct result_of_function<R(A1,A2,A3,A4,A5)> : result_of_function<R()> {};
template <typename R, typename A1, typename A2, typename A3, typename A4, typename A5, typename A6> 
struct result_of_function<R(A1,A2,A3,A4,A5,A6)> : result_of_function<R()> {};
template <typename R, typename A1, typename A2, typename A3, typename A4, typename A5, typename A6, typename A7> 
struct result_of_function<R(A1,A2,A3,A4,A5,A6,A7)> : result_of_function<R()> {};
template <typename R, typename A1, typename A2, typename A3, typename A4, typename A5, typename A6, typename A7, typename A8> 
struct result_of_function<R(A1,A2,A3,A4,A5,A6,A7,A8)> : result_of_function<R()> {};
template <typename R, typename A1, typename A2, typename A3, typename A4, typename A5, typename A6, typename A7, typename A8, typename A9> 
struct result_of_function<R(A1,A2,A3,A4,A5,A6,A7,A8,A9)> : result_of_function<R()> {};
template <typename R, typename A1, typename A2, typename A3, typename A4, typename A5, typename A6, typename A7, typename A8, typename A9, typename B0> 
struct result_of_function<R(A1,A2,A3,A4,A5,A6,A7,A8,A9,B0)> : result_of_function<R()> {};

}


/*
//
// Given a STL iterator, obtain where possible the type of the container
//

template <typename Iterator>
struct container_of_iterator {};

template <typename T>
struct container_of_iterator< std::deque<T>::iterator> {
    typedef std::deque<T> type;
};
template <typename T>
struct container_of_iterator< std::list<T>::iterator> {
    typedef std::list<T> type;
};
template <typename T>
struct container_of_iterator< std::vector<T>::iterator> {
    typedef std::vector<T> type;
};
template <typename T>
struct container_of_iterator< std::set<T>::iterator> {
    typedef std::set<T> type;
};
template <typename T>
struct container_of_iterator< std::valarray<T>::iterator> {
    typedef T* type;
};
*/


#endif //
