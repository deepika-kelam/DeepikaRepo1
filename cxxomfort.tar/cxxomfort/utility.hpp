#ifndef CXXOMFORT_UTILITY_HPP
#define CXXOMFORT_UTILITY_HPP
/**
 * @file cxxomfort/utility.hpp
 * @brief Implementations and additions tied to <utility>.
 * 
 * Interfaces defined in this file:
 * 
 * * declval
 * * exchange
 * * move (from util/move)
 * * forward (from util/move)
 * * as_const (from c++17)
 * 
 * Interfaces reflected in namespace @b std : 
 * 
 * * declval
 * * exchange
 * * as_const 
 * 
 */

#include "base.hpp"   // move, forward
#include "util/meta.hpp"
#include "util/type_traits.hpp"
#include <type_traits>

#if (defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1))
#pragma message CXXO_NOTICE("enabled <utility> support.")
#endif


namespace cxxomfort {
/**
 * @addtogroup utility 
 * @{
 */


/**
 * @}
 */
}

namespace cxxomfort {
    //! @ingroup utility
    //! @ingroup cxx03-backports
    template <typename T> typename cxxomfort::traits::add_reference<T>::type declval();
}

#if (CXXOMFORT_CXX_STD < 2011)
    #if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_MSC && CXXOMFORT_COMPILER_VERSION==150)
    // MSVC 2010 does not ship with a declval
        #define CXXO_ADD_declval 
    #elif (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC)
        #if (CXXOMFORT_CXX_EMULATION<2011)
            #define CXXO_ADD_declval
        #endif
    #else
        #define CXXO_ADD_declval
    #endif
    #if defined(CXXO_ADD_declval)
namespace std { 
    using ::cxxomfort::declval;
} //std::
        #undef CXXO_ADD_declval
    #endif

#endif
#define CXXOMFORT_IMPLEMENTS_n1978 CXXO_BACKPORT()
#define CXXOMFORT_IMPLEMENTS_n2343 CXXO_BACKPORT()


#include "impl/n3668_exchange.hpp"
#include "impl/14-integer_sequence.hpp"
#include "impl/17-as_const.hpp"

#endif
