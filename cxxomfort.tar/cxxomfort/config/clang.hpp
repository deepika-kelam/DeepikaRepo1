#ifndef CXXOMFORT_CONFIG_CLANG_HPP
#define CXXOMFORT_CONFIG_CLANG_HPP
#ifndef CXXOMFORT_CONFIG_HPP
    #error "This file must not be included directly (see cxxomfort/config.hpp)"
#endif

/*
Here follows a list of C++11 features for Clang:

TODO
 */

#define CXXOMFORT_COMPILER_ID CXXO_VALUE_COMPILER_CLANG
#define CXXOMFORT_COMPILER_VERSION 100*__clang_major__+__clang_minor__

#define CXXO_PRAGMA(x) _Pragma (#x)
//#define CXXO_NOTICE(msg) GCC message (" cxxomfort warning -- " msg )
//#define CXXO_WARNING(msg) CXXO_NOTICE_IMPL_( "cxxomfort warning: " msg)

#define CXXO_NOTICE_IMPL_(msg) msg
#define CXXO_NOTICE(msg) CXXO_NOTICE_IMPL_( "cxxomfort notice: " msg)
#define CXXO_WARNING(msg) CXXO_NOTICE_IMPL_( "cxxomfort warning: " msg)

#if defined(CXXOMFORT_NOTICES)
    #pragma CXXO_NOTICE("Found the Clang C++ Compiler.")
#endif

#undef  CXXO_COMPILER_SUPPORT_alignof
#define CXXO_COMPILER_SUPPORT_alignof 1
#undef  CXXO_COMPILER_SUPPORT_alignment_tools
#define CXXO_COMPILER_SUPPORT_alignment_tools __has_extension(cxx_alignas)
#undef  CXXO_COMPILER_SUPPORT_attribute
#define CXXO_COMPILER_SUPPORT_attribute __has_extension(cxx_attributes)
#undef  CXXO_COMPILER_SUPPORT_auto
#define CXXO_COMPILER_SUPPORT_auto __has_extension(cxx_auto_type)
#undef  CXXO_COMPILER_SUPPORT_constexpr
#define CXXO_COMPILER_SUPPORT_constexpr __has_extension(cxx_constexpr)
#undef  CXXO_COMPILER_SUPPORT_decltype
#define CXXO_COMPILER_SUPPORT_decltype __has_extension(cxx_decltype_incomplete_return_types)
#undef  CXXO_COMPILER_SUPPORT_default_delete
#define CXXO_COMPILER_SUPPORT_default_delete (__has_extension(cxx_defaulted_functions) * __has_extension(cxx_deleted_functions))
#undef  CXXO_COMPILER_SUPPORT_enum_class
#define CXXO_COMPILER_SUPPORT_enum_class __has_extension(cxx_strong_enums)
#undef  CXXO_COMPILER_SUPPORT_explicit_operator
#define CXXO_COMPILER_SUPPORT_explicit_operator __has_extension(cxx_explicit_conversions)
#undef  CXXO_COMPILER_SUPPORT_foreach
#define CXXO_COMPILER_SUPPORT_foreach __has_extension(cxx_range_for)
#undef  CXXO_COMPILER_SUPPORT_initializer_list
#define CXXO_COMPILER_SUPPORT_initializer_list __has_extension(cxx_inheriting_constructors)
#undef  CXXO_COMPILER_SUPPORT_local_types
#define CXXO_COMPILER_SUPPORT_local_types __has_extension(cxx_local_type_template_args)
#undef  CXXO_COMPILER_SUPPORT_noexcept
#define CXXO_COMPILER_SUPPORT_noexcept __has_extension(cxx_noexcept)
#undef  CXXO_COMPILER_SUPPORT_nullptr
#define CXXO_COMPILER_SUPPORT_nullptr __has_extension(cxx_nullptr)
#undef  CXXO_COMPILER_SUPPORT_rvref
#define CXXO_COMPILER_SUPPORT_rvref (__has_extension(cxx_rvalue_references) * __has_extension(cxx_implicit_moves))
#undef  CXXO_COMPILER_SUPPORT_std_is_trivially
#define CXXO_COMPILER_SUPPORT_std_is_trivially (CXXOMFORT_CXX_STD < 2011)
#undef  CXXO_COMPILER_SUPPORT_static_assert
#define CXXO_COMPILER_SUPPORT_static_assert __has_extension(cxx_static_assert)
#undef  CXXO_COMPILER_SUPPORT_typeof
#define CXXO_COMPILER_SUPPORT_typeof 1
#undef  CXXO_COMPILER_SUPPORT_unique_ptr
#define CXXO_COMPILER_SUPPORT_unique_ptr (CXXOMFORT_CXX_STD >= 2011)
#undef  CXXO_COMPILER_SUPPORT_variadic
#define CXXO_COMPILER_SUPPORT_variadic (__has_extension(cxx_variadic_templates) * __has_extension(cxx_default_function_template_args))
#undef  CXXO_COMPILER_SUPPORT_va_args
#define CXXO_COMPILER_SUPPORT_va_args 1

// -- TODO -- get my claws on clang >= 3.2

#endif
