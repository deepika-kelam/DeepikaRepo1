#ifndef CXXOMFORT_CONFIG_C_HAS_HPP
#define CXXOMFORT_CONFIG_C_HAS_HPP

/*
 * Starting with cxxomfort 0.6, headers also provide a macro describing the 
 * support of feature they implement. 
 */

//! Value returned for feature macro when cxxomfort is redirecting the feature to the compiler's native implementation.
#define CXXO_REDIRECT_NATIVE() (9001u)
//! Value returned for feature macro when cxxomfort is implementing a backport.
#define CXXO_BACKPORT() (4001u)
//! Value returned for feature macro when cxxomfort provides an emulation.
#define CXXO_EMULATION() (5001u)
#define CXXO_LIBRARY() (1001u)

//------------------------------------------------
/*
 * List of C++ features for documentation
 * 
 * c++03:
 * c++11:
 * 
 * n1601, n2214, n2431 - null pointer constant
 * n1604, n1720 - static_assert
 * n1811 - long long
 * n1836 - built-in type traits
 * n1978, n2343 - decltype
 * n1984, N2546 - new 'auto' semantics
 * n1986 - delegating constructors
 * n1990 - minmax
 * n2070 - decay
 * n2118 - rvalue references, std::move
 * n2235 - constexpr (c++11)
 * n2240 - enable_if and conditional
 * n2243, n2930 - range-based for loop
 * n2249 - new character types
 * n2258 - template aliases ("using =")
 * n2333, n2437 - explicit conversion operators
 * n2341 - alignment (alignof, alignas, aligned_storage, aligned_union)
 * n2346 - defaulted and deleted members
 * n2347 - scoped enums
 * n2349 - new character types (char16, char32)
 * n2439 - rvalue references for *this
 * n2442 - raw string literals
 * n2540 - inheriting constructors
 * n2541 - trailing return type for functions (->)
 * n2555 - variadic templates
 * n2569 - any, all, none algorithms; lexicographical compare 3-way
 * n2657 - local types as template arguments
 * n2672 - initializer_list
 * n2761 - attributes
 * n2765 - user-defined literals
 * n2844 - rvalue references 2.0
 * n2947 - additional C++0x traits (is_trivially... and is_literal...)
 * 
 * c++14:
 * 
 * n3421 - functional's transparent operators
 * n3584, n3670 - get<>(std:tuple) by type
 * n3652 - relaxed constexpr (c++14)
 * n3656 - make_unique
 * n3638 - return type deduction for normal functions
 * n3654 - quoted
 * n3658 - integer_sequence
 * n3668 - exchange
 * n3671 - improved equal, mismatch
 * n3829 - apply (call a function with a tuple as pack of arguments)
 * 
 * c++17:
 * 
 * n3840, n4282
 * n3840, n4282 - observer_ptr, the world's dumbest smart pointer
 * n3928 - extended static_assert
 * n3911 - make_void, void_t
 * n4061 - gcd, lcm
 * n4076 - not_fn
 * n4380 - as_const
 * 
 * external proposals as of Aug 2017:
 * 
 * n1878, n3527 - optional<T>, nullable type wrapper
 * n2648 - dynarray<T>, ctor-sized vector (functionally later fixed_vector)
 * n3334 - array_ref<T>, range view over a contiguous sequence
 * n3350 - std::range (minimum proposal)
 * n3500 - new assert variants
 * n4017 - nonmember size (<iterator>)
 * n3928 - static_assert without message
 * 
 
 * 
 */



#endif
