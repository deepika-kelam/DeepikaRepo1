#ifndef CXXOMFORT_CONFIG_GCC_HPP
#define CXXOMFORT_CONFIG_GCC_HPP
#ifndef CXXOMFORT_CONFIG_HPP
    #error "This file must not be included directly (see cxxomfort/config.hpp)"
#endif

/*
Here follows a list of C++11 features for GCC:

 * static_assert - 403
 * decltype - 403
 * variadic templates - 404
 * auto with new semantics - 404
 * char16_t, char32_t - 404
 * rvalue references - 404
 * std::initializer_list - 404
 * defaulted and deleted members - 404
 * scoped enums - 404
 * explicit operator T - 405
 * local types as template arguments - 405
 * for (elem : range) - 406
 * nullptr, std::nullptr_t - 406
 * user-defined literals - 407
 * alignment - 408
 * rvalue references for *this - 408
 * decltype for function calls - 408
 * Attributes - 408
 * 
 * See: 
 * http://gcc.gnu.org/projects/cxx0x.html
 * 
 * For correct usage of this library emulation mode
 * ("C++0x") should not be used below GCC 4.6; 
 * normal C++03 plus a TR1 implementation should be used instead.
 */


#define CXXOMFORT_COMPILER_ID CXXO_VALUE_COMPILER_GCC
#define CXXOMFORT_COMPILER_VERSION (__GNUC__*100+__GNUC_MINOR__)

//#define CXXO_PRAGMA(x) _Pragma (#x)
//#define CXXO_NOTICE(msg) CXXO_PRAGMA( message (" cxxomfort warning -- " msg ) )

#if (CXXOMFORT_COMPILER_VERSION >= 408)
    #define CXXO_NOTICE(msg) "cxxomfort: " msg
    #define CXXO_WARNING(msg) "cxxomfort warning: " msg
#else
    #define CXXO_NOTICE_IMPL_(msg) msg
    #define CXXO_NOTICE(msg) CXXO_NOTICE_IMPL_( "cxxomfort notice: " msg)
    #define CXXO_WARNING(msg) CXXO_NOTICE_IMPL_( "cxxomfort warning: " msg)
#endif

#if defined(CXXOMFORT_NOTICES)
    #pragma message CXXO_NOTICE("Found the GNU C++ Compiler.")
#endif

// GCC has a known bug where __cplusplus is not a YYYYMM tag in old versions in C++03 mode
#if (__cplusplus==1)
    #undef CXXOMFORT_CXX_STD
    #define CXXOMFORT_CXX_STD 1997
#endif

#undef  CXXO_COMPILER_SUPPORT_typeof
#define CXXO_COMPILER_SUPPORT_typeof 1
#undef  CXXO_COMPILER_SUPPORT_va_args
#define CXXO_COMPILER_SUPPORT_va_args 1

#if (CXXOMFORT_COMPILER_VERSION < 406)
    #if defined(__GXX_EXPERIMENTAL_CXX0X__)
        // Note: *Unsupported* c++0x emulation mode
        #define CXXOMFORT_CXX_EMULATION 2011
        #pragma message CXXO_WARNING( "Configuration not supported (nullptr and other basic features are missing)" )
        #undef  CXXO_COMPILER_SUPPORT_alignof
        #define CXXO_COMPILER_SUPPORT_alignof 1
        #undef  CXXO_COMPILER_SUPPORT_auto
        #define CXXO_COMPILER_SUPPORT_auto 1
        #undef  CXXO_COMPILER_SUPPORT_default_delete
        #define CXXO_COMPILER_SUPPORT_default_delete 1
        #undef  CXXO_COMPILER_SUPPORT_enum_class
        #define CXXO_COMPILER_SUPPORT_enum_class 1
        #undef  CXXO_COMPILER_SUPPORT_rvref
        #define CXXO_COMPILER_SUPPORT_rvref 1
        #undef  CXXO_COMPILER_SUPPORT_static_assert
        #define CXXO_COMPILER_SUPPORT_static_assert 1
        #undef  CXXO_COMPILER_SUPPORT_std_cxx11_algorithms
        #define CXXO_COMPILER_SUPPORT_std_cxx11_algorithms 1
        //#define CXXO_COMPILER_SUPPORT_std_iterator_helpers 1
        #define CXXO_COMPILER_SUPPORT_std_metaprogramming_helpers 1
        #undef  CXXO_COMPILER_SUPPORT_unique_ptr
        #define CXXO_COMPILER_SUPPORT_unique_ptr 1
        #undef  CXXO_COMPILER_SUPPORT_variadic
        #define CXXO_COMPILER_SUPPORT_variadic 1
    #endif
#endif
#if (CXXOMFORT_COMPILER_VERSION >= 406)
    #if defined(__GXX_EXPERIMENTAL_CXX0X__)
        #undef  CXXOMFORT_CXX_EMULATION
        #define CXXOMFORT_CXX_EMULATION 2011
        #undef  CXXO_COMPILER_SUPPORT_alignof
        #define CXXO_COMPILER_SUPPORT_alignof 1
        #undef  CXXO_COMPILER_SUPPORT_auto
        #define CXXO_COMPILER_SUPPORT_auto 1
        #undef  CXXO_COMPILER_SUPPORT_default_delete
        #define CXXO_COMPILER_SUPPORT_default_delete 1
        #undef  CXXO_COMPILER_SUPPORT_enum_class
        #define CXXO_COMPILER_SUPPORT_enum_class 1
        #undef  CXXO_COMPILER_SUPPORT_explicit_operator
        #define CXXO_COMPILER_SUPPORT_explicit_operator 1
        #undef  CXXO_COMPILER_SUPPORT_foreach
        #define CXXO_COMPILER_SUPPORT_foreach 1
        #undef  CXXO_COMPILER_SUPPORT_initializer_list
        #define CXXO_COMPILER_SUPPORT_initializer_list 1
        #undef  CXXO_COMPILER_SUPPORT_local_types
        #define CXXO_COMPILER_SUPPORT_local_types 1
        #undef  CXXO_COMPILER_SUPPORT_noexcept
        #define CXXO_COMPILER_SUPPORT_noexcept 1
        #define CXXO_NOEXCEPT noexcept
        #undef  CXXO_COMPILER_SUPPORT_nullptr
        #define CXXO_COMPILER_SUPPORT_nullptr 1
        #undef  CXXO_COMPILER_SUPPORT_rvref
        #define CXXO_COMPILER_SUPPORT_rvref 1
        #undef  CXXO_COMPILER_SUPPORT_static_assert
        #define CXXO_COMPILER_SUPPORT_static_assert 1
        #undef  CXXO_COMPILER_SUPPORT_std_cxx11_algorithms
        #define CXXO_COMPILER_SUPPORT_std_cxx11_algorithms 1
        #undef  CXXO_COMPILER_SUPPORT_std_iterator_helpers
        #define CXXO_COMPILER_SUPPORT_std_iterator_helpers 1
        #undef  CXXO_COMPILER_SUPPORT_std_metaprogramming_helpers
        #define CXXO_COMPILER_SUPPORT_std_metaprogramming_helpers 1
        #undef  CXXO_COMPILER_SUPPORT_std_cxx11_constructible_traits
        #define CXXO_COMPILER_SUPPORT_std_cxx11_constructible_traits 1
        #undef  CXXO_COMPILER_SUPPORT_unique_ptr
        #define CXXO_COMPILER_SUPPORT_unique_ptr 1
        #undef  CXXO_COMPILER_SUPPORT_variadic
        #define CXXO_COMPILER_SUPPORT_variadic 1
    #else
    #endif
#endif

#if (CXXOMFORT_COMPILER_VERSION >= 407)
    #if defined(__GXX_EXPERIMENTAL_CXX0X__)
        #undef  CXXO_COMPILER_SUPPORT_constexpr
        #define CXXO_COMPILER_SUPPORT_constexpr 1
    #endif
#endif

// GCC 4.8 onwards set up support for C++14 (--std=c++1y or --std=c++14)

#if (CXXOMFORT_CXX_STD == 2013)
    #define CXXOMFORT_CXX_EMULATION 2014
#endif

#if (CXXOMFORT_COMPILER_VERSION >= 408)
    #if defined(__GXX_EXPERIMENTAL_CXX0X__)
    #undef  CXXO_COMPILER_SUPPORT_attribute
    #define CXXO_COMPILER_SUPPORT_attribute 1
    #undef  CXXO_COMPILER_SUPPORT_alignment_tools
    #define CXXO_COMPILER_SUPPORT_alignment_tools 1
    #undef  CXXO_COMPILER_SUPPORT_decltype
    #define CXXO_COMPILER_SUPPORT_decltype 1
    // 4.8 is considered to have full C++11 support for practical purposes
    // but it's untested so far
    #endif
#endif

#if (CXXOMFORT_COMPILER_VERSION >= 409)
    #if defined(__GXX_EXPERIMENTAL_CXX0X__)
    #undef  CXXO_COMPILER_SUPPORT_attribute
    #define CXXO_COMPILER_SUPPORT_attribute 1
    #undef  CXXO_COMPILER_SUPPORT_alignment_tools
    #define CXXO_COMPILER_SUPPORT_alignment_tools 1
    #undef  CXXO_COMPILER_SUPPORT_decltype
    #define CXXO_COMPILER_SUPPORT_decltype 1
    // 4.8 is considered to have full C++11 support for practical purposes
    // but it's untested so far
    #else
    #undef CXXOMFORT_CXX_STD
    #define CXXOMFORT_CXX_STD 2003
    #endif
#endif

#endif
