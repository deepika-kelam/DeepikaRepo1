#ifndef CXXOMFORT_CONFIG_MSC_HPP
#define CXXOMFORT_CONFIG_MSC_HPP
#ifndef CXXOMFORT_CONFIG_HPP
    #error "This file must not be included directly (see cxxomfort/config.hpp)"
#endif

/*
 * In VC < 10, there is no such thing as C++11 emulation mode. What's more
 * important, in some versions the implementation of TR1 is broken or, in the
 * case of VC9 Express (2008) it won't install at all. 
 * Meaning that to be usable, this library needs to implement many
 * type_traits on its own.
 * 
 * In VC >= 10, the compiler works in what Microsoft calls C++11 mode, 
 * but it is broken in various ways; for example one version resolves 
 * rvalue references incorrectly, and many of them up to 2013 have no 
 * initializer_list support. As such this library does not recorgnize 
 * VC == 10 as C++11 mode, but as C++0x emulation.
 * 
 * See also:
 * http://msdn.microsoft.com/en-us/library/ms177194%28v=VS.100%29.aspx
 *
*/


#define CXXOMFORT_COMPILER_ID CXXO_VALUE_COMPILER_MSC
#define CXXOMFORT_COMPILER_VERSION (_MSC_VER/10)
// eg.: 120 for VC6 (ugh!), 150 for VC9 (Studio / Express 2008)

#define CXXO_PRAGMA(x) _Pragma (#x)
#define CXXO_NOTICE(msg) ( "cxxomfort notice -- " __FILE__ " " msg)
#define CXXO_WARNING(msg) ( "cxxomfort warning -- " __FILE__ " " msg)

#if defined(CXXOMFORT_NOTICES)

    #pragma message CXXO_NOTICE("Found the Microsoft C++ Compiler [" CXXO_STRINGIZE(_MSC_VER) "]" )
#endif

#undef CXXOMFORT_CXX_STD
#define CXXOMFORT_CXX_STD (__cplusplus/100)

// We won't even make an attempt to support VC6
#if (CXXOMFORT_COMPILER_VERSION <= 120)
    #error "cxxomfort -- Detected an horribly broken compiler! (MSVC6 or earlier)"
#endif

#if (CXXOMFORT_COMPILER_VERSION > 120)
    #undef  CXXO_COMPILER_SUPPORT_va_args
    #define CXXO_COMPILER_SUPPORT_va_args 1
#endif

#if (CXXOMFORT_COMPILER_VERSION >= 160) // VC10 or higher
    #undef  CXXOMFORT_CXX_EMULATION
    #define CXXOMFORT_CXX_EMULATION 2011
    #undef  CXXO_COMPILER_SUPPORT_auto
    #define CXXO_COMPILER_SUPPORT_auto 1
    #undef  CXXO_COMPILER_SUPPORT_decltype
    #define CXXO_COMPILER_SUPPORT_decltype 1
    #undef  CXXO_COMPILER_SUPPORT_iterator_helpers
    #define CXXO_COMPILER_SUPPORT_iterator_helpers 0
    #undef  CXXO_COMPILER_SUPPORT_local_types
    #define CXXO_COMPILER_SUPPORT_local_types 1
    #undef  CXXO_COMPILER_SUPPORT_nullptr
    #define CXXO_COMPILER_SUPPORT_nullptr 1
    #undef  CXXO_COMPILER_SUPPORT_rvref
    #define CXXO_COMPILER_SUPPORT_rvref 1
    #undef  CXXO_COMPILER_SUPPORT_static_assert
    #define CXXO_COMPILER_SUPPORT_static_assert 1
    #undef  CXXO_COMPILER_SUPPORT_std_cxx11_algorithms
    #define CXXO_COMPILER_SUPPORT_std_cxx11_algorithms 1
    #undef  CXXO_COMPILER_SUPPORT_std_cxx11_constructible_traits
    #define CXXO_COMPILER_SUPPORT_std_cxx11_constructible_traits 1
    #undef  CXXO_COMPILER_SUPPORT_std_iterator_helpers
    #define CXXO_COMPILER_SUPPORT_std_iterator_helpers 1
    #undef  CXXO_COMPILER_SUPPORT_std_metaprogramming_helpers
    #define CXXO_COMPILER_SUPPORT_std_metaprogramming_helpers 1
//    #undef  CXXO_COMPILER_SUPPORT_alignof
//    #define CXXO_COMPILER_SUPPORT_alignof 1
    #undef  CXXO_COMPILER_SUPPORT_unique_ptr
    #define CXXO_COMPILER_SUPPORT_unique_ptr 1
    
#endif

// -- TODO -- get my claws on a MSVC 2012

// -- END Microsoft C++ Compiler --
#endif
