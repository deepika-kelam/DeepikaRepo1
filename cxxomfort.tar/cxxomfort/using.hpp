#ifndef CXXOMFORT_USING_HPP
#define CXXOMFORT_USING_HPP
// this header should be included after all other standard
// headers that are needed have been included
// in other words: #include as late as possible.
// compliments http://gcc.gnu.org/bugzilla/show_bug.cgi?id=36428 in GCC

#include "config.hpp"

//
// The following section enables usage of TR1 additions when in C++03 mode
// from a predefined namespace such as std::tr1 (like GCC).
//
// Since this library seeks to enable writing code that looks like C++11 
// and is written once, the tr1 headers are assumed to be #include-able 
// just as normal headers are, eg.: <unordered_map>.
// Check your compiler's documentation to see how to do this.
//

/**
 * @namespace std
 * @brief Namespace of the Standard C++ Features
 * 
 * The cxxomfort library maps some features inside this namespace for 
 * backporting. All features mapped this way are brought via 
 * @c using -declaration, with no implementation details entering 
 * the namespace.
 * 
 */
#if (CXXOMFORT_CXX_STD < 2011 && CXXOMFORT_CXX_EMULATION < 2011)
namespace std { namespace tr1 {} } // ensure that the tr1 name exists
namespace std { 
    using namespace tr1 ;   
    // the above uses the contents of namespace 
    // might be not safe, see http://lists.nongnu.org/archive/html/adonthell-general/2011-07/msg00008.html
    // but there's really no better choice when trying to write 
    // portable code because:
    // 1.- we can't know in advance what names are exposed to "using" them
    // eg.: incomplete TR1 implementations, features that change names 
    // such as the ones in <random>
    // see http://lists.gnu.org/archive/html/adonthell-devel/2011-07/msg00000.html
    // 2.- we can't make the object names appear without 
    // #include-ing the headers first and availability of a header 
    // can not be checked at compile time.
    //
    // tl;dr: read the information on the repo wiki about TR1.

}
    #if defined(CXXOMFORT_NOTICES)
        #if (CXXOMFORT_NOTICES>1)
        #pragma message CXXO_NOTICE("importing TR1")
        #endif
    #endif
#else // in C++11

//namespace std { namespace tr1 { using namespace std; } } //
#endif

#endif
