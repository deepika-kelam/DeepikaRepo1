#ifndef CXXOMFORT_ITERATOR_HPP
#define CXXOMFORT_ITERATOR_HPP
/**
 * @file cxxomfort/iterator.hpp
 * @brief Implements some C++11 functions in C++03 from the "iterator" header.
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 * @ingroup base-features
 *
 * Interfaces defined in this header:
 *
 * * begin, end (also for namespace std)
 * * next, prev (also for namespace std)
 * * cbegin (also for namespace std)
 * * cend (also for namespace std)
 *
 */

#include "../config.hpp"
#include "../impl/11-addressof.hpp"
#include CXXO_INCLUDE_SYS(iterator)

#if (CXXOMFORT_CXX_STD < 2011) || (CXXO_COMPILER_SUPPORT_std_iterator_helpers == 0) // begin, end not implemented
    #define CXXOMFORT_USING_ITERATOR 1
#endif

//#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC)
//#pragma GCC diagnostic warning "-Wunused-local-typedefs
//#endif

namespace cxxomfort {
namespace iterator {

//
// Detect the presence of begin, end, size, front and back member functions
//
template <typename T>
struct iterator_accessors_helper {

    typedef struct { int a; } yes;
    typedef char no;

    private:
    template <typename U, U> struct really_has;

    template <typename C> static yes& Test_begin(really_has <typename C::const_iterator (C::*)() const,
                            &C::begin>*);

    template <typename C> static yes& Test_begin(really_has <typename C::iterator (C::*)() const,
                            &C::begin>*);

    template <typename C> static yes& Test_end(really_has <typename C::const_iterator (C::*)() const,
                            &C::end>*);

    template <typename C> static yes& Test_end(really_has <typename C::iterator (C::*)() const,
                            &C::end>*);

    template <typename C> static yes& Test_size(really_has <typename C::difference_type (C::*)() const,
                            &C::size>*);

    template <typename C> static yes& Test_size(really_has <size_t (C::*)() const,
                            &C::size>*);

    template <typename> static no& Test_begin(...);
    template <typename> static no& Test_end(...);
    template <typename> static no& Test_size(...);
    
    public:
    static const bool has_begin    = (sizeof(Test_begin<T>(0)) == sizeof(yes));
    static const bool has_end      = (sizeof(Test_end<T>(0)) == sizeof(yes));
    static const bool has_size     = (sizeof(Test_size<T>(0)) == sizeof(yes));


};

/*
 * This is marked as a system header mostly because of 
 * the generation of intended but annoying 
 * "typedef defined but not used" warnings that can turn 
 * into errors in strict builds.
 */
#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC \
    && CXXOMFORT_COMPILER_VERSION >= 406)
#pragma GCC system_header
#endif

//! Returns the "begin" iterator for a container-like object.
//! @ingroup iterator
//! @ref cxx03-backports
template <typename C>
typename C::iterator inline
begin (C & c) {
    typedef typename C::iterator iterator;
    typedef typename C::value_type value_type;
    return c.begin();
}

//! @overloads cxxomfort::begin
template <typename C> inline
typename C::const_iterator
begin (C const& c) {
    typedef typename C::const_iterator const_iterator;
    //typedef typename C::size_type size_type;
    typedef typename C::value_type value_type;
    return c.begin();
}

//! C++14 "overload" of begin to always return const-iterator
//! @ingroup iterator
//! @ref cxx03-backports
//! @ref cxx11-backports
template <typename C> inline
typename C::const_iterator
cbegin (C const& c)  {
    typedef typename C::const_iterator const_iterator;
    //typedef typename C::size_type size_type;
    typedef typename C::value_type value_type;
    return cxxomfort::iterator::begin(c);
}

//! @overloads cxxomfort::begin 
template <typename T, std::size_t N> inline
T* begin (T(&arr)[N]) { return arr; }

//! @overloads cbegin
template <typename T, std::size_t N> inline
T const* cbegin (T const(&arr)[N]) { return arr; }

//! Returns the "end" iterator for a container-like object.
//! @ingroup iterator
//! @ref cxx03-backports
template <typename C> inline
typename C::iterator
end (C & c) {
    typedef typename C::iterator iterator;
    typedef typename C::difference_type difference_type;
    typedef typename C::value_type value_type;
    return c.end();
}

//! @overloads cxxomfort::end 
template <typename C> inline
typename C::const_iterator
end (C const& c) {
    typedef typename C::const_iterator iterator;
    //typedef typename C::size_type size_type;
    typedef typename C::value_type value_type;
    return c.end();
}

//! C++14 "overload" to always return const-iterator
//! @ingroup iterator
//! @ref cxx03-backports
//! @ref cxx11-backports
template <typename C> inline
typename C::const_iterator
cend (C const& c)  {
    typedef typename C::const_iterator const_iterator;
    //typedef typename C::size_type size_type;
    typedef typename C::value_type value_type;
    return cxxomfort::iterator::end(c);
}

//! @overloads end
template <typename T, size_t N> inline
T* end (T(&arr)[N]) { return arr+N; }

//! @overloads cend
template <typename T, size_t N> inline
T const* cend (T const(&arr)[N]) { return arr+N; }

// From C++14 / 2y
template <typename C>
typename C::reverse_iterator inline
rbegin (C & c) {
    typedef typename C::reverse_iterator iterator;
    typedef typename C::difference_type difference_type;
    typedef typename C::value_type value_type;
    return c.rbegin();
}

template <typename C>
typename C::reverse_iterator inline
rend (C & c) {
    typedef typename C::reverse_iterator iterator;
    typedef typename C::difference_type difference_type;
    typedef typename C::value_type value_type;
    return c.rend();
}

//! @overloads cxxomfort::rbegin 
template <typename T, std::size_t N> inline
std::reverse_iterator<T*> rbegin (T(&arr)[N]) { return std::reverse_iterator<T*>(arr+N); }

//! @overloads cxxomfort::rend 
template <typename T, std::size_t N> inline
std::reverse_iterator<T*> rend (T(&arr)[N]) { return std::reverse_iterator<T*>(arr); }


/**
 * @brief Moves an iterator forwards an amount of steps, returning the result.
 * @ingroup iterator
 * @ref cxx03-backports
 *
 * This is reflected as @c std::next .
 */
template <typename FIterator> inline
FIterator next
(FIterator i, typename std::iterator_traits<FIterator>::difference_type n = 1
) {
    std::advance(i, n);
    return i;
}

/**
 * @brief Moves an iterator backwards an amount of steps, returning the result.
 * @ingroup iterator
 * @ref cxx03-backports
 *
 * This is reflected as @c std::prev .
 */
template <typename FIterator> inline
FIterator prev (FIterator i
, typename std::iterator_traits<FIterator>::difference_type n = 1
) {
    std::advance(i, -n);
    return i;
}


//
// From proposal N4017
//
// This implements a nonmember size() that calls member .size().
// For containers that somehow don't have size() (looking at you forward_list >_>)
// let's do distance(.begin(),.end())

namespace detail_size {
template <typename C, bool F=false> struct call_size_has {
    typename C::difference_type operator() (C const& c) const { 
        return std::distance(c.begin() , c.end());
    }
}; // call_size_has

template <typename C> struct call_size_has<C,true> {
    typename C::difference_type operator() (C const& c) const { 
        return c.size();
    }
}; // call_size_has

} // detail_size

template <typename C> inline
typename C::difference_type
size (C & c) {
    typedef typename C::iterator iterator;
    typedef typename C::difference_type difference_type;
    typedef typename C::value_type value_type;
    const detail_size::call_size_has< C, iterator_accessors_helper<C>::has_size > s={};
    return s(c);
}

// overload for native arrays
template <typename T, size_t N> inline
size_t size (T(&arr)[N]) {
    return N;
}

#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC \
    && CXXOMFORT_COMPILER_VERSION >= 408)
#pragma GCC diagnostic pop
#endif

} // ~::cxxomfort::iterator
} // ~::cxxomfort



#if defined CXXOMFORT_USING_ITERATOR
    #if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 2)
    #pragma message CXXO_NOTICE("enabled iterator functions support.")
    #endif

#include CXXO_INCLUDE_SYS(iterator)

/*
 * Provide begin, end support for std::valarray as well.
 */
namespace std {
template <typename T> class valarray;
}

namespace cxxomfort {

template <typename T> inline
T* begin (std::valarray<T> & c) { return addressof(c[0]); }

template <typename T> inline
T const* begin (std::valarray<T> const& c) { return addressof(c[0]); }

template <typename T> inline
T* end (std::valarray<T> & c) { return addressof(c[0])+c.size(); }

template <typename T> inline
T const* end (std::valarray<T> const& c) { return addressof(c[0])+c.size(); }


} //~::cxxomfort


#endif // valarray support


namespace std {

#if (CXXOMFORT_CXX_STD < 2011 && CXXO_COMPILER_SUPPORT_std_iterator_helpers == 0)
    using ::cxxomfort::iterator::begin;
    using ::cxxomfort::iterator::end;
    using ::cxxomfort::iterator::cbegin;
    using ::cxxomfort::iterator::cend;
    using ::cxxomfort::iterator::rbegin;
    using ::cxxomfort::iterator::rend;
// GCC 4.4 already has next, prev in c++0x mode
    #if (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_GCC && CXXOMFORT_CXX_EMULATION == 2011)
    #else
    using ::cxxomfort::iterator::next;
    using ::cxxomfort::iterator::prev;
    #endif

#else
	using ::cxxomfort::iterator::cbegin;
	using ::cxxomfort::iterator::cend;
#endif
    //using ::cxxomfort::size; // not enabled yet
}

#endif
