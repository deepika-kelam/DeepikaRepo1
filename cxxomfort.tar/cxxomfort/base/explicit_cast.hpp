#ifndef CXXOMFORT_UTIL_EXPLICIT_CAST_HPP
#define CXXOMFORT_UTIL_EXPLICIT_CAST_HPP
/**
 * @file cxxomfort/util/explicit_cast.hpp
 * @brief Explicit cast, and @c explicit_cast conversion operator for C++03
 * 
 * Interfaces defined in this header:
 * 
 * * @c explicit_cast (as a synonym in C++11)
 * * @c CXXO_EXPLICIT_OPERATOR
 * 
 */

#include "../config.hpp"
#include "../base/move.hpp"
#define CXXOMFORT_IMPLEMENTS_n2333 CXXO_EMULATION()
#define CXXOMFORT_IMPLEMENTS_n2437 CXXO_EMULATION()

namespace cxxomfort {
namespace detail_explicit_cast {

#if (CXXOMFORT_CXX_STD < 2011 && CXXO_COMPILER_SUPPORT_explicit_operator==0)
#if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 2)
    #pragma message CXXO_NOTICE("enabled 'explicit operator' emulation")
#endif

//! @ingroup base-features
template <typename T>
struct explicit_cast {
    T value;
    explicit_cast (T const& t) CXXO_NOEXCEPT : value(t) {}
    //explicit_cast ( CXXO_RV_REF(T) p) : value(std::move(p)) {}
    operator T () const CXXO_NOEXCEPT { return value; }
};

#else
//template <typename T, typename U>
//T explicit_cast (U&& u) { return static_cast<T>(u); }
#define explicit_cast static_cast

/*
template <typename T>
struct explicit_cast {
    T value;
    template <typename U>
    explicit_cast (U u): value(static_cast<T>(u)) {}
    explicit_cast (T const& t) : value(t) {}
    explicit_cast (T&& t) : value(std::move(t)) {}
    operator T () const { return value; }
};
*/
#endif

}
} // cxxomfort::

#if defined(DOXYGEN_DOC)
/**
 * @def CXXO_EXPLICIT_OPERATOR(T)
 * @brief Implements a member conversion operator that provides explicit conversion
 * @ingroup base-features
 * 
 * This macro creates a conversion operator that provides an explicit conversion 
 * to a type of argument type @p T .
 * 
 * In C++11, this is defined to be a native <code>explicit operator T</code>; 
 * in C++03, this is defined to be an accessory conversion that the caller 
 * enabled by using <code>explicit_cast<T>(...)</code>.
 * 
 */
#define CXXO_EXPLICIT_OPERATOR(T)  implementation_defined
/**
 * @brief Explicitly cast an object of type F to a type T
 * @ingroup base-features
 * 
 * This pseudo-keyword performs an @c explicit -using cast on an object @em f 
 * to a target type @em T .
 * 
 * In C++11, this is defined to be a native <code>static_cast</code>; 
 * in C++03, this uses a fake cast.
 */
template <typename T, typename F>
T explicit_cast (F f) { return implementation_defined_cast<T>(f); }
#endif

// sync this #if with the top feature one
#if (CXXOMFORT_CXX_STD < 2011 && CXXO_COMPILER_SUPPORT_explicit_operator==0)
    #define CXXO_EXPLICIT_OPERATOR(T) operator ::cxxomfort::detail_explicit_cast::explicit_cast<T> 

using ::cxxomfort::detail_explicit_cast::explicit_cast;
#else
    #define CXXO_EXPLICIT_OPERATOR(T) explicit operator T 

#endif


#endif
