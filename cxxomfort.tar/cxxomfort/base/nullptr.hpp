#ifndef CXXOMFORT_NULLPTR_HPP
#define CXXOMFORT_NULLPTR_HPP
/**
 * @file cxxomfort/nullptr.hpp
 * @brief Implements @c nullptr as a comfort utility for C++03.
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 *
 * Interfaces defined in this file:
 * 
 * * nullptr_t (also in namespace std)
 * * nullptr (also in namespace std)
 */
#include "../config.hpp"
#define CXXOMFORT_IMPLEMENTS_n1601 CXXO_BACKPORT()
#define CXXOMFORT_IMPLEMENTS_n2214 CXXO_BACKPORT()



#if (CXXOMFORT_CXX_STD < 2011 && CXXO_COMPILER_SUPPORT_nullptr==0)
    #define CXXOMFORT_USING_nullptr
#endif


#if defined (CXXOMFORT_USING_nullptr)
    #if defined (CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 2)
    #pragma message CXXO_NOTICE("enabled 'nullptr' backport.")
    #endif


/*
 * This is marked as a system header mostly because of 
 * bug https://gcc.gnu.org/bugzilla/show_bug.cgi?id=48914
 * where it is not possible to omit "nullptr is reserved" warnings.
 */
#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC \
    && CXXOMFORT_COMPILER_VERSION >= 406)
#pragma GCC system_header
#endif

namespace std {

// This is pretty much borrowed from the Standards recommendation verbatim.

/**
 * @class nullptr_t
 * @brief Null pointer literal type.
 * @ingroup base-features
 * @ref cxx03-backports
 * 
 * @attention No variables of this type can be created.
 *
 * @c nullptr_t is defined in the C++0x Standard as the type of the
 * keyword "@c nullptr ", via decltype. In C++98 / C++03,
 * an emulation is provided and recommended by the Standard.
 *
 * Only one variable of this type exists - @link nullptr @endlink .
 *
**/
class nullptr_t {
public:
    template<class T>           // convertible to any type
    operator T*() const       // of null non-member
    { return 0; }              // pointer...
    template<class C, class T> // or any type of null
    operator T C::*() const   // member pointer...
    { return 0; }
private:
    void operator&() const;    // whose address can't be taken
};



} //~namespace std

/**
 * @var nullptr
 * @brief Null pointer literal (backport)
 * @anchor nullptr
 * @addtogroup base-features
 * @see http://stackoverflow.com/questions/8747005/backporting-nullptr-to-c-pre-c0x-programs
 * @ref cxx03-backports
 */
const std::nullptr_t nullptr = {};



#endif // using emulation

#endif // file
