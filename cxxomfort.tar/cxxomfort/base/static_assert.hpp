#ifndef CXXOMFORT_SASSERT_HPP
#define CXXOMFORT_SASSERT_HPP
/**
 * @file static_assert.hpp
 * @brief Implements @c static_assert (n1720) as a comfort utility for C++03.
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 * @license MIT License (see LICENSE.txt)
 *
 * Interfaces defined in this file:
 * 
 * * @c static_assert
 */

#include "../config.hpp"
#define CXXOMFORT_IMPLEMENTS_n1604 CXXO_EMULATION()
#define CXXOMFORT_IMPLEMENTS_n1720 CXXO_EMULATION()


#define CXXOMFORT_JOIN(a,b) a##b
#define CXXOMFORT_JOINX(a,b) CXXOMFORT_JOIN(a,b)

#if (CXXOMFORT_CXX_STD < 2011)
#if (CXXO_COMPILER_SUPPORT_static_assert == 0) // static_assert is not supported
    #define CXXOMFORT_USING_static_assert
#endif
#endif

// implementation

#if defined(CXXOMFORT_USING_static_assert)
    #if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 2)
    #pragma message CXXO_NOTICE("enabled 'static_assert' emulation.")
    #endif

/*
 * This is marked as a system header 
 * as it uses the name of a C++11 reserved word as an identifier.
 */
#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC \
    && CXXOMFORT_COMPILER_VERSION >= 406)
#pragma GCC system_header
#endif


/**
 * @def static_assert
 * @ingroup base-features
 * @ref cxx03-backports
 * @brief Provides an assertion at compile-time
 * @param test The boolean test to run, must be computable at compile-time
 * @param msg The string literal to provide as a compiler error message if the assertion does not hold
 */
//    #define static_assert(test,msg) enum { CXXOMFORT_JOINX(sassert_e_,__COUNTER__) = (int)(msg[0])/(test) }
    #if defined(_MSC_VER)
    #define static_assert(test,msg) typedef void* CXXOMFORT_JOINX(sassert_expr_,__COUNTER__)[(test)?1:-1]
    #else
    #define static_assert(test,msg) enum { CXXOMFORT_JOINX(sassert_e_,__COUNTER__) = 1/(test) }
    #endif

#endif
// partial implementation of n3928: static_assert without message
    #define static_assert0(test) static_assert(test,#test)

#endif
