#ifndef CXXOMFORT_EXTRAS_MOVE_11_HPP
#define CXXOMFORT_EXTRAS_MOVE_11_HPP

//Move emulation rv breaks standard aliasing rules so add workarounds for some compilers
#ifdef __GNUC__ 
  #define BOOST_MOVE_ATTRIBUTE_MAY_ALIAS __attribute__((__may_alias__)) 
#else 
  #define BOOST_MOVE_ATTRIBUTE_MAY_ALIAS
#endif

// move, forward, are already declared

#define CXXO_COPYABLE_MOVABLE(TYPE) \
    //
#define CXXO_NONCOPYABLE_MOVABLE(TYPE) \
    //
#define CXXO_COPYABLE_MOVABLE_NONASSIGNABLE(TYPE)\

#define CXXO_COPY_ASSIGN_REF(TYPE) const TYPE & 
    //
#define CXXO_RV_REF(TYPE) TYPE && 
    //
#define CXXO_FWD_REF(TYPE) TYPE && 
    //

#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_CLANG && CXXO_EMULATION_rvref)

#endif

#endif
