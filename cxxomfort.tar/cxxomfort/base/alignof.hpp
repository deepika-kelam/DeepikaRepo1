#ifndef CXXOMFORT_ALIGNOF_HPP
#define CXXOMFORT_ALIGNOF_HPP
/**
 * @file base/alignof.hpp
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 *
 * Interfaces defined in this file:
 * 
 * * alignof (macro) (only for c++03 where __alignof is available)
 * 
 * Backported for C++03
 * 
 */

#include "../config.hpp"

#if (CXXOMFORT_CXX_STD < 2011 && CXXO_COMPILER_SUPPORT_alignof==0)
    #define CXXOMFORT_USING_alignof
#endif


#if defined(CXXOMFORT_USING_alignof) || defined(DOXYGEN_DOC)

/* alignof */
    #ifdef alignof
    #error " cxxomfort - conflicting #define directive for 'alignof()'!"
    #endif

    #define alignof(x) __alignof( x )

#endif // using emulation


#endif // file
