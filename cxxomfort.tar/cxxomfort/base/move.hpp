#ifndef CXXOMFORT_UTIL_MOVE_HPP
#define CXXOMFORT_UTIL_MOVE_HPP

/**
 * @file cxxomfort/base/move.hpp
 * @brief Implements movable objects functionality in C++03 .
 *
 */


/*
 * Usage example
 *
template <class Resource> class holds_resource {
    private:
    CXXO_COPYABLE_MOVABLE(holds_resource);
    Resource* ptr;

    public:
    // Construction
    explicit holds_resource(Resource* p = 0) : ptr(p) {}
    // Destruction
    ~holds_resource() { delete ptr; }
    // copy constructor works as usual
    holds_resource(holds_resource const& p)
      : ptr(p.ptr ? p.ptr->clone() : 0) {}
    // copy assignment
    holds_resource& operator=(CXXO_COPY_ASSIGN_REF(holds_resource) p) {
      if (this != &p){
         Resource *tmp_p = p.ptr ? p.ptr->clone() : 0;
         delete ptr;
         ptr = tmp_p;
      }
      return *this;
    }
    // move constructor
    holds_resource(CXXO_RV_REF(holds_resource) p) 
      : ptr(p.ptr) { p.ptr = 0; }
    // move assignment
    holds_resource& operator=(CXXO_RV_REF(holds_resource) p) {
      if (this != &p){
         delete ptr;
         ptr = p.ptr;
         p.ptr = 0;
      }
      return *this;
    }
};
*/

#include <cxxomfort/config.hpp> // c++11
#define CXXOMFORT_IMPLEMENTS_n2118 CXXO_EMULATION()


#if ((CXXOMFORT_CXX_STD < 2011) && (CXXO_COMPILER_SUPPORT_rvref==0))
    #define CXXOMFORT_USING_MOVE_EMULATION 1
#endif

#if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 2)
#pragma message CXXO_NOTICE("enabled rvref and movable object emulation.")
#endif


#if !defined (CXXOMFORT_USING_MOVE_EMULATION)
    #include "move-11.hpp"
    // end c++11
#else
    #include "move-03.hpp"
// end c++11 / c++03
#endif

namespace cxxomfort {

/**
 * @brief Move-assigns the objects from sequence <var>[ini,fin)</var> to sequence at @e dest .
 * @ingroup base-features
 * @ref cxx03-backports
 * @ref algorithm
 */
template<class IIt, class OIt>
OIt move(IIt ini, IIt fin, OIt dest) {
    while (ini != fin) {
        *dest++ = ::cxxomfort::move(*ini++);
    }
    return dest;
}

template<class IIt, class OIt>
OIt move_backward(IIt ini, IIt fin, OIt dest) {
    while (ini != fin) {
        *dest-- = ::cxxomfort::move(*fin--);
    }
    return dest;
}


// move_if algorithm

} // cxxomfort

// this has to be in global namespace for clear usage
//! Rvalue-reference selector
template <typename T>
struct rvref {
#if defined(CXXOMFORT_USING_MOVE_EMULATION)
    typedef ::cxxomfort::rv<T>& type;
#else
    typedef T&& type;
#endif
};


/*
#if (defined(CXXOMFORT_USING_MOVE_EMULATION))
namespace std {
    using ::cxxomfort::extras::move;
    using ::cxxomfort::extras::move_backward;
}
#endif
*/

#endif
