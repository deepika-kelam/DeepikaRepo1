#ifndef CXXOMFORT_UTIL_MOVE_03_HPP
#define CXXOMFORT_UTIL_MOVE_03_HPP

// Move emulation, deboostified from Boost
// (Dunno what's the point, Boost.Move is pretty self-standing)

#include "../config.hpp"
#include "../util/type_traits.hpp"
#include "../util/meta.hpp"
#include "../impl/11-addressof.hpp"
#if (CXXOMFORT_CXX_STD >= 2011)
    #error Library error - this file should only be invoked with c++03
#endif


//Move emulation rv breaks standard aliasing rules so add workarounds for some compilers
#ifdef __GNUC__
  #define BOOST_MOVE_ATTRIBUTE_MAY_ALIAS __attribute__((__may_alias__))
#else
  #define BOOST_MOVE_ATTRIBUTE_MAY_ALIAS
#endif

#define noexcept

namespace cxxomfort{

namespace move_detail {
//is_convertible
template <class T, class U>
class is_convertible {
    typedef char true_t;
    class false_t { char dummy[2]; };
    static true_t dispatch(U);
    static false_t dispatch(...);
    static T& trigger();
    public:
    enum { value = sizeof(dispatch(trigger())) == sizeof(true_t) };
};

template <typename U>
class is_convertible<void, U> {
    public:
    static const bool value= false;
};

struct empty {};
}

template <class T>
class rv
: public ::cxxomfort::conditional
    < (traits::is_class<T>::value || traits::is_union<T>::value)
    , T
    , move_detail::empty
>::type {
    rv();
    ~rv();
    rv(rv const&);
    void operator=(rv const&);
} BOOST_MOVE_ATTRIBUTE_MAY_ALIAS;

template <class T>
struct is_rv
: traits::false_type
{};

template <class T>
struct is_rv< rv<T> >
: traits::true_type
{};

template <class T>
struct is_rv< const rv<T> >
: public traits::true_type
{};


template<class T>
struct has_move_emulation_enabled
  : move_detail::is_convertible< T, rv<T>& >
{};

template<class T>
struct has_move_emulation_enabled<T&>
  : traits::false_type
{};

template<class T>
struct has_move_emulation_enabled< rv<T> >
  : traits::false_type
{};

template <class T>
struct has_move_emulation_enabled_aux
 : has_move_emulation_enabled<T> {};

template <class T>
struct has_nothrow_move
  : traits::integral_constant<bool, false>
{};

template<class T> struct enable_move_utility_emulation {
    static const bool value = true;
};

//
//                            move()
//

template <class T>
inline typename
std::enable_if<!has_move_emulation_enabled_aux<T>::value, T&>::type move(T& x) {
  return x;
}

template <class T>
inline typename
std::enable_if<has_move_emulation_enabled<T>::value, rv<T>&>::type move(T& x) {
  return *static_cast<rv<T>* >(std::addressof(x));
}

template <class T>
inline typename
std::enable_if<has_move_emulation_enabled<T>::value, rv<T>&>::type move(rv<T>& x) {
  return x;
}

//
//                            forward()
//

template <typename T> inline 
typename std::enable_if<
    enable_move_utility_emulation<T>::value && is_rv<T>::value, T &
>::type forward (const typename ::cxxomfort::identity<T>::type &x) noexcept {
    return const_cast<T&>(x);
}

template <typename T> inline
typename std::enable_if<
    enable_move_utility_emulation<T>::value && !is_rv<T>::value, T const&
>::type forward (const typename ::cxxomfort::identity<T>::type &x) noexcept {
    return x;
}

#undef noexcept

} //::cxxomfort::


#define CXXO_NONCOPYABLE_MOVABLE(TYPE)\
        private:\
        TYPE(TYPE &);\
        TYPE& operator=(TYPE &);\
        public:\
        operator ::cxxomfort::rv<TYPE>&() \
        {  return *static_cast< ::cxxomfort::rv<TYPE>* >(this);  }\
        operator const ::cxxomfort::rv<TYPE>&() const \
        {  return *static_cast<const ::cxxomfort::rv<TYPE>* >(this);  }\
        private:\


#define CXXO_COPYABLE_MOVABLE(TYPE)\
        public:\
        TYPE& operator=(TYPE &t)\
        {  this->operator=(static_cast<const ::cxxomfort::rv<TYPE> &>(const_cast<const TYPE &>(t))); return *this;}\
        public:\
        operator ::cxxomfort::rv<TYPE>&() \
        {  return *static_cast< ::cxxomfort::rv<TYPE>* >(this);  }\
        operator const ::cxxomfort::rv<TYPE>&() const \
        {  return *static_cast<const ::cxxomfort::rv<TYPE>* >(this);  }\
        private:\

#define CXXO_COPYABLE_MOVABLE_NONASSIGNABLE(TYPE)\
        private:\
        TYPE& operator= (TYPE const&) CXXOMFORT_CXX11_CODE(=delete,);\
        public:\
        operator ::cxxomfort::rv<TYPE>&() \
        {  return *static_cast< ::cxxomfort::rv<TYPE>* >(this);  }\
        operator const ::cxxomfort::rv<TYPE>&() const \
        {  return *static_cast<const ::cxxomfort::rv<TYPE>* >(this);  }\
        private:\


#define CXXO_COPY_ASSIGN_REF(TYPE) const ::cxxomfort::rv< TYPE >&

#define CXXO_RV_REF(TYPE) ::cxxomfort::rv< TYPE >&

#define CXXO_FWD_REF(TYPE) TYPE const&

//
// Helps write a semi-variadic argument list, up to 5 arguments
#define CXXO_VARIADIC_SIGNATURE(name)                                       \
    template <typename Arg1> name ( CXXO_VARFN_ARG0 CXXO_FWD_REF(Arg1) );    \
    template <typename Arg1, typename Arg2>                                  \
    name ( CXXO_VARFN_ARG0 CXXO_FWD_REF(Arg1), CXXO_FWD_REF(Arg2) );         \
    template <typename Arg1, typename Arg2, typename Arg3>                   \
    name ( CXXO_VARFN_ARG0 CXXO_FWD_REF(Arg1), CXXO_FWD_REF(Arg2), CXXO_FWD_REF(Arg3) );      \
    template <typename Arg1, typename Arg2, typename Arg3, typename Arg4>    \
    name ( CXXO_VARFN_ARG0 CXXO_FWD_REF(Arg1), CXXO_FWD_REF(Arg2),           \
     CXXO_FWD_REF(Arg3), CXXO_FWD_REF(Arg4) );             \
    template <typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5>     \
    name ( CXXO_VARFN_ARG0 CXXO_FWD_REF(Arg1), CXXO_FWD_REF(Arg2),           \
     CXXO_FWD_REF(Arg3), CXXO_FWD_REF(Arg4), CXXO_FWD_REF(Arg5) );           \


namespace std{
    using ::cxxomfort::move;
    using ::cxxomfort::forward;
}


#endif

