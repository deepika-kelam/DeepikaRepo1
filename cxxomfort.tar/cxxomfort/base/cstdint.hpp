#ifndef CXXOMFORT_BASE_CSTDINT_HPP
#define CXXOMFORT_BASE_CSTDINT_HPP
/*
 * This header file redirects to the header providing
 * the standard integer types; in C++11 this is
 * <cstdint>, whereas in C++03 this is <stdint.h>
 */
#include "../config.hpp"
#define __STDC_LIMIT_MACROS

#if (CXXOMFORT_CXX_STD>=2011 || CXXOMFORT_CXX_EMULATION >= 2011)
    #if defined(CXXOMFORT_NOTICES)  && (CXXOMFORT_NOTICES > 1)
        #pragma message CXXO_NOTICE("Including <cstdint> in C++11 mode")
    #endif
    #include <cstdint>
    #define CXXOMFORT_USING_NATIVE_stdint
#else
    #if 0
        #error ("Unreachable.");
    #elif (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_CLANG)
    // GCC and clang have a <stdlib.h>
        #if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
        #pragma message CXXO_NOTICE("cstdint forwarded to tr1/ <cstdint> [clang]")
        #endif
        #define __STDC_LIMIT_MACROS
        #include <tr1/cstdint>
        #define CXXOMFORT_USING_NATIVE_stdint

    #elif (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_GCC)
        #if (CXXOMFORT_COMPILER_VERSION >= 406)
            #if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
            #pragma message CXXO_NOTICE("cstdint forwarded to tr1/ <cstdint> [gcc]")
            #endif
            #define __STDC_LIMIT_MACROS
            #include <tr1/cstdint>
            #define CXXOMFORT_USING_NATIVE_stdint
        #else
            #if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
            #pragma message CXXO_NOTICE("cstdint forwardrd to <stdint.h> [gcc]")
            #endif
            #define __STDC_LIMIT_MACROS
            #include <stdint.h>
            #define CXXOMFORT_USING_NATIVE_stdint
        #endif
    #elif (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_MSC)
        #if (CXXOMFORT_COMPILER_VERSION>150)
            #if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
            #pragma message CXXO_NOTICE("cstdint forwarded to MSVC:<cstdint>")
            #define __STDC_LIMIT_MACROS
            #include <cstdint>
            #define CXXOMFORT_USING_NATIVE_stdint
            #endif
        #else
            //#include <stdint.h>
        #endif
    #else
    #endif
#endif // c++11

#if (!defined(CXXOMFORT_USING_NATIVE_stdint))
    #if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
        #pragma message CXXO_NOTICE("cstdint forwarded to portable-stdint")
    #endif
    //#define __STDC_LIMIT_MACROS
    #include "../impl/pstdint.h"
    #define CXXOMFORT_USING_PSTDINT_stdint
#endif // using pstdint

#include <climits>
#endif // header

