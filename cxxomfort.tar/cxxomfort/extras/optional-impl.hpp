#ifndef CXXOMFORT_EXTRAS_OPTIONAL_IMPL_HPP
#define CXXOMFORT_EXTRAS_OPTIONAL_IMPL_HPP
/**
 * @file cxxomfort/extras/optional-impl.hpp
 * @brief Implementation details of <code>optional<T></code> proposal.
 */

/*
 * Header file with implementation of optional
 * This is directly loaded from optional.hpp
 * as such we are already within namespace cxxomfort::extras::optional::
 */

namespace detail {

using std::aligned_storage;

CXXOMFORT_CXX11_CODE(constexpr,const) struct trivial_init_t {} trivial_init = {};

/* storage of the optional contents as an aligned_storage */
template <typename T>
struct storage_align_t {
    typename aligned_storage<sizeof(T),alignof(T)>::type buff_;

    void const * address () const { return std::addressof(/*dummy.*/buff_); }
    void       * address ()       { return std::addressof(/*dummy.*/buff_); }

    // "disengaged" constructor
    CXXO_CONSTEXPR storage_align_t (trivial_init_t) CXXO_NOEXCEPT : /*dummy()*/ buff_() {}
    ~storage_align_t () {}
};

/* constexpr-storage for C++11 optionals where T is a fundamental */
/* TODO: implement optional<fundamental_T> with this storage and 
 * constexpr constructors to make it a literal type
 */
#if (CXXOMFORT_CXX_STD >= 2011 || (CXXOMFORT_CXX_EMULATION>=2011 && CXXO_COMPILER_SUPPORT_constexpr>0 ))
template <typename T>
union storage_constexpr11_t {
    unsigned char dummy_;
    T value_;

    constexpr storage_constexpr11_t ( trivial_init_t ) noexcept : dummy_() {};
    ~storage_constexpr11_t () = default;
};

#endif


}

#if 1

namespace detail {

// Wrapper for nullable types
template <typename T, typename=void>
class optional_impl {
    static_assert (!std::is_lvalue_reference<T>::value, "optional<T>: T must not be a reference type");
    static_assert ((!std::is_same<T,nullopt_t>::value), "optional<T>: T must not be an optional 'nullopt' tag");
    

    private:
    typedef detail::storage_align_t<T> storage_type;
    protected:
    typedef T  value_type;
    static const bool is_specialized = false;
    
    //! Default constructor (@c noexcept ; trivial if @p T is a fundamental type)
    CXXO_CONSTEXPR optional_impl () CXXO_NOEXCEPTNOTHROW 
    : _engaged(false), _storage(detail::trivial_init) {}

    //! Copy constructor (defaulted-trivial if @p T is a fundamental type)
    optional_impl (optional_impl const& ot)
    : _storage(detail::trivial_init), _engaged(ot._engaged) {
        if (_engaged) new (std::addressof(_storage)) value_type(reinterpret_cast<T const&>(ot._storage)) ;
    }

    //! Disengaged state constructor (@c constexpr  @c noexcept )
    CXXO_CONSTEXPR optional_impl (nullopt_t) CXXO_NOEXCEPTNOTHROW
    : _storage(detail::trivial_init), _engaged(false) {}

    //! Engaged state constructor
    explicit optional_impl (T const& t)
    : _storage(detail::trivial_init), _engaged(true) {
        new (std::addressof(_storage)) value_type(t);
    }

#if (CXXOMFORT_CXX_STD >= 2011)
    //! Emplace constructor 
    template <typename... Args>
    optional_impl (in_place_t, Args&&... args)
    : _engaged(true), _storage(detail::trivial_init) {
        new (std::addressof(_storage)) value_type(std::forward<Args>(args)...);
    }
#else

    //! emplace constructor
    optional_impl (in_place_t)
    : _engaged(true), _storage(detail::trivial_init) {
        new (std::addressof(_storage)) value_type() ;
    }

    //! emplace constructor
    template <typename A1>
    optional_impl (in_place_t, CXXO_FWD_REF(A1) a1)
    : _engaged(true), _storage(detail::trivial_init) {
        new (std::addressof(_storage)) value_type(a1) ;
    }
    //! emplace constructor
    template <typename A1, typename A2>
    optional_impl (in_place_t, CXXO_FWD_REF(A1) a1, CXXO_FWD_REF(A2) a2)
    : _engaged(true), _storage(detail::trivial_init) {
        new (std::addressof(_storage)) value_type(a1,a2) ;
    }
    //! emplace constructor
    template <typename A1, typename A2, typename A3>
    optional_impl (in_place_t, CXXO_FWD_REF(A1) a1, CXXO_FWD_REF(A2) a2, CXXO_FWD_REF(A3) a3)
    : _engaged(true), _storage(detail::trivial_init) {
        new (std::addressof(_storage)) value_type(a1,a2,a3) ;
    }
    //! emplace constructor
    template <typename A1, typename A2, typename A3, typename A4>
    optional_impl (in_place_t, CXXO_FWD_REF(A1) a1, CXXO_FWD_REF(A2) a2, CXXO_FWD_REF(A3) a3, CXXO_FWD_REF(A4) a4)
    : _engaged(true), _storage(detail::trivial_init) {
        new (std::addressof(_storage)) value_type(a1,a2,a3,a4) ;
    }
#endif

    //! Destructor (trivial if @p T is a fundamental type)
    ~optional_impl () { this->destruct(); }


    //! Assignment (@c noexcept  and trivial if @p T is a fundamental type)
    optional_impl& operator= (optional_impl const& ot) {
        if (_engaged && ot._engaged) *cast_it()= *ot.cast_it();
        else if (_engaged && !ot._engaged) *this= nullopt;
        else if (!_engaged && ot._engaged) *this= *ot.cast_it();
        return *this;
    }
    //! Disengaging assignment (trivial if @p T is a fundamental type)
    optional_impl& operator= (nullopt_t) CXXO_NOEXCEPT {
        destruct();
        _engaged= false;
        return *this;
    }
    //! Engaging assignment (trivial if @p T is a fundamental type)
    optional_impl& operator= (T const& t) {
        if (!_engaged) {
            new (std::addressof(_storage)) value_type(t);
            _engaged= true;
        }
        return *this;
    }

    CXXO_CONSTEXPR CXXO_EXPLICIT_OPERATOR(bool) () const CXXO_NOEXCEPT {
        return engaged();
    }


    //! Obtain value of a @b engaged  object.
    T const&        value () const {
        if (!_engaged) throw bad_optional_access("disengaged call to value() const");
        return *cast_it();
    }
    //! @overloads value
    T&              value () {
        if (!_engaged) throw bad_optional_access("disengaged call to value() non-const");
        return *cast_it();
    }

    T     value_or (T const& alt) const CXXO_NOEXCEPT {
        if (!_engaged) return alt;
        else return *cast_it();
    }

    //! Check engagement state of object.
    CXXO_CONSTEXPR bool  engaged () const CXXO_NOEXCEPT { return _engaged; }

    //! Obtain value of an @v engaged  object.
    CXXO_CONSTEXPR const T&   operator* () const CXXO_NOEXCEPT { return value(); }
    //! @overloads operator*
    T&         operator* () { return value(); }

    CXXO_CONSTEXPR T const* operator-> () const CXXO_NOEXCEPT {
        return cast_it();
    }
    T* operator-> () {
        return cast_it();
    }


    //! Swap contents with another object.
    void swap (optional_impl& rhs) CXXO_NOEXCEPT {
        if (!_engaged && !rhs._engaged) return;
        else if (_engaged && !rhs._engaged) { rhs= *this; *this= nullopt; }
        else if (!_engaged && rhs._engaged) { *this= rhs; rhs= nullopt; }
        else {
            using std::swap;
            swap(*cast_it(), *rhs.cast_it());
        }
        
    }

#if (CXXOMFORT_CXX_STD >= 2011)
    template <typename... Args>
    void emplace (Args&&... args) {
        *this= nullopt;
        *this= value_type(std::forward<Args>(args)...);
    }
    
#else
    #if 0
    void emplace () {
        this->assign(nullopt);
        this->initialize();
    }
    template <typename A1>
    void emplace (CXXO_FWD_REF(A1) a1) {
        this->assign(nullopt);
        this->initialize(std::forward<A1>(a1));
    }

    template <typename A1, typename A2>
    void emplace (CXXO_FWD_REF(A1) a1, CXXO_FWD_REF(A2) a2) {
        this->assign(nullopt);
        this->initialize(std::forward<A1>(a1), std::forward<A2>(a2));
    }

    template <typename A1, typename A2, typename A3>
    void emplace (CXXO_FWD_REF(A1) a1, CXXO_FWD_REF(A2) a2, CXXO_FWD_REF(A3) a3) {
        this->assign(nullopt);
        this->initialize(std::forward<A1>(a1), std::forward<A2>(a2), std::forward<A3>(a3));
    }
    #endif
#endif


    private:
#pragma pack(push,2)
    storage_type    _storage;
    bool            _engaged;
#pragma pack(pop)
    value_type*          cast_it () {
        return reinterpret_cast<value_type*> (std::addressof(_storage));
    }
    value_type const*    cast_it () const {
        return reinterpret_cast<value_type const*> (std::addressof(_storage));
    }
    void destruct () {
        if (_engaged) cast_it()->~value_type();
    }


};

#endif


#if 1
//
// The implementation of an optional<T> for fundamental types T 
// is fairly simple and can be completely done inplace
// This implementation allows it to be trivially copy-constructible, 
// copy-assignable and destructible, as well as 
// constexpr-constructible in C++11.
//
template <typename T>
class optional_impl<T, typename std::enable_if<std::is_fundamental<T>::value>::type > {
    private:
    typedef T       storage_type;
    protected:
    typedef T       value_type;
    static const bool is_specialized = true;

    CXXO_CONSTEXPR optional_impl () CXXO_NOEXCEPT
    : _engaged(false) {}
    // trivially copyable
#if (CXXOMFORT_CXX_STD >= 2011)
    constexpr optional_impl (optional_impl const&) noexcept = default;
#else
    optional_impl (optional_impl const& r) CXXO_NOEXCEPT
    : _engaged(r._engaged), _storage(r._storage) {}
#endif
    CXXO_CONSTEXPR optional_impl (nullopt_t) CXXO_NOEXCEPT
    : _engaged(false) {}
    CXXO_CONSTEXPR explicit optional_impl (T t) CXXO_NOEXCEPT
    : _engaged(true), _storage(t) {}
    // trivially destructible
    CXXOMFORT_CXX11_CODE(~optional_impl() = default,);
    
    CXXO_CONSTEXPR bool engaged () const CXXO_NOEXCEPT { return _engaged; }
    
    CXXO_CONSTEXPR CXXO_EXPLICIT_OPERATOR(bool) () const CXXO_NOEXCEPT {
        return _engaged;
    }
    
    // trivially copy-assignable
#if (CXXOMFORT_CXX_STD >= 2011)
    optional_impl& operator= (optional_impl const&) CXXO_NOEXCEPT = default;
#else
    optional_impl& operator= (optional_impl const& r) CXXO_NOEXCEPT {
        _engaged= r._engaged;
        _storage= r._storage;
        return *this;
    }
#endif

    optional_impl& operator= (nullopt_t) CXXO_NOEXCEPT {
        _engaged=false;
        return *this;
    }
    optional_impl& operator= (T t) CXXO_NOEXCEPT {
        _engaged= true;
        _storage= t;
        return *this;
    }
    
    CXXO_CONSTEXPR T const& operator* () const CXXO_NOEXCEPT {
        return _storage;
    }
    
    T& operator* () CXXO_NOEXCEPT {
        return _storage;
    }
    
    T const* operator-> () const CXXO_NOEXCEPT {
        return std::addressof(_storage);
    }
    T* operator-> () CXXO_NOEXCEPT {
        return std::addressof(_storage);
    }
    
    T const& value () const {
        if (_engaged) return _storage; else throw bad_optional_access("call to value() const");
    }
    
    T& value () {
        if (_engaged) return _storage; else throw bad_optional_access("call to value() non-const");
    }

    T value_or (T alt) const CXXO_NOEXCEPT { return (_engaged ? _storage : alt); }

    // emplace constructions can only take one argument
    void emplace (T t) CXXO_NOEXCEPT {
        (*this= t);
    }
    void emplace (...) {
        static_assert( std::is_compound<T>::value, "optional::emplace over a fundamental type does not take more than one argument");
    }
    
    void swap (optional_impl& o) CXXO_NOEXCEPT {
        using std::swap;
        std::swap(_engaged, o._engaged);
        std::swap(_storage, o._storage);
    }
    
    private:
#pragma pack(push,2)
    bool            _engaged;
    T               _storage;
#pragma pack(pop)
};
#endif

// detail
}

#endif
