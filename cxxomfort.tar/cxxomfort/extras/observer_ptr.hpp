#ifndef CXXOMFORT_EXTRAS_OBSERVER_PTR_HPP
#define CXXOMFORT_EXTRAS_OBSERVER_PTR_HPP
/**
 * @file cxxomfort/extras/observer_ptr.hpp
 * @brief Implements observer_ptr proposal (n3840)
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 * 
* For documentation see @link Features/Extras @endlink .
* 
* Reflection header: experimental/memory (to be mapped in cstd)
* 
**/

#include <cxxomfort/config.hpp>
#define CXXOMFORT_IMPLEMENTS_n3840 CXXO_BACKPORT()
#define CXXOMFORT_IMPLEMENTS_n4282 CXXO_BACKPORT()
#include <memory>
#include <functional> // std::hash

#if (defined(CXXOMFORT_NOTICES))
    #pragma message CXXO_NOTICE("enabled extras: observer_ptr<T> from TR2")
#endif

namespace cxxomfort {
namespace extras {
namespace observer_ptr {

/**
 * @brief observer_ptr - the world's dumbest smart pointer
 * 
 * @c observer_ptr  is a simple "pointer wrapper" type that manages a 
 * non-owning pointer. No further "intelligence" is added to the wrapper's 
 * behaviour. It is added to C++17 as an "experimental".
 * 
 * @sa n3840
 * 
 */
template <typename W>
struct observer_ptr {
    typedef W element_type;
    typedef W* pointer;
    typedef W& reference;
    typedef observer_ptr<W> this_type;
    
    
    CXXO_CONSTEXPR observer_ptr () CXXO_NOEXCEPT  //!< def-ctor
    : w(nullptr) {}
#if (CXXOMFORT_CXX_STD < 2011)
    CXXO_CONSTEXPR observer_ptr (observer_ptr const& r) CXXO_NOEXCEPT : w(r.w) {}
#else
    CXXO_CONSTEXPR observer_ptr (observer_ptr const& r) CXXO_NOEXCEPT = default;
#endif

    CXXO_COMPILER_ observer_ptr (std::nullptr_t) CXXO_NOEXCEPT //!< nullptr-ctor
    : w(nullptr) {}
    CXXO_CONSTEXPR observer_ptr (pointer r) CXXO_NOEXCEPT  //!< pointer-ctor
    : w(r) {}
    
    // interfaces defined in cppreference
    CXXO_CONSTEXPR pointer get () CXXO_NOEXCEPT { return w; }
    CXXO_CONSTEXPR pointer const get () const CXXO_NOEXCEPT { return w; }
    
    //! resets to pointer 'p', or @c nullptr .
    CXXO_CONSTEXPR void       reset (pointer r = nullptr) CXXO_NOEXCEPT { w=r; }
    //! resets to @c nullptr .
    CXXO_CONSTEXPR pointer    release ()  CXXO_NOEXCEPT { pointer r=w; this->reset(); return r; }
    
    CXXO_CONSTEXPR void       swap (observer_ptr& r) CXXO_NOEXCEPT {
        using std::swap;
        swap(this->w, r.w);
    }

    // extra interfaces
    //! checks if observer is set.
    CXXO_CONSTEXPR bool       is_set () const CXXO_NOEXCEPT { return !(w==nullptr); }

    //! conversion to @c pointer  type (explicit).
    CXXO_EXPLICIT_OPERATOR(pointer) const CXXO_NOEXCEPT { return this->get(); }
    //! conversion to @c bool  type (explicit).
    CXXO_EXPLICIT_OPERATOR(bool) const CXXO_NOEXCEPT { return this->is_set(); }

    reference       operator* () const CXXO_NOEXCEPT { return *w; }
    pointer         operator-> () const CXXO_NOEXCEPT { return w; }


    CXXO_CONSTEXPR friend operator== (observer_ptr const& l, observer_ptr const& r) CXXO_NOEXCEPT {
        return l.w == r.w; 
    }
    

    private:
    W* w;
};

//! makes an observer_ptr
template <typename W>
observer_ptr<W> make_observer (W* w) CXXO_NOEXCEPT {
    return observer_ptr<W> (w);
}


template <typename W>
bool operator!= (observer_ptr<W> const& l, observer_ptr<W> const& r) CXXO_NOEXCEPT {
    return !(l==r);
}

template <typename W>
bool operator< (observer_ptr<W> const& l, observer_ptr<W> const& r) CXXO_NOEXCEPT {
    return (l.get()<r.get());
}

template <typename W>
bool operator<= (observer_ptr<W> const& l, observer_ptr<W> const& r) CXXO_NOEXCEPT {
    return !(r<l);
}

template <typename W>
bool operator> (observer_ptr<W> const& l, observer_ptr<W> const& r) CXXO_NOEXCEPT {
    return (r<l);
}

template <typename W>
bool operator>= (observer_ptr<W> const& l, observer_ptr<W> const& r) CXXO_NOEXCEPT {
    return !(l<r);
}

} // observer_ptr
} // extras
} // cxxomfort

#endif
