#ifndef CXXOMFORT_EXTRAS_OPTIONAL_HPP
#define CXXOMFORT_EXTRAS_OPTIONAL_HPP
/**
 * @file cxxomfort/extras/optional.hpp
 * @brief Implementation of <code>optional<T></code> proposal.
 */

/*
 *
 * Optional as per C++ Proposal (n1878):
 * http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2005/n1878.htm
 * Also incorporates some implementation details and fixes from n3527
 * http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2013/n3527.html
 *
 */
#include <cxxomfort/config.hpp>
#include <cxxomfort/base.hpp>
#include "../base/explicit_cast.hpp"
#include <type_traits>
#include <cassert>
#include <stdexcept>
#include <iostream>

#if defined(CXXOMFORT_NOTICES)
    #pragma message CXXO_NOTICE("enabled extras: optional<T> implementation from experimental")
#endif

namespace cxxomfort {
namespace extras {
namespace optional {

/**
 * @class cxxomfort::extras::optional::optional
 * @brief Wrapper for Nullable, Regularized types
 * @ingroup extra-features
 * @anchor optional
 *
 * @c optional is a nullable-type wrapper for type @e T - it can store
 * a value of type T or "nothing" (indicated by @c 'nullopt').
 * It is indirectly convertible to <code>T const&</code>
 * and provides pointer-like access interface semantics.
 *
 * Differences with the C++14 proposal:
 *
 * * (TBD)
 *
 * Implementation specifics:
 *
 * <ul><li>Support for @c alignof  and @c aligned_storage are required in C++03 mode.
 * </li><li>If @p T is a fundamental type, @c optional<T>  is :
 * * In C++03, trivially copyable, trivially assignable
 * and trivially destructible.
 * * In C++11, besides the above, a "literal type", and all the
 * constructors are @c noexcept(true) .
 * </li></ul>
 *
 * @sa n1878, n3527
**/
template <typename T> class optional;
//template <typename T, typename Enabler=void> class optional;

/*
struct nullopt_t {
  struct init{};
  CXXOMFORT_CXX11_CODE(constexpr,) nullopt_t(init){};
};
*/


//! disengaged-state tag indicator for @c optional
CXXOMFORT_CXX11_CODE(constexpr,const) struct nullopt_t {
    // added in c++17
    CXXO_CONSTEXPR explicit nullopt_t (int) CXXO_NOEXCEPT {}
} nullopt (3);

//! emplace-construction tag indicator for @c optional
CXXOMFORT_CXX11_CODE(constexpr,const) struct in_place_t{} in_place = {};


//! bad access exception for @c optional
class bad_optional_access : public std::logic_error {
    public:
    explicit bad_optional_access(const std::string& what_arg) : std::logic_error(what_arg) {}
    explicit bad_optional_access(const char* what_arg) : std::logic_error(what_arg) {}
};

//! Trait identifying optional types
template <typename T> struct is_optional;

/*
 * Declaration of nonmember functions
 */
//! equality comparison
template<typename T> inline CXXO_CONSTEXPR bool operator== (optional<T> const&, optional<T> const&);
template<typename T> inline CXXO_CONSTEXPR bool operator!= (optional<T> const&, optional<T> const&);
//! get the value of an @b engaged optional
template<typename T> inline T const& get ( optional<T> const& opt );
//! get the value of an @b engaged optional
template<typename T> inline T&       get ( optional<T> & opt );
//! get a pointer to value of an optional, or @c nullptr if disengaged
template<typename T> inline T const* get ( optional<T> const* opt );
//! get a pointer to value of an optional, or @c nullptr if disengaged
template<typename T> inline T*       get ( optional<T>* opt );
//! get a pointer to value of an optional, or @c nullptr if disengaged
template<typename T> inline T const* get_pointer ( optional<T> const& opt );
//! get a pointer to value of an optional, or @c nullptr if disengaged
template<typename T> inline T*       get_pointer ( optional<T> & opt );
//! global swap
template<typename T> inline void swap( optional<T>& x, optional<T>& y ) ;

//
// implementation is loaded here separately,
// might change between c++11 and c++03
//

#include "optional-impl.hpp"

// ----

/**
 * @brief Trait that identifies a @c optional  type.
 * */
template <typename T> struct is_optional
: public std::false_type {};

template <typename T> struct is_optional< optional<T> >
: public std::true_type {};


//
// central interface for optional
//
template <typename T>
class optional
: public detail::optional_impl<T> {
    private:
    typedef detail::optional_impl<T> base_type;
    public:
    typedef T value_type;


    CXXO_CONSTEXPR optional () CXXO_NOEXCEPT : base_type() {};
    CXXO_CONSTEXPR optional (optional const& p) : base_type(p) {};
    CXXO_CONSTEXPR optional (T const& v) CXXO_NOEXCEPT : base_type(v) {};
    CXXO_CONSTEXPR optional (nullopt_t) CXXO_NOEXCEPT : base_type(nullopt) {};

    template<typename A1>
    optional (in_place_t, CXXO_FWD_REF(A1) a1)
    : base_type(in_place, a1) {}
    template <typename A1, typename A2>
    optional (in_place_t, CXXO_FWD_REF(A1) a1, CXXO_FWD_REF(A2) a2)
    : base_type(in_place, std::forward<A1>(a1), std::forward<A2>(a2)) {}

    ~optional() {};


    //optional& operator= (optional const&) CXXO_NOEXCEPT;
#if (1 || CXXOMFORT_CXX_STD >= 2011)
    using base_type::operator= ;
#else
    optional& operator= (optional const& r) {
        ((base_type*)this)->operator= ((base_type&)(r));
        return *this;
    }
    optional& operator= (T const& r) {
        ((base_type*)this)->operator= (r);
        return *this;
    }
    optional& operator= (nullopt_t) CXXO_NOEXCEPT {
        ((base_type*)this)->operator= (nullopt);
        return *this;
    }
#endif

#if (CXXOMFORT_CXX_STD >= 2011 || (CXXOMFORT_CXX_EMULATION >= 2011 && CXXO_COMPILER_SUPPORT_explicit_operator>0))
    using base_type::operator bool;
#else
    using base_type::CXXO_EXPLICIT_OPERATOR(bool);
#endif

    // unchecked access

    using base_type::operator* ;
    using base_type::operator-> ;

    // checked access

    using base_type::value;
    using base_type::value_or;

    using base_type::swap;
    //void swap (optional& b) {
    //    ((base_type*)this)->swap( (base_type&)(b) );
    //}

    using base_type::is_specialized;

};

//
// nonmember get
//

//! nonmember 'get'
template <typename T>
inline T const* get_ptr (optional<T> const& o) { return o.operator->(); }
//! nonmember 'get'
template <typename T>
inline T const& get (optional<T> const& o) { return o.operator*(); }
//! nonmember 'get'
template <typename T>
inline T& get (optional<T>& o) { return o.operator*(); }


template <typename T> inline
T* get (optional<T>* po) {
    return (*po == nullopt) ? nullptr : po->operator->();
}

template <typename T> inline
T const* get (optional<T> const* po) {
    return (*po == nullopt) ? nullptr : po->operator->();
}

//! global swap
template <typename T>
inline void swap (optional<T>& a, optional<T>& b) {
    a.swap(b);
}


//! utility typedef for an <code>optional<signed int></code>.
typedef optional<signed int> opt_int_t;
//! utility typedef for an <code>optional<unsigned int></code>.
typedef optional<unsigned int> opt_uint_t;


#if (CXXOMFORT_CXX_STD >= 2011)

#endif


} // optional::
} // extras::
} // cxxomfort::


/*
// Maps hash< optional<T> > with the same semantics as hash<T>
// requires <functional> to be included
// #include <functional>
namespace std {
#if (!defined(CXXOMFORT_CXX11_MODE) && CXXOMFORT_CXX11_EMULATION==0)
namespace tr1 {
#endif

template <typename T> struct hash< ::cxxomfort::extras::optional::optional<T> >
: protected hash<T> {
    private:
    typedef hash<T> base_t;
    public:
    typename hash<T>::result_type operator() (::cxxomfort::extras::optional::optional<T> const& ot) const {
        using namespace cxxomfort::extras::optional;
        if (ot != nullopt) {
            std::cerr<< "[hash<optional> with engaged var]"<< std::endl;
            T const& t (*ot);
            return static_cast< base_t const* >(this)->operator()(t);
        } else return hash<T*>()(0);
    }

};

#if (!defined(CXXOMFORT_CXX11_MODE) && CXXOMFORT_CXX11_EMULATION==0)
}
#endif
}
*/

#endif

