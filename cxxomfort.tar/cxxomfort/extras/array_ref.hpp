#ifndef CXXOMFORT_EXTRAS_ARRAY_REF_HPP
#define CXXOMFORT_EXTRAS_ARRAY_REF_HPP
/**
 * @file cxxomfort/extras/array_ref.hpp
 * @brief Implements array_ref proposal (n3334)
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 * 
* For documentation see @link Features/Extras @endlink .
* 
* Reflection header: experimental/array_ref
* 
**/

#include <cxxomfort/base.hpp>
#include <iterator>
#include <stdexcept>
#include <vector>
#include <array>
#include <valarray>
#include <cxxomfort/library/fixed_vector.hpp>
#include <cxxomfort/extras/dynarray.hpp>

#define CXXOMFORT_IMPLEMENTS_n3334 CXXO_LIBRARY()

#if (defined(CXXOMFORT_NOTICES))
    #pragma message CXXO_NOTICE("enabled extras: array_ref<T> implementation")
#endif


namespace cxxomfort {
namespace extras {
namespace array_ref {

/**
 * @brief Array view for sequences, from n3334
 * @anchor array_ref
 * @addtogroup extra-features
 * @sa n3334
 * 
 * A @c array_ref is a non-owning view of a sequence of 
 * *contiguous* elements via a simple {pointer+length} package.
 * 
 * It provides some of the same operatios available for readable
 * sequences, in particular begin() and end().
 * 
 * This implementation is intended to be used for sequences of 
 * const elements (ie.: template argument is <code>T const</code>).
 * 
**/
template <typename T>
class array_ref {
    public:
    typedef T       value_type;
    typedef typename std::add_const<T>::type * pointer;
    typedef typename std::add_const<T>::type * const_pointer;
    typedef T&                reference;
    typedef typename std::add_const<T>::type & const_reference;
    typedef ptrdiff_t    difference_type;
    typedef size_t       size_type;
    typedef T*           iterator;
    typedef T const*     const_iterator;
    typedef std::reverse_iterator<const_iterator>  const_reverse_iterator;
    
    public:
    
    CXXO_CONSTEXPR array_ref () CXXO_NOEXCEPT : ptr_(nullptr), len_(0) {}
    CXXO_CONSTEXPR array_ref (array_ref const& p) CXXO_NOEXCEPT : ptr_(p.ptr_), len_(p.len_) {}
    CXXO_CONSTEXPR array_ref (T const* p, size_t l) CXXO_NOEXCEPT : ptr_(p), len_(l) {}
    
    template <size_t N>
    explicit array_ref (T(&arr)[N]) CXXO_NOEXCEPT : ptr_(arr), len_(N) {}

    // view from related non-const view, only for const view, for C++11-onwards
#if (CXXOMFORT_CXX_STD >= 2011)
    template <bool B = std::is_const<T>::value, typename std::enable_if<B,int>::type=0 >
    array_ref (array_ref< typename std::remove_const<T>::type > const& av)
    : ptr_(av.ptr_), len_(av.len_) {}
#endif

    // view ref from array<>; should be a std::array conversion operator but can't in C++03, C++11
    template <size_t N>
    array_ref (std::array<T,N> const& arr) CXXO_NOEXCEPT
    : ptr_(arr.data()), len_(arr.size()) {}
    
    // view ref from vector; should be a std::array conversion operator but can't in C++03, C++11
    template <typename Alloc>
    array_ref (std::vector<T,Alloc> const& vec) 
    : ptr_(std::addressof(vec[0])), len_(vec.size()) {}
    
    // view ref from valarray; should be a std::array conversion operator but can't in C++03, C++11
    array_ref (std::valarray<T> const& va) 
    : ptr_(std::addressof(va[0])), len_(va.size()) {}

    // view ref from dynarray; should be a std::array conversion operator but can't in C++11
    array_ref (::cxxomfort::extras::dynarray::dynarray<T> const& da) CXXO_NOEXCEPT
    : ptr_(da.data()), len_(da.size()) {}

    // view_ref from fixed_vector; should be a fixed_vector conversion operator but that would include extras from library.
    array_ref (::cxxomfort::fixed_vector<T> const& vec) CXXO_NOEXCEPT 
    : ptr_(vec.data()), len_(da.size()) {}

    // access to elements
    //reference       at (size_t len) { assert_range(len); return ptr_[len]; }
    const_reference at (size_t len) const { assert_range(len); return ptr_[len]; }
    //reference       operator[] (size_t len) CXXO_NOEXCEPT { return ptr_[len]; }
    const_reference operator[] (size_t len) const CXXO_NOEXCEPT { return ptr_[len]; }
    
    // view info
    //! @return size of the view as a @c size_t .
    size_t          size () const CXXO_NOEXCEPT { return len_; }
    //! @return @c bool .
    bool            empty () const CXXO_NOEXCEPT { return size() == 0; }
    //! @return pointer to the view's data.
    pointer         data () CXXO_NOEXCEPT { return ptr_; }
    //! @return pointer to the view's data.
    const_pointer   data () const CXXO_NOEXCEPT { return ptr_; }
    
    // iterators
    const_iterator  cbegin () const CXXO_NOEXCEPT { return ptr_; }
    const_iterator  cend () const CXXO_NOEXCEPT { return ptr_+len_; }
    const_iterator  begin () const CXXO_NOEXCEPT { return cbegin(); }
    const_iterator  end () const CXXO_NOEXCEPT { return cend(); }

    const_reverse_iterator    crbegin () const CXXO_NOEXCEPT { return const_reverse_iterator(ptr_+len_); }
    const_reverse_iterator    crend () const CXXO_NOEXCEPT { return const_reverse_iterator(ptr_); }
    const_reverse_iterator    rbegin () const CXXO_NOEXCEPT { return crbegin(); }
    const_reverse_iterator    rend () const CXXO_NOEXCEPT { return crend(); }

    const_iterator  front () const { return ptr_[0]; }
    const_iterator  back () const { return ptr_[len_-1]; }
    
    array_ref       slice (size_t skip) const {
        return (skip > len_) ? array_ref() : array_ref(ptr_+skip, len_-skip);
    }
    array_ref       slice (size_t skip, size_t n) const {
        return slice(skip);
    }
    
    private:
    void assert_range (size_t len) const {
        if (len>=len_) throw std::out_of_range("array_ref: out of range");
    }
    
    const_pointer   ptr_;
    size_t const    len_;
}; // array_ref

template <typename Ty, size_t N>
array_ref<Ty> make_array_ref(Ty(&arr)[N]) {
    return array_ref<Ty>(arr);
}

template <typename Ty, size_t N>
array_ref<Ty> make_array_ref(std::array<Ty,N> const& a) {
    return array_ref<Ty>(a);
}


template <typename Ty>
array_ref<Ty> make_array_ref(std::vector<Ty> const& v) {
    return array_ref<Ty>(v);
}

template <typename Ty>
array_ref<Ty> make_array_ref(std::valarray<Ty> const& v) {
    return array_ref<Ty>(v);
}


template <typename Ty>
array_ref<Ty> make_array_ref(::cxxomfort::extras::dynarray::dynarray<Ty> const& v) {
    return array_ref<Ty>(v);
}

} // namespace array_ref
} // namespace extras
}

#endif
