#pragma message CXXO_WARNING("this header is deprecated. New header is <cxxomfort/forward_list.hpp>")
#include <cxxomfort/forward_list.hpp>
