#ifndef CXXOMFORT_EXTRAS_OPTIONAL_IO_HPP
#define CXXOMFORT_EXTRAS_OPTIONAL_IO_HPP

#include <cxxomfort/extras/optional.hpp>
#include <string>
#include <sstream>
#include <iostream>

namespace cxxomfort {
namespace extras {
namespace optional {

struct io_optional_empty {
    public:
    static std::string& value() {
        static std::string v= "{}";
        return v;
    }
};

template <typename T>
std::istream& operator>> (std::istream& is, optional<T>& o) {
    std::string s;
    if (is>> s) {
        if (s == io_optional_empty::value()) {
            o= optional<T>();
        } else {
            // try to convert via a stringstream
            std::stringstream f(s);
            T t;
            if (f>> t) {
                o= t;
            } else {
                is.clear (std::ios::failbit);
            }
        }
    }
    return is;
}

template <typename T>
std::ostream& operator<< (std::ostream& os, optional<T> const& o) {
    os<< o.value_or(io_optional_empty::value());
    return os;
}

}
}
}


#endif
