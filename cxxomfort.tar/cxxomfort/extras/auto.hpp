#ifndef CXXOMFORT_EXTRAS_AUTO_HPP
#define CXXOMFORT_EXTRAS_AUTO_HPP
/**
 * @file auto.hpp
 * @brief Implements new auto semantics in C++03 where compatible.
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 *
 * Interfaces defined in this header:
 *
 * * CXXO_DECLTYPE (where emulation is provided by the compiler)
 * * CXXO_AUTO (where emulation is provided by the compiler)
 * 
*/

/**
 * @def CXXO_DECLTYPE
 * @brief Obtains the type of an expression, equivalent to eg.: @c __typeof__ (C++03) or @c decltype (C++11).
 */
/**
 * @def CXXO_AUTO
 * @brief Creates a variable with type determined by the initializer expression, equivalent to eg.: @c auto (C++11).
 */

#include <cxxomfort/config.hpp>
#include <cxxomfort/base.hpp>

#if (defined(CXXOMFORT_NOTICES))
    #pragma message CXXO_NOTICE("enabled extras: 'auto' emulation")
#endif

//namespace cxxomfort {
//namespace extras {

#if ((CXXOMFORT_CXX_STD >= 2011) || (CXXO_COMPILER_SUPPORT_auto==1 && CXXO_COMPILER_SUPPORT_decltype==1))

	#if (defined(CXXOMFORT_NOTICES) && CXXOMFORT_NOTICES > 1)
		#pragma message CXXO_NOTICE("using c++11's definition of auto")
	#endif
	#define CXXOMFORT_USING_auto
	#define CXXO_AUTO(var,expr) auto var ( expr )
	#define CXXO_AUTO_REF(var,expr) auto& var = expr
	#define CXXO_AUTO_CREF(var,expr) auto const& var (expr)
	#define CXXO_DECLTYPE(expr) decltype (expr)
	#define CXXO_TYPEOF(expr) __typeof__ (expr)

#else
// Not in C++11 mode

	#if defined (CXXOMFORT_NOTICES)
		#pragma message CXXO_NOTICE("enabled auto/decltype helpers")
	#endif

	#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC && CXXOMFORT_COMPILER_VERSION >= 300) \
	 || (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_CLANG)

		#define CXXOMFORT_USING_auto
		#define CXXO_AUTO(var,expr) __typeof__(expr) var (expr)
		#define CXXO_AUTO_CREF(var,expr) __typeof__(expr) const& var ( expr )
		#define CXXO_DECLTYPE(expr) __typeof__(expr)
		#define CXXO_TYPEOF(expr) __typeof__(expr)


	#elif (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_MSC && CXXOMFORT_COMPILER_VERSION >= 150)
		#define CXXOMFORT_USING_auto
		#include "auto-impl.hpp"
		#define CXXO_AUTO(var,expr) CXXO_DECLTYPE(expr) var ( expr )

	#else // no valid compiler found
		#error " cxxomfort library -- error: compiler doesn't support '__typeof__' or equiv."
	#endif // compiler test

#endif // no CXX11 support

//} //cxxomfort::extras
//} //cxxomfort

#endif // CXXOMFORT_EXTRAS_LOCALFN_HPP

