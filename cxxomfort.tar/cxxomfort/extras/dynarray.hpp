#ifndef CXXOMFORT_EXTRAS_DYNARRAY_HPP
#define CXXOMFORT_EXTRAS_DYNARRAY_HPP
/**
 * @file cxxomfort/extras/dynarray.hpp
 * @brief Implementation of n2648 "C++ Dynamic Arrays" proposal, "dynarray" component
 * @author Luis Machuca Bezzaza
 * 
 * "dynarray" is a proposal for a container of contiguous elements where 
 * the container size is fixed at construction time - in a way similar to 
 * std::array<> except the size is specified at runtime - and where 
 * storage of the elements can be handled *at the stack* at the discretion 
 * of the compiler (which requires toolkit support).
 * 
 * The implementation here disregards the facet of stack-based allocation 
 * (which is not practically available in C++03/11 anyway) and instead 
 * focuses on the facet of the ever-missing from the C++ standard toolkit's 
 * "fixed vector" / "dynamic array" container requirement.
 * 
 */


// To invoke this via a std header see cstd/dynarray.

// TBD: implement option to have dynarray be copy assignable

#include <cxxomfort/base.hpp>
#include <cxxomfort/sequences.hpp> // is_iterator
#include <iterator>
#include <algorithm>
#include <stdexcept>
#include <memory>
#define CXXOMFORT_IMPLEMENTS_n2648 CXXO_LIBRARY()

//
// using dynarray
//
#if (defined(CXXOMFORT_NOTICES))
    #pragma message CXXO_NOTICE("enabled extras: dynarray<T> implementation")
#endif


#if (CXXOMFORT_CXX_STD >= 2011)
    //#define CXXO_NOEXCEPT CXXO_NOEXCEPT
    #define INIT_LIST(T) std::initializer_list<T> const&
    #define _DELETED_ =delete
#else
    #define _DELETED_ 
#endif

namespace cxxomfort{
namespace extras{
namespace dynarray{

template <typename T> class dynarray;

/**
 * @brief Dynamic array (aka fixed vector) container for C++ from n2648 ("C++ Dynamic Arrays") by Lawrence Crowl
 * @anchor dynarray
 * @ingroup extra-features
 * @sa n2648
 * 
 * A @c dynarray is a container of contiguous storage of elements 
 * of type @e T for which the storage of the elements can be handled 
 * at the stack at the discretion of the compiler. 
 * It behaves much like a <code>vector<T></code> except there is no resize or 
 * reserve support - the size of the container is fixed at construction time.
 * 
 * <b>From n2648</b>:
 * 
 * "The header <dynarray> defines a class template for storing sequences 
 * of objects where the size is fixed at construction. 
 * A dynarray supports random access iterators. 
 * An instance of dynarray<T> stores elements of type T. 
 * The elements of a dynarray are stored contiguously, meaning that if d 
 * is an dynarray<T> then it obeys the identity 
 * &a[n] == &a[0] + n for all 0 <= n < N."
 * 
 *
 * 
 * A @c dynarray  presents the some of the same interface convenients as 
 * other standard containers:
 * 
 * * except where specified, no members throw
 * * copy constructor and iterator constructor
 * * indexed accesors (@c at() and @c operator[] ) with usual semantics
 * * iteration member accesors and types
 * * nonmember equality comparison operators
 * 
 * This implementation is slightly different than the one in n2648 
 * while retaining the same functionality.
 * 
 * Key differences:
 * 
 * * no support for stack-allocation - this implementation focuses on 
 * the lack of a "fixed vector" container type in the Standard.
 * * cxxomfort's @c dynarray is move-constructible
 *  (but -very importantly- not move-assignable!).
 * 
 * To invoke this in a standard manner, the header @c <dynarray> is 
 * provided in cstd/experimental directory.
 * 
 */
template <typename T> class dynarray {
    typedef dynarray<T>  this_type;

    public:
    typedef T            value_type;         ///< type of contained value
    typedef size_t       size_type;
    typedef ptrdiff_t    difference_type;
    typedef value_type&       reference;
    typedef value_type const& const_reference;
    typedef value_type*       pointer;
    typedef const value_type* const_pointer;
    // see if those should be changed to checked iterators?
    typedef T*           iterator;           ///< @c iterator type
    typedef T const*     const_iterator;     ///< @c const_iterator type
    typedef std::reverse_iterator<iterator> reverse_iterator;
    typedef std::reverse_iterator<const_iterator> const_reverse_iterator;

    public:

    explicit dynarray (size_type N);     ///< (1) count-constructor
    dynarray (size_type N, T const& v);  ///< (3) count-constructor
    dynarray (dynarray const &V);        ///< (5) copy-constructor
    /// iterator-constructor
    template <typename It>
    dynarray (It ini, It fin, typename std::enable_if<is_iterator<It>::value,bool>::type* = nullptr);
    
    ////! Inicializa un vector de una lista est�tica en C++11
#if (CXXOMFORT_CXX_STD >= 2011) || defined(DOXYGEN_DOC)
    dynarray (std::initializer_list<T> const&) CXXO_NOEXCEPT;             ///< (7) initializer_list-ctor
#endif

    dynarray (CXXO_RV_REF(dynarray) p) CXXO_NOEXCEPT;  ///< move-constructor

    ~dynarray ();                                 ///< destructor

    size_type       max_size () const CXXO_NOEXCEPT { return std::numeric_limits<size_t>::max(); }
    //! size of container (fixed value)
    size_type       size () const CXXO_NOEXCEPT { return m_sz; } // nothrow
    bool            empty () const CXXO_NOEXCEPT { return m_p == nullptr && m_sz == 0; } // nothrow

    //! access of storage buffer
    const T*        data () const CXXO_NOEXCEPT { return m_p; } // nothrow
    T*              data () CXXO_NOEXCEPT { return m_p; } // nothrow

    //! checked access to element at index @em idx
    const_reference at (size_t idx) const {
        if (m_sz <= idx) throw std::out_of_range("dynarray at(size_t) const");
        return m_p[idx];
    }
    //! @overloads at
    reference at (size_t idx) {
        if (m_sz <= idx) throw std::out_of_range("dynarray at(size_t)");
        return m_p[idx];
    }

    //! direct access to element at index @em idx
    const_reference operator[] (size_t idx) const CXXO_NOEXCEPT { // nothrow
        return m_p[idx];
    }
    //! @overloads operator[]
    reference operator[] (size_t idx) CXXO_NOEXCEPT { // nothrow
        return m_p[idx];
    }

    const_reference front () const { return m_p[0]; } // nothrow
    reference       front () { return m_p[0]; } // nothrow
    const_reference back  () const { return m_p[m_sz-1]; } // nothrow
    reference       back () { return m_p[m_sz-1]; } // nothrow

    //@ Iterator to the beginning
    const_iterator  cbegin () const CXXO_NOEXCEPT { return m_p; } // nothrow
    //@ Iterator to the beginning
    const_iterator  begin () const CXXO_NOEXCEPT { return cbegin(); } // nothrow
    //@ @overloads begin
    iterator        begin () CXXO_NOEXCEPT { return m_p; } // nothrow
    const_iterator  cend () const CXXO_NOEXCEPT { return m_p+m_sz; } // nothrow
    //@ Iterador apuntando al final+1.
    const_iterator  end () const CXXO_NOEXCEPT { return cend(); } // nothrow
    //* @overloads end
    iterator        end   () CXXO_NOEXCEPT { return m_p+m_sz; } // nothrow

    const_reverse_iterator     rbegin () const CXXO_NOEXCEPT {
        return const_reverse_iterator(this->end());
    }
    reverse_iterator     rbegin () CXXO_NOEXCEPT {
        return reverse_iterator(this->end());
    }
    const_reverse_iterator     rend () const CXXO_NOEXCEPT {
        return const_reverse_iterator(this->begin());
    }
    reverse_iterator     rend () CXXO_NOEXCEPT {
        return reverse_iterator(this->begin());
    }

    void fill (T const& v) CXXO_NOEXCEPT {
        for (iterator i= this->begin(); i != this->end(); ++i) {*i= v;}
    }

    private:
    size_t m_sz;
    T* m_p;

    // Move Interface
    private:
    CXXO_COPYABLE_MOVABLE_NONASSIGNABLE (dynarray);

    T* alloc (size_type n) {
        return reinterpret_cast<T*>( new char [n * sizeof(T)] );
    }

    private:
    dynarray ()          _DELETED_ ;    //< non-default-constructible
    //dynarray& operator= (dynarray const&) _DELETED_ ;    //< non-assignable

};

// Copy Constructor
template <typename T>
dynarray<T>::dynarray (dynarray const &V) // strong_throw
: m_p ( alloc(V.m_sz) ), m_sz(V.m_sz) {
    try {
        using namespace std;
        uninitialized_copy(V.begin(), V.end(), this->begin());
    } catch(...) {
        delete[] m_p; m_p= nullptr;
        throw; // rethrow
    }// ~catch
}


// Constructor cantidad (N)
template <typename T>
dynarray<T>::dynarray (size_type N) // strong_throw
: m_sz(N), m_p ( alloc(N) ) {
    size_t i;
    try {
        using namespace std;
        uninitialized_fill(m_p, m_p+m_sz, T());
    } catch(...) {
        for (; i > 0 ; --i) (m_p+i-1)->~T();
        m_sz= 0;
        throw; // rethrow
    }//~catch
}

template <typename T>
dynarray<T>::dynarray (size_type N, T const& v) // strong_throw
: m_sz(N), m_p ( alloc(N) ) {
    using namespace std;
    size_t i= 0;
    try {
        for (i=0; i < m_sz; ++i) ::new (m_p+i) T(v);
        //uninitialized_fill(m_p, m_p+m_sz, v);
    } catch(...) {
        for (; i > 0 ; --i) (m_p+i-1)->~T();
        m_sz= 0;
        throw; // rethrow
    }//~catch
}


// This assumes none of the involved constructors will throw!
template <typename T>
template <typename It>
dynarray<T>::dynarray (It ini, It fin, typename std::enable_if<is_iterator<It>::value,bool>::type*) 
:  m_sz ( std::distance(ini, fin) ), m_p (alloc(m_sz)) {
    using namespace std;
    try {
        //m_p= alloc(m_sz);
        uninitialized_copy(ini, fin, m_p);
    } catch (...) {
        delete[] m_p; m_p= nullptr;
        throw;
    }
}

#if (CXXOMFORT_CXX_STD >= 2011)
// This assumes none of the involved constructors will throw!
template <typename T>
dynarray<T>::dynarray (std::initializer_list<T> const& L) CXXO_NOEXCEPT // shouldnt_throw
: m_p ( alloc(std::distance(L.begin(),L.end())) ), m_sz( std::distance(L.begin(),L.end()) ) {
    std::uninitialized_copy(L.begin(), L.end(), m_p);
}
#endif

// Move constructor
template <typename T>
dynarray<T>::dynarray (CXXO_RV_REF( dynarray ) p)  CXXO_NOEXCEPT // shouldnt_throw
: m_p(p.m_p), m_sz(p.m_sz) {
    p.m_p= nullptr;
    p.m_sz= 0;
}


// Destructor
template <typename T>
dynarray<T>::~dynarray () { 
    using namespace std;
    typedef typename conditional < std::is_const<T>::value , 
        char const*,
        char*>
    ::type buffertype;
    for (size_t i=0; i < m_sz; ++i) {
        (m_p+i)->~T();
    }
    delete[] reinterpret_cast<buffertype>(m_p); 
    m_p= nullptr;
}

template <typename T>
inline bool operator== (dynarray<T> const& a, dynarray<T> const& b) {
    return ( a.size() == b.size() ) && std::equal(a.begin(), a.end(), b.begin()) ;
}

template <typename T>
inline bool operator!= (dynarray<T> const& a, dynarray<T> const& b) {
    return !(a==b);
}

#if (CXXOMFORT_CXX_STD >= 2011)
#undef INIT_LIST
#else
#endif
#undef _DELETED_

}//~dynarray
}//~extras
}//~cxxomfort

/**
 * @class std::experimental::dynarray
 * @brief Dynamic array template class from C++14/2y (using @ref dynarray )
 */

#endif
