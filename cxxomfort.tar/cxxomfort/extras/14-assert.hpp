#ifndef CXXOMFORT_EXTRAS_14ASSERT_HPP
#define CXXOMFORT_EXTRAS_14ASSERT_HPP
/*
 * Partially implements New Assert Variants proposal (n3500)
 * http://www.open-std.org/JTC1/SC22/WG21/docs/papers/2013/n3500.htm
 */
#include <cxxomfort/config.hpp>
#include <cxxomfort/base/static_assert.hpp>

namespace cxxomfort {
namespace extras {

/* equivalent to assert(expression), except it also prints message (when expression is false) */
#ifdef NDEBUG
#define assert_msg(expr,msg) ( (void)0 )
#else
#define assert_msg(expr,msg) (expr) ? ((void)0) : assert(0==msg) 
#endif

/* equivalent to assert(expression), 
 * except it always evaluates expression, even when NDEBUG is defined 
 */
#ifdef NDEBUG
    #define verify(expr) ((void)(expr))
    #define verify_msg(expr,msg) ((void)(expr))
#else
    #define verify(expr) assert(expr)
    #define verify_msg(expr,msg) assert_msg(expr,msg)
#endif

/* equivalent to assert(expression), 
 * except it always evaluates and checks expression, even when NDEBUG is defined 
 */
#define CXXO_abort_str_(a) #a
#define CXXO_abort_str(a) CXXO_abort_str_(a)
#define CXXO_abort_msg_where() "file " __FILE__ " line " CXXO_abort_str(__LINE__) " "
#define abort_with_message(t,s) (fprintf(stderr,"Assertion failed in " s ": " t "\n"), abort())
#define assure(expr) (expr) ? (void)0 : abort_with_message(#expr, CXXO_abort_msg_where())
#define assure_msg(expr,msg) (expr) ? (void)0 : abort_with_message(msg, CXXO_abort_msg_where())

} //cxxomfort::extras
} //cxxomfort

#endif // CXXOMFORT_EXTRAS_14ASSERT_HPP

