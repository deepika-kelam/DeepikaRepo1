#pragma message CXXO_WARNING("this header is deprecated. New header is <cxxomfort/library/foreach.hpp>")
#include <cxxomfort/library/foreach.hpp>
