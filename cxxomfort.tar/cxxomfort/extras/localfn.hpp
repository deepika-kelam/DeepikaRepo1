#pragma message CXXO_WARNING("this header is deprecated. New header is <cxxomfort/library/localfn.hpp>")
#include <cxxomfort/library/localfn.hpp>
