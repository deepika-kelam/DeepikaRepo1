#ifndef CXXOMFORT_MEMORY_HPP
#define CXXOMFORT_MEMORY_HPP
/**
 * @file cxxomfort/memory.hpp
 * @brief Implementations and additions tied to <memory>.
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 *
 * Interfaces defined in this header:
 *
 * - addressof
 * - alignof (as a compiler-dependent macro)
 * - alignas (in C++03-mode only)
 *
 * Included:
 * - addressof.hpp
 * - unique_ptr.hpp
 */

#include "config.hpp"
#include "base/alignof.hpp"

#if (defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1))
#pragma message CXXO_NOTICE("enabled <memory> support.")
#endif


/* alignas, aligned_storage */
#if ((CXXOMFORT_CXX_STD < 2011) && (CXXO_COMPILER_SUPPORT_alignment_tools==0))

//
// alignas
//

    #ifdef alignas
    #error " cxxomfort -- conflicting #define directive for 'alignas()'!"
    #endif
    #if 0
    #elif (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC)
        #define alignas(N) __attribute__ ((aligned(N)))
    #elif (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_MSC)
        #define alignas(N) __declspec(align(N))
    #endif



//
// aligned_storage
//
#include "impl/11-aligned_storage.hpp"

//
// aligned_union
//

#endif

// pointer_traits, allocator_traits
#include "util/memtraits.hpp"


#if (CXXOMFORT_CXX_STD < 2011)
    #define CXXOMFORT_USING_MEMTOOLS
    #if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
    #pragma message CXXO_NOTICE("memtools support.")
    #endif
#endif // c++11


#if defined(CXXOMFORT_USING_MEMTOOLS)

#include CXXO_INCLUDE_SYS(memory)
#include "base.hpp"

// We define alignas, alignof depending on compiler specifics
#if 0
#elif (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_GCC)
#elif (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_MSC)
#else // unrecognized compiler, we can't go any further
    // take a safe bet
    #define alignof(T) __alignof(T)
    // this bet is very unsafe, but nothing better can be done at this point
    #define alignas(N) typedef *char _cant_implement_alignas_emulation[-1]
    #pragma message CXXO_NOTICE("alignof directives not supported; compilation might fail if using <memory> utilities!")
#endif

#else // using c++11 or emulation mode, we might still need to fix some things
// NOTE: in GCC < 4.8, alignas is not supported - not even in in c++11 mode
// (but alignof is)
#if ((CXXOMFORT_CXX_STD >= 2011) && CXXOMFORT_COMPILER_ID==CXXOMFORT_VALUE_GCC && CXXOMFORT_COMPILER_VERSION < 408)
    #define alignas(N) __attribute__ ((aligned(N))
    #define CXXOMFORT_ALIGNMENT_TOOLS_SUPPORTED
#endif // GCC c++11 fix

#endif // check for USING_memtools (1)

#if defined(CXXOMFORT_USING_MEMTOOLS)
//
// Using the above features, we can implement aligned_storage as per cppreference.com
//
namespace cxxomfort {

#if (0 && !defined(CXXOMFORT_ALIGNMENT_TOOLS_SUPPORTED))
template <size_t S, size_t A = -1> struct aligned_storage {
    typedef union { 
        unsigned char storage[S]; 
        struct struct_;
        double dd[2]; 
        long double ld;
        double d;
        long l;
        int i;
        char c;
        void (*fn_a)();
        int struct_::memobj;
        double (struct_::*memfn)(int);
    } type;
};
#else
    #if defined(__GNUC__) && (CXXOMFORT_COMPILER_VERSION >= 406)
    // in GCC >= 4.6, __attribute__(aligned) can take compile-time constants
    #elif defined(__GNUC__) && (CXXOMFORT_COMPILER_VERSION >= 402)
    // in GCC >= 4.2, __attribute__(aligned) can only take numeric literals
    // in MSC (tested versions), __declspec(aligned) can only take numeric literals

    #elif defined(_MSC_VER)
    #else
    #error ("Unidentified method for aligned_storage.");

    #endif
#endif

//
// uninitialized_copy_n
//
template<class InpIt, class Size, class FwdIt>
FwdIt uninitialized_copy_n (InpIt ini, Size n, FwdIt dest) {
    typedef typename std::iterator_traits<FwdIt>::value_type Value;
    for (; n > 0; ++ini, ++dest, --n) {
        ::new (static_cast<void*>(&*dest)) Value(*ini);
    }
    return dest;
}

} // cxxomfort

//
// addressof
//
#include "impl/11-addressof.hpp"


//
// unique_ptr
//
#include "impl/unique_ptr.hpp"
#include "impl/make_unique.hpp"




// -- set up needed things in std::

#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC && CXXOMFORT_COMPILER_VERSION<404)
namespace std {namespace tr1 {
    using ::cxxomfort::aligned_storage;
}}
#endif


#if (defined(_MSC_VER) && CXXOMFORT_COMPILER_VERSION<160)
namespace std {namespace tr1 {
    //using ::cxxomfort::aligned_storage;
}}
#endif

#else
#include <memory>
namespace cxxomfort {
    //using std::addressof;
    using std::uninitialized_copy_n;
    using std::aligned_storage;
}


#endif // c++03/11


#endif // file
