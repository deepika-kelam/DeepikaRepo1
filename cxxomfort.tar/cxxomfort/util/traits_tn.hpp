#ifndef CXXOMFORT_UTIL_TRAITS_TN_HPP
#define CXXOMFORT_UTIL_TRAITS_TN_HPP

#if (defined(CXXOMFORT_NOTICES) && CXXOMFORT_NOTICES>2)
    #pragma message CXXO_NOTICE("")
#endif

#include <type_traits>
#include "../util/type_traits.hpp"
//
// Triviality traits from C++11
//

#if (CXXOMFORT_CXX_STD < 2011)
    #define CXXO_enable_is_trivially
#endif


#if (defined(CXXO_enable_is_trivially))
namespace std {

    template <typename T>
    struct is_trivially_default_constructible
    : std::integral_constant<bool, __has_trivial_constructor(T)> {};

    template <typename T>
    struct is_trivially_copy_constructible 
    : std::integral_constant<bool, __has_trivial_copy(T)> {};

    template <typename T>
    struct is_trivially_copy_assignable 
    : std::integral_constant<bool, __has_trivial_assign(T)> {};

    template <typename T>
    struct is_trivially_destructible
    : std::integral_constant<bool, __has_trivial_destructor(T)> {};

}
#undef CXXO_enable_is_trivially

#else
/* 
 * clang <= 3.4 and GCC <= 4.9 are missing the following in C++11 mode:
 * 
 * is_trivially_default_constructible
 * is_trivially_copy_constructible
 * is_trivially_copy_assignable
 * 
 * partial source:
 * http://stackoverflow.com/questions/25123458/is-trivially-copyable-is-not-a-member-of-std
 * 
 */
    #if (CXXOMFORT_CXX_STD == 2011 && CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_CLANG && CXXOMFORT_COMPILER_VERSION<=304) \
    || (CXXOMFORT_CXX_EMULATION == 2011 && CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC && CXXOMFORT_COMPILER_VERSION<=409)
namespace std {
    template <typename T>
    struct is_trivially_default_constructible
    : std::integral_constant<bool, __has_trivial_constructor(T)> {};

    template <typename T>
    struct is_trivially_copy_constructible 
    : std::integral_constant<bool, __has_trivial_copy(T)> {};

    template <typename T>
    struct is_trivially_copy_assignable 
    : std::integral_constant<bool, __has_trivial_assign(T)> {};

}
    #endif

#endif

/*
 * is_trivial, is_literal_type
 */
#if (CXXOMFORT_CXX_STD < 2011)

    // for is_trivial
    #if 0
    #elif (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_CLANG)
        #if (CXXOMFORT_CXX_STD < 2011)
        #define CXXO_enable_is_trivial 1
        #define CXXO_has_trivial_intrinsic 1
        #define CXXO_enable_is_literal 1
        #define CXXO_has_literal_intrinsic 1
        #endif
    #elif (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC)
        #if (CXXOMFORT_CXX_EMULATION==0)
            #define CXXO_enable_is_trivial 1
            #define CXXO_enable_is_literal 1
        #endif
        
        #if (CXXOMFORT_COMPILER_VERSION<406)
        #define CXXO_has_trivial_intrinsic 0
        #define CXXO_has_literal_intrinsic 0
        #else
        #define CXXO_has_trivial_intrinsic 1
        #define CXXO_has_literal_intrinsic 1
        #endif
        
    #elif (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_MSC)
        #define CXXO_enable_is_literal 1
        #if (CXXOMFORT_COMPILER_VERSION>=160)
        #define CXXO_enable_is_trivial 0 // already available
        #else
        #define CXXO_enable_is_trivial 1 // but check intrinsic
        #endif
    #endif

namespace std {

    #if (CXXO_enable_is_literal==1)
    #if (CXXO_has_literal_intrinsic_==1)
    template <typename T>
    struct is_literal_type
    : integral_constant<bool, __is_literal_type(T)> {};
    #else
    // a C++03 literal type is a scalar or a reference
    template <typename T>
    struct is_literal_type
    : cxxomfort::traits::integral_constant<bool, cxxomfort::traits::is_scalar<T>::value || cxxomfort::traits::is_reference<T>::value > {};
    
    #endif
    #endif // enable_is_literal

    
    #if (CXXO_enable_is_trivial==1)
    #if (CXXO_has_trivial_intrinsic==1)
    template <typename T>
    struct is_trivial
    : cxxomfort::traits::integral_constant<bool, __is_trivial(T)> {};

    #else
    // a C++03 trivial type is a scalar or a class whose construction and destruction behaves like that of a scalar
    template <typename T>
    struct is_trivial
    : cxxomfort::traits::integral_constant<bool
        , cxxomfort::traits::is_scalar<T>::value || 
        ( cxxomfort::traits::is_class<T>::value && is_trivially_default_constructible<T>::value 
        && is_trivially_copy_constructible<T>::value && is_trivially_destructible<T>::value 
        )
    > {};

    #endif
    #endif // enable_is_trivial

#undef CXXO_enable_is_trivial
#undef CXXO_enable_is_literal

}
#endif // c++11 mode or type_traits emulation

//
// is_nothrow_...
//

#if (CXXOMFORT_CXX_STD < 2011) 
    #define CXXO_enable_is_nothrow
#endif

#if (defined(CXXO_enable_is_nothrow))
namespace std {
    template <typename T>
    struct is_nothrow_default_constructible
    : cxxomfort::traits::integral_constant<bool, __has_nothrow_constructor(T)> {};

    template <typename T>
    struct is_nothrow_copy_constructible
    : cxxomfort::traits::integral_constant<bool, __has_nothrow_copy(T)> {};

    template <typename T>
    struct is_nothrow_copy_assignable 
    : cxxomfort::traits::integral_constant<bool, __has_nothrow_assign(T)> {};

}
#undef CXXO_enable_is_nothrow
#endif // cxx11


//
// is_default_constructible (for c++03)
// we approximate it by using the trivially and nothrow traits
//

#if (CXXOMFORT_CXX_STD < 2011)
#if (!(CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC && CXXOMFORT_COMPILER_VERSION >= 407 && CXXOMFORT_CXX_EMULATION == 2011))
namespace std {
    template <typename T>
    struct is_default_constructible
    : std::integral_constant<bool, is_trivially_default_constructible<T>::value || is_nothrow_default_constructible<T>::value>
    {};

} // std::
#endif
#endif

//
// is_copy_constructible (for c++03)
// is_copy_assignable (for c++03)
//
#if (CXXOMFORT_CXX_STD < 2011)
#if (!(CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC && CXXOMFORT_COMPILER_VERSION >= 407 && CXXOMFORT_CXX_EMULATION == 2011))
namespace std {
    // pending: use is_convertible as an assist
    template <typename T>
    struct is_copy_constructible
    : std::integral_constant<bool, is_trivially_copy_constructible<T>::value || is_nothrow_copy_constructible<T>::value > 
    {};

    // pending: use is_convertible as an assist
    template <typename T>
    struct is_copy_assignable
    : cxxomfort::traits::integral_constant<bool, is_trivially_copy_assignable<T>::value || is_nothrow_copy_assignable<T>::value > 
    {};

} // std::
#endif
#endif


#endif // HEADER GUARD
