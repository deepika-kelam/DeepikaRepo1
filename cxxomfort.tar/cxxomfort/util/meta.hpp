#ifndef CXXOMFORT_UTIL_META_HPP
#define CXXOMFORT_UTIL_META_HPP
/**
 * @brief Implements some of the type_traits additions in C++03.
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 *
 * Interfaces defined in this header:
 *
 * * enable_if, conditional (also for namespace std)
 * * identity
 * * disable_if
 * * selection
 * * meta_and, meta_or
 * 
 */

#include <cxxomfort/config.hpp>
#include <cxxomfort/base/static_assert.hpp>
#include "type_traits.hpp"
#define CXXOMFORT_IMPLEMENTS_n2240 CXXO_LIBRARY()


namespace cxxomfort {

struct none_tag ;

/**
 * @brief Given a type T, define member ::type as T
 */
template <typename T>
struct identity {  typedef T type; };

/**
 * @struct enable_if
 * @brief Given condition Cond, define member ::type as T only if Cond is @c true ; otherwise define nothing.
 */
template <bool Cond, typename T=void> struct enable_if;
template <typename T> struct enable_if<true,T> { typedef T type; }; ///< actually defined only in this case

/**
 * @name disable_if
 * @brief Oppossite of @c enable_if , added here for completeness.
 */
template <bool B, typename T=void> struct disable_if { typedef T type; };
template <typename T> struct enable_if<true,T>;

/**
 * @brief Given condition @e Cond , define member ::type as T1 if Cond is @c false , as T2 otherwise.
 */
template <bool Cond, typename T1, typename T2> struct conditional        { typedef T2 type; };
template <typename T1, typename T2> struct conditional<true,T1,T2>    { typedef T1 type; };

/**
 * @brief Given an index V and a list of types T0, T1, T2, ...; find the type in the Vth position.
 */
template <unsigned V,
    typename T0, typename T1, typename T2= void, typename T3= void, typename T4= void,
    typename T5= void, typename T6= void, typename T7= void, typename T8= void, typename T9= void>
struct selection {};

template <
    typename T0, typename T1, typename T2, typename T3, typename T4,
    typename T5, typename T6, typename T7, typename T8, typename T9
> struct selection<0, T0,T1,T2,T3,T4,T5,T6,T7,T8,T9> {
    typedef T0 type;
};

template <
    typename T0, typename T1, typename T2, typename T3, typename T4,
    typename T5, typename T6, typename T7, typename T8, typename T9
> struct selection<1, T0,T1,T2,T3,T4,T5,T6,T7,T8,T9> {
    typedef T1 type;
};

template <
    typename T0, typename T1, typename T2, typename T3, typename T4,
    typename T5, typename T6, typename T7, typename T8, typename T9
> struct selection<2, T0,T1,T2,T3,T4,T5,T6,T7,T8,T9> {
    typedef T2 type;
};

template <
    typename T0, typename T1, typename T2, typename T3, typename T4,
    typename T5, typename T6, typename T7, typename T8, typename T9
> struct selection<3, T0,T1,T2,T3,T4,T5,T6,T7,T8,T9> {
    typedef T3 type;
};

template <
    typename T0, typename T1, typename T2, typename T3, typename T4,
    typename T5, typename T6, typename T7, typename T8, typename T9
> struct selection<4, T0,T1,T2,T3,T4,T5,T6,T7,T8,T9> {
    typedef T4 type;
};

template <
    typename T0, typename T1, typename T2, typename T3, typename T4,
    typename T5, typename T6, typename T7, typename T8, typename T9
> struct selection<5, T0,T1,T2,T3,T4,T5,T6,T7,T8,T9> {
    typedef T5 type;
};

template <
    typename T0, typename T1, typename T2, typename T3, typename T4,
    typename T5, typename T6, typename T7, typename T8, typename T9
> struct selection<6, T0,T1,T2,T3,T4,T5,T6,T7,T8,T9> {
    typedef T6 type;
};

template <
    typename T0, typename T1, typename T2, typename T3, typename T4,
    typename T5, typename T6, typename T7, typename T8, typename T9
> struct selection<7, T0,T1,T2,T3,T4,T5,T6,T7,T8,T9> {
    typedef T7 type;
};

template <
    typename T0, typename T1, typename T2, typename T3, typename T4,
    typename T5, typename T6, typename T7, typename T8, typename T9
> struct selection<8, T0,T1,T2,T3,T4,T5,T6,T7,T8,T9> {
    typedef T8 type;
};

template <
    typename T0, typename T1, typename T2, typename T3, typename T4,
    typename T5, typename T6, typename T7, typename T8, typename T9
> struct selection<9, T0,T1,T2,T3,T4,T5,T6,T7,T8,T9> {
    typedef T9 type;
};

// this is for failures in iteration
template <
    typename T0, typename T1, typename T2, typename T3, typename T4,
    typename T5, typename T6, typename T7, typename T8, typename T9
> struct selection<10, T0,T1,T2,T3,T4,T5,T6,T7,T8,T9> ;

/*
 * meta_and, meta_or
 * Given a list of boolean traits Bools..., 
 * sets ::value as the AND / OR of their ::values
 */
#if CXXOMFORT_CXX_STD >= 2011 || defined(DOXYGEN_DOC)

template <typename... Bools>
struct meta_and; // make compiler happy

// at least 2 arguments
template <typename B0, typename... Bools>
struct meta_and<B0,Bools...>
: traits::integral_constant<
bool, (B0::value and meta_and<Bools...>::value)
> {};

template <typename B0>
struct meta_and<B0> : traits::integral_constant<bool, B0::value> {};

template <typename... Bools>
struct meta_or; // make compiler happy

// at least 2 arguments
template <typename B0, typename... Bools>
struct meta_or<B0,Bools...>
: traits::integral_constant<
bool, (B0::value or meta_and<Bools...>::value)
> {};

#else
// non-variadic up to 10 args, non-recursive
template <
    typename B0, typename B1, 
    typename B2= traits::true_type, typename B3= traits::true_type,
    typename B4= traits::true_type, typename B5= traits::true_type,
    typename B6= traits::true_type, typename B7= traits::true_type,
    typename B8= traits::true_type, typename B9= traits::true_type
> struct meta_and
: traits::integral_constant< 
bool, (B0::value && B1::value && B2::value && B3::value && B4::value 
    && B5::value && B6::value && B7::value && B8::value && B9::value)
> {};

template <
    typename B0, typename B1, 
    typename B2= traits::false_type, typename B3= traits::false_type,
    typename B4= traits::false_type, typename B5= traits::false_type,
    typename B6= traits::false_type, typename B7= traits::false_type,
    typename B8= traits::false_type, typename B9= traits::false_type
> struct meta_or
: traits::integral_constant< 
bool, (B0::value || B1::value || B2::value || B3::value || B4::value 
    || B5::value || B6::value || B7::value || B8::value || B9::value)
> {};
#endif

//
// conditional_if
// (select type according to a trait
//

#if 0
namespace detail_conditional {

template <template<typename> class Trait, int Idx, int N, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8, typename T9, typename T10>
struct helper {
    typedef typename selection<Idx, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>::type test_T;
    enum { value = 
    (traits::is_same<test_T,none_tag>::value ? -1 : 
    (Trait<test_T>::value ? Idx : helper<Trait, Idx+1, N, T1,T2,T3,T4,T5,T6,T7,T8,T9,T10>::value )
    )
    };
};

template <template<typename> class Trait, int N, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8, typename T9, typename T10>
struct helper<Trait,N,N,T1,T2,T3,T4,T5,T6,T7,T8,T9,T10> {
    static_assert( (N!=0) , "Sequence of types in conditional_if helper did not find a type");
    enum { value = N };
};


}

template <template <typename> class Trait, 
    typename T1, 
    typename T2=T1, typename T3=T1, typename T4=T1, typename T5=T1, 
    typename T6=T1, typename T7=T1, typename T8=T1, typename T9=T1, 
    typename T10=T1
> struct conditional_if {
    private:
    static const int value = detail_conditional::helper<Trait,0,10,T1,T2,T3,T4,T5,T6,T7,T8,T9,T10>::value;
    public:
    typedef typename selection<value, T1,T2,T3,T4,T5,T6,T7,T8,T9,T10>::type type;

};

template <template <typename> class Trait, typename T>
struct conditional_if<Trait, T> 
: conditional<Trait<T>::value, T, none_tag> {};

#endif

}//~cxxomfort

#if CXXOMFORT_CXX_STD < 2011
#if (CXXO_COMPILER_SUPPORT_std_metaprogramming_helpers == 0)
    #define CXXOMFORT_USING_METAPROGRAMMING_HELPERS 1
#endif
#endif

#if defined (CXXOMFORT_USING_METAPROGRAMMING_HELPERS)
    #if defined (CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
    #pragma message CXXO_NOTICE("enabled metaprogramming support.")
    #endif


//
// enable_if and conditional go to namespace std
//
namespace std {
    using ::cxxomfort::enable_if;
    using ::cxxomfort::conditional;
}

// Example usages
// http://stackoverflow.com/questions/7693703/can-i-use-something-like-enable-if-with-an-implicit-conversion-operator?rq=1
//
//

#endif // USING

#endif // file
