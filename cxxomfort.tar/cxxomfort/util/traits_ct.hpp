#ifndef CXXOMFORT_UTIL_TRAITS_COMMONTYPE_HPP
#define CXXOMFORT_UTIL_TRAITS_COMMONTYPE_HPP
//
// common_type, from C++11
//

#if (defined(CXXOMFORT_NOTICES) && CXXOMFORT_NOTICES>2)
    #pragma message CXXO_NOTICE("common_type trait specifics")
#endif

#include "../util/type_traits.hpp"
#include <type_traits>
#include <ciso646>

#if (CXXOMFORT_CXX_STD >= 2011)
    // only do something if the specific compiler lacks std::common_type
#else // c++03
    #define CXXO_IMPLEMENT_COMMON_TYPE 1

    
    #if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_MSC && CXXOMFORT_COMPILER_VERSION==160)
        // MSVC 2010 already implements common_type, albeit broken; nothing we can do
        #undef CXXO_IMPLEMENT_COMMON_TYPE
    #elif (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC)
        // GCC ships common_type in "emulation" mode from 4.4 onwards
        #if (CXXOMFORT_COMPILER_VERSION >= 404 && CXXOMFORT_CXX_EMULATION==2011)
            #undef CXXO_IMPLEMENT_COMMON_TYPE
        #endif
    #else
        // unrecognized compiler
    
    #endif

#endif // CXXOMFORT_CXX_STD


#if defined(CXXO_IMPLEMENT_COMMON_TYPE) // _IMPLEMENT_
/*
 * Unlike other utilities, common_type has to be implemented in namespace std 
 * because clients have to be able to specialize.
 * 
 * The only way around it would be to either hack MSVC 2010's <utility> 
 * or replacing the header whole via a cstd/cxx11/utility transparent header.
 * 
 * A cxxomfort::common_type_2 could be offered as an alternative.
 * 
 */
namespace std {

#if (0 && CXXO_COMPILER_SUPPORT_variadic==1) // VARIADIC

#else

template <
 typename T1, typename T2=void, typename T3=void, typename T4=void, typename T5=void
 , typename T6=void, typename T7=void, typename T8=void, typename T9=void, typename TA=void>
struct common_type
 : public common_type <T1, typename common_type<T2,T3,T4,T5,T6,T7,T8,T9,TA>::type >
 {};

// one arg - not exactly identity
template <typename T>
struct common_type<T> { typedef typename std::decay<T>::type type; };

//
// two args - here is where the real work is done
// if we have __typeof__, we can use that
// if not but we have is_convertible, we can try to use that
// if we don't even have that, we can use a promotion chain
//


// two args - unequal case
#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC || CXXO_COMPILER_SUPPORT_typeof==1)

template <typename T1, typename T2> struct common_type<T1,T2> {
	private:
	template <typename Q> static typename std::add_lvalue_reference<Q>::type dv ();
	public:
	typedef  typename common_type< __typeof__ (true ? dv<T1>() : dv<T2>() ) >::type type;
};
    

#else
// (decltype/__typeof__ not available)
// (we can try and solve some cases via eg.: is_convertible)

template <typename T1, typename T2> struct common_type <T1,T2> {
	private:
	struct common_type_cant_resolve; 
	template <typename Q> static typename std::add_lvalue_reference<Q>::type dv ();
	enum { 
		samey = is_same<T1,T2>::value, 
		convertible_12 = std::tr1::is_convertible<T1,T2>::value ,
		convertible_21 = std::tr1::is_convertible<T2,T1>::value
	};
	static_assert (convertible_12 or convertible_21, "cxxomfort: common_type<...> instantiation can not resolve");
	typedef std::conditional< 
		convertible_12, 
		T2, 
		typename std::enable_if<convertible_21, T1>::type
		> convto_t;
	
	public:
	typedef typename std::decay<typename convto_t::type>::type type;
	
};

// we specialize promotion pairs 
// that define common_type<T1,T2> -> type = T2
#define DEF_COMFORT_COMMONTYPE_PROMOTE(T1,T2) \
template <> struct common_type<T1,T2>: common_type<T2> {}; \
template <> struct common_type<T2,T1>: common_type<T2> {} 

    DEF_COMFORT_COMMONTYPE_PROMOTE(bool,short);
    DEF_COMFORT_COMMONTYPE_PROMOTE(bool,int) ;
    DEF_COMFORT_COMMONTYPE_PROMOTE(bool,long) ;
    DEF_COMFORT_COMMONTYPE_PROMOTE(bool,long long) ;
    DEF_COMFORT_COMMONTYPE_PROMOTE(bool,unsigned short);
    DEF_COMFORT_COMMONTYPE_PROMOTE(bool,unsigned int);
    DEF_COMFORT_COMMONTYPE_PROMOTE(bool,unsigned long);
    DEF_COMFORT_COMMONTYPE_PROMOTE(bool,unsigned long long);

    DEF_COMFORT_COMMONTYPE_PROMOTE(signed char,short);
    DEF_COMFORT_COMMONTYPE_PROMOTE(signed char,int);
    DEF_COMFORT_COMMONTYPE_PROMOTE(signed char,long);
    DEF_COMFORT_COMMONTYPE_PROMOTE(unsigned char,unsigned short);
    DEF_COMFORT_COMMONTYPE_PROMOTE(unsigned char,unsigned int);
    DEF_COMFORT_COMMONTYPE_PROMOTE(unsigned char,unsigned long);

    DEF_COMFORT_COMMONTYPE_PROMOTE(short,int);
    DEF_COMFORT_COMMONTYPE_PROMOTE(short,long);
    DEF_COMFORT_COMMONTYPE_PROMOTE(short,long long);
    DEF_COMFORT_COMMONTYPE_PROMOTE(unsigned short,unsigned int);
    DEF_COMFORT_COMMONTYPE_PROMOTE(unsigned short,unsigned long);
    DEF_COMFORT_COMMONTYPE_PROMOTE(unsigned short,unsigned long long);
    DEF_COMFORT_COMMONTYPE_PROMOTE(unsigned short,int);
    DEF_COMFORT_COMMONTYPE_PROMOTE(unsigned short,long);
    DEF_COMFORT_COMMONTYPE_PROMOTE(unsigned short,long long);

    DEF_COMFORT_COMMONTYPE_PROMOTE(int,long);
    DEF_COMFORT_COMMONTYPE_PROMOTE(int,long long);
    DEF_COMFORT_COMMONTYPE_PROMOTE(unsigned int,unsigned long);
    DEF_COMFORT_COMMONTYPE_PROMOTE(unsigned int,unsigned long long);
    DEF_COMFORT_COMMONTYPE_PROMOTE(unsigned int,int);
    DEF_COMFORT_COMMONTYPE_PROMOTE(unsigned int,long);
    DEF_COMFORT_COMMONTYPE_PROMOTE(unsigned int,long long);

    DEF_COMFORT_COMMONTYPE_PROMOTE(float,double);
    DEF_COMFORT_COMMONTYPE_PROMOTE(float,long double);
    DEF_COMFORT_COMMONTYPE_PROMOTE(double,long double);

    //DEF_COMFORT_COMMONTYPE_PROMOTE(char const*, std::string);
    //DEF_COMFORT_COMMONTYPE_PROMOTE(wchar const*, std::wstring);

#undef DEF_COMFORT_COMMONTYPE_PROMOTE
// end compiler w/o typeof
    
#endif // common_case<T1,T2> resolver


// three args

template <typename T1, typename T2, typename T3>
struct common_type<T1,T2,T3>
 : public common_type< typename common_type<T1,T2>::type, T3 >
 {};


// four args

template <typename T1, typename T2, typename T3, typename T4>
struct common_type<T1,T2,T3,T4>
 : public common_type< typename common_type<T1,T2,T3>::type, T4 >
 {};


// five args

template <typename T1, typename T2, typename T3, typename T4, typename T5>
struct common_type<T1,T2,T3,T4,T5>
 : public common_type< typename common_type<T1,T2,T3,T4>::type, T5 >
 {};

// six args

template <typename T1, typename T2, typename T3, typename T4, typename T5, typename T6>
struct common_type<T1,T2,T3,T4,T5,T6>
 : public common_type< typename common_type<T1,T2,T3,T4,T5>::type, T6 >
 {};

// seven args

template <typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7>
struct common_type<T1,T2,T3,T4,T5,T6,T7>
 : public common_type< typename common_type<T1,T2,T3,T4,T5,T6>::type, T7 >
 {};

// eight args

template <typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8>
struct common_type<T1,T2,T3,T4,T5,T6,T7,T8>
 : public common_type< typename common_type<T1,T2,T3,T4,T5,T6,T7>::type, T8 >
 {};

// nine args

template <typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8, typename T9>
struct common_type<T1,T2,T3,T4,T5,T6,T7,T8,T9>
 : public common_type< typename common_type<T1,T2,T3,T4,T5,T6,T7,T8>::type, T9 >
 {};

#endif // VARIADIC

// two args - equal case
template <typename T>
struct common_type<T,T>
 : common_type<T> 
 {};


}    // namespace std
#endif // _IMPLEMENT_


#endif


