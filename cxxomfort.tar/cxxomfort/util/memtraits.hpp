#ifndef CXXOMFORT_UTIL_MEMTRAITS_HPP
#define CXXOMFORT_UTIL_MEMTRAITS_HPP

/*
 * This file defines the pointer_traits and allocator_traits
 * interfaces in C++03 as a way to provide uniform access to 
 * allocator functionality when using this library to implement 
 * eg.: container functionality.
 * 
 */

#include "../config.hpp"
#if (CXXOMFORT_CXX_STD < 2011)
#include <utility> // forward, move in c++11
#include "../base/move.hpp"

namespace cxxomfort {

/**
 * @ingroup StandardFeatures
 * @brief API to refer to properties of pointer types
 */
template <typename Ptr>
struct pointer_traits {
    typedef Ptr pointer;
    typedef typename Ptr::element_type element_type;
// element_type 	Ptr::element_type if present. Otherwise T if Ptr is a template instantiation Template<T, Args...> 
    typedef typename Ptr::difference_type difference_type;
// difference_type 	Ptr::difference_type if present, otherwise std::ptrdiff_t
    
    template <typename U>
    struct rebind : Ptr::template rebind<U> {}; 
};

template <typename T> struct pointer_traits<T*> {
    typedef T* pointer;
    typedef T  element_type;
    typedef ptrdiff_t difference_type;

    template <typename U>
    struct rebind { typedef typename pointer_traits<U*>::pointer other; };
};


namespace detail {
//workaround needed for C++03 compilers with no construct()
//supporting rvalue references
template<class A>
struct is_std_allocator {  static const bool value = false; };

template<class T> struct is_std_allocator< std::allocator<T> > {  
    static const bool value = true; 
};

}  //detail::

namespace detail {
    // implementation of check if Class::type_name exists

template<typename T>
struct has_membertypedef_pointer {
private:
    typedef char                      yes;
    typedef struct { char array[2]; } no;

    template<typename C> static yes test(typename C::pointer*);
    template<typename C> static no  test(...);
public:
    static const bool value = sizeof(test<T>(0)) == sizeof(yes);
};

template <typename T>
struct has_membertypedef_void_pointer {
private:
    typedef char                      yes;
    typedef struct { char array[2]; } no;

    template<typename C> static yes test(typename C::void_pointer*);
    template<typename C> static no  test(...);
public:
    static const bool value = sizeof(test<T>(0)) == sizeof(yes);
};

template <typename T, bool> struct has_pointer_types_impl {
    enum { value = false };
    public:
    typedef typename T::value_type value_type;
    typedef value_type* pointer;
    typedef typename pointer_traits<pointer>
        ::template rebind<const value_type>::other const_pointer;
    // using elements from std::pointer_traits
};

template <typename T> struct has_pointer_types_impl<T, true> {
    enum { value = true };
    typedef typename T::pointer pointer;
    typedef typename T::const_pointer const_pointer;
};

template <typename T, bool> struct has_voidpointer_types_impl {
    enum { value = false };
    private:
    typedef typename T::value_type value_type;
    typedef typename pointer_traits<T>::pointer pointer;
    public:
    typedef typename pointer_traits<pointer>::template rebind<void>::other::pointer void_pointer;
    // using elements from std::pointer_traits
};

template <typename T> struct has_voidpointer_types_impl<T, true> {
    enum { value = false };
    typedef typename T::void_pointer void_pointer;
    typedef typename T::const_void_pointer const_void_pointer;
};

template <typename T> struct has_pointer_types:
public has_pointer_types_impl<T, has_membertypedef_pointer<T>::value > {};

template <typename T> struct has_voidpointer_types:
public has_voidpointer_types_impl<T, has_membertypedef_void_pointer<T>::value > {};

} //detail::

template <typename Alloc>
struct allocator_traits {
    typedef Alloc                  allocator_type;
    typedef typename Alloc::value_type      value_type;
    //typedef typename Alloc::pointer         pointer;
    typedef typename detail::has_pointer_types<Alloc>::pointer pointer;
// pointer 	Alloc::pointer if present, otherwise value_type*
    typedef typename detail::has_pointer_types<Alloc>::const_pointer const_pointer;
    //typedef typename Alloc::const_pointer   const_pointer;
//const_pointer 	Alloc::const_pointer if present, otherwise std::pointer_traits<pointer>::rebind<const value_type>
    
    //typedef typename Alloc::void_pointer  void_pointer;
    typedef typename pointer_traits<pointer>::template rebind<void>::other void_pointer;
    //typedef typename detail::has_voidpointer_types<Alloc>::void_pointer void_pointer;
//void_pointer 	Alloc::void_pointer if present, otherwise std::pointer_traits<pointer>::rebind<void>
    typedef typename pointer_traits<pointer>::template rebind<void const>::other const_void_pointer;
    //typedef typename Alloc::const_void_pointer   const_void_pointer;
    //typedef typename detail::has_voidpointer_types<Alloc>::const_void_pointer const_void_pointer;
//const_void_pointer 	Alloc::const_void_pointer if present, otherwise std::pointer_traits<pointer>::rebind<const void>
    //typedef typename Alloc::difference_type difference_type;
//difference_type 	Alloc::difference_type if present, otherwise std::pointer_traits<pointer>::difference_type
    typedef typename Alloc::size_type       size_type;
    typedef typename Alloc::difference_type difference_type;
//size_type 	Alloc::size_type if present, otherwise std::make_unsigned<difference_type>::type
//propagate_on_container_copy_assignment 	Alloc::propagate_on_container_copy_assignment if present, otherwise std::false_type
//propagate_on_container_move_assignment 	Alloc::propagate_on_container_move_assignment if present, otherwise std::false_type
//propagate_on_container_swap 	Alloc::propagate_on_container_swap if present, otherwise 

    template <typename T>
    struct rebind_alloc { typedef typename Alloc::template rebind<T>::other type;  };
    
    static pointer allocate (Alloc &a, size_type n) { return a.allocate(n); }
    static pointer allocate (Alloc &a, size_type n, const void* hint) { return a.allocate(n,hint); }
    static void    deallocate (Alloc &a, pointer p, size_type n) { a.deallocate(p,n); }
    template <typename T>
    static void construct (Alloc &a, T* p) { 
        //a.construct(p); 
        ::new (static_cast<void*>(p)) T;
        }
    template <typename T>
    static void construct (Alloc &a, T* p, CXXO_RV_REF(T) m) { 
        //a.construct(p,std::forward<T>(m)); 
        ::new (static_cast<void*>(p)) T (std::move(m));
    }
    template <typename T, typename Arg1>
    static void construct (Alloc& a, T* p, Arg1 x1) { a.construct(p,x1); }
    template <typename T, typename Arg1, typename Arg2>
    static void construct (Alloc& a, T* p, Arg1 x1, Arg2 x2) { a.construct(p,x1,x2); }
    template <typename T>
    static void destroy (Alloc &a, T* p) { a.destroy(p); }
    static size_t max_size (Alloc const& a)  { return a.max_size(); }

};

}

namespace std {
    using ::cxxomfort::pointer_traits;
    using ::cxxomfort::allocator_traits;
/**
 * @class std::pointer_traits
 * @ingroup StandardFeatures
 * @brief Backport of C++11's pointer_traits API (using @c cxxomfort::pointer_traits ).
 */
}

#endif // c++11
#endif

