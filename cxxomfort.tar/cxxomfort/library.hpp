#ifndef CXXOMFORT_LIBRARY_HPP
#define CXXOMFORT_LIBRARY_HPP
/**
 * @file library.hpp
 * @brief Implementations and additions proper to the cxxomfort library.
 * @addtogroup independent-features
 * 
 *
 * Implementations included from here:
 * 
 * * CXXO_FOREACH
 * * i12n
 * * fixed_vector
 * * pair03
 * * type_name
 * * <sequences.hpp>
 * 
 */

#include <cxxomfort/utility.hpp>

// extra algorithm variants (find_last_if, count_while, etc)
#include "library/algorithmfn.hpp"
// for (x:range) emulation
#include "library/foreach.hpp"
// object-like primitive wrapper for fundamentals (int, long, etc)
// #include "library/fundamental.hpp"
// fixed_vector - the oft sought for vector without resize
#include "library/fixed_vector.hpp"
// initialization of containers and sequences
#include "library/i12n.hpp"
// extra iterator helpers (constant_iterator, etc)
#include "library/iteratorfn.hpp"
// local function emulation
#include "library/localfn.hpp"
// functional plus<> like complements for +=, -=, ...
#include "library/operatorit.hpp"
// pair03 - movable pair type for C++03
#include "library/pair03.hpp"
// extra string extensions (join, trim, etc)
#include "library/stringfn.hpp"
// extra tuple extensions (tuple_pop, etc)
#include "library/tuplefn.hpp"
// typename to string helpers - typeid_demangle, type_name
#include "library/type_name.hpp"

/*
 * is_pair
 */
namespace cxxomfort {

}


#endif

/**
 * @page independent-features
 * 
 * The set of utilities and features specific to cxxomfort, themselves not 
 * part or backport of any Standard feature.
 * 
 */
