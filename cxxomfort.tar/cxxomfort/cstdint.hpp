#ifndef CXXOMFORT_CSTDINT_HPP
#define CXXOMFORT_CSTDINT_HPP
/**
 * @file cxxomfort/cstdint.hpp
 * @brief <cstdint> wrapper
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 *
 *
 */

#include <cxxomfort/config.hpp>
#if (defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1))
#pragma message CXXO_NOTICE("enabled <cstdint> support.")
#endif
#include <cxxomfort/base/cstdint.hpp>
#include <cxxomfort/base.hpp>


#endif
