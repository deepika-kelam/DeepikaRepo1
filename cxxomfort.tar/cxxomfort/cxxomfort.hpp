#ifndef CXXOMFORT_HPP
#define CXXOMFORT_HPP
/**
 * @file cxxomfort.hpp
 * @brief Header file for C++11 and onward backport utilities.
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 * @license MIT License (see LICENSE.txt)
 * @mainpage Cxxomfort Tools for C++03.
 *
 * Cxxomfort is a small, header-only library that backports to C++03
 * some of the nifty C++11 goodies. I wrote it to facilitate my working
 * with the evolving C++ standard as I was getting back into the language.
 * It is intended to reduce the amount and stress of code rewrite
 * while at the same time assisting in backwards and forwards portability.
 *
 * Information on features and usage is available at the repository's page:
 *
 * http://ryan.gulix.cl/fossil.cgi/cxxomfort
 *
 * This library is distributed under the terms of the
 * MIT License. Check LICENSE.txt for more information.
 * 
 * See:
 * 
 * * @subpage base-features "Base Features"
 * * @subpage independent-features "Independent Features"
 * * @subpage extra-features "Extras"
 * * @subpage transparent-headers "Transparent Headers"
 * * @ref cxx03-backports
 * * @ref cxx11-backports
 * * @ref cxx14-backports
 * 
 * Some features are matched to the C++ @b headers  
 * they are provided in in Standard C++:
 * 
 * * @subpage algorithm "<algorithm>"
 * * @subpage cstddef "<cstddef>"
 * * @subpage forward_list "<forward_list>"
 * * @subpage functional "<functional>"
 * * @subpage iterator "<iterator>"
 * * @subpage memory "<memory>"
 * * @subpage random "<random>"
 * * @subpage string "<string>"
 * * @subpage utility "<utility>"
 * * @subpage tuple "<tuple>"
 * * @subpage type_traits "<type_traits>"
 * 
 *
 */

//
// Setup
#include "config.hpp"

//
// Main Features
//
// (pending minor reorganization as of v0.49)
#include "base.hpp"
#include "algorithm.hpp" // <algorithm> additions (copy_if, minmax, etc...)
#include "cstdint.hpp" // <cstdint> wrapper (integer types)
#include "functional.hpp" // <functional> additions (transparent functors, etc)
#include "limits.hpp" // compile-time integral limits
#include "memory.hpp" // <memory> additions (pointer_traits, alignof, unique_ptr, etc...)
#include "util/type_traits.hpp" // basic type_traits
#include "impl/regex-esc.hpp" // CXXO_R for raw regex patterns
#include "utility.hpp" // declval, exchange, pair...
#include "string.hpp" // string function helpers (eg.: to_string)
#include "type_traits.hpp" // common_type, decay, is_literal, is_null_pointer, ...
#include "library.hpp" // cxxomfort library features
#include "sequences.hpp" // sequence helpers, seq_<T>()
#include "using.hpp"



/**
 * @page cxx03-backports
 * @brief Features that are backported to C++03.
 */

/**
 * @page cxx11-backports
 * @brief Features that are backported to C++11.
 */

#endif

