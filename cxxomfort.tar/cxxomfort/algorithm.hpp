#ifndef CXXOMFORT_ALGORITHM_HPP
#define CXXOMFORT_ALGORITHM_HPP
/**
 * @file algorithm.hpp
 * @brief Implementations and additions tied to <algorithm>.
 * 
 * Interfaces defined in this file:
 * 
 * * @c [all,any,none]_of
 * * @c copy_if, @c copy_n, @c partition_copy
 * * @c equal (C++14)
 * * @c find_if_not
 * * @c iota
 * * @c is_permutation, @c next_permutation, @c prev_permutation
 * * @c is_sorted
 * * @c minmax, @c minmax_element
 * * @c count_while (STDC++ Forums proposal)
 * 
 * Pending:
 * 
 * * @c shuffle
 *
 * Documentation: @link Algorithms @endlink .
 * 
 */

#include "base.hpp"
#include "util/meta.hpp" // conditional
#include CXXO_INCLUDE_SYS(algorithm)


namespace cxxomfort {
namespace algorithm {

/**
 * @addtogroup algorithm
 * @{
 */

//! copy elements conditionally to @a dest if they fulfill @a f .
//! @return the advanced @a dest iterator.
template <typename InpI, typename OutI, typename Predicate>
inline OutI copy_if (InpI ini, InpI fin, OutI dest, Predicate f) {
    if (ini != fin) {
        for (; ini != fin; ++ini) {
            if (f(*ini)) { *dest++= *ini; }
        } // for
        
    }
    return dest;
}

//! copy a given amount of elements to @a dest .
//! @return the iterated @a dest iterator.
template <typename InpI, typename Integral, typename OutI>
inline OutI copy_n (InpI ini, Integral n, OutI dest) {
    for (; n --> 0; ++ini, ++dest) {
        *dest= *ini;
    }
    return dest;
}

//! Conditionally copy from sequence <var>[ini,fin)</var> to either sequence starting at @p Dtrue or @p Dfalsef .
//! @return the advanced <code>std::pair</code> (@a Dtrue , @a Dfalse ).
template <typename InpI, typename OutI1, typename OutI2, typename Predicate>
std::pair<OutI1,OutI2> partition_copy (InpI ini, InpI const fin, OutI1 Dtrue, OutI2 Dfalse, Predicate f) {
    for (; ini != fin; ++ini) {
        if (f(*ini)) *Dtrue++= *ini; 
        else *Dfalse++= *ini;
    } // end for
    return std::pair<OutI1,OutI2>(Dtrue,Dfalse);
}

//! Copy like @c copy_if with inverted predicate (for symmetry with @c find_if_not ).
template <typename OutI, typename InpI, typename Pred> inline 
OutI copy_if_not (InpI ini, InpI fin, OutI dest, Pred p) {
    for (; ini != fin; ++ini) { 
        if (!p(*ini)) { *dest= *ini; ++dest; }
    }
}

//! Finds like @c find_if but the predicate is reversed.
template<class It, class Pred>
It find_if_not(It ini, It fin, Pred f) {
    for (; ini != fin; ++ini) {
        if (!f(*ini)) {
            return ini;
        }
    }
    return fin; // < all the elements fulfill f
}

//! Fills the sequence <var>[ini,fin)</var> with an incrementing sequence starting from @p i0 .
template <typename FwIt, typename T>
FwIt iota (FwIt ini, FwIt fin, T i0) {
    for(; ini!=fin; ++ini, ++i0) {*ini= i0; }
    return ini;
}

//! Fills @p n elements with an incrementing sequence starting from @p i0 .
template <typename FwIt, typename Integer, typename T>
FwIt iota_n (FwIt ini, Integer n, T i0) {
    while (n-->0) { *ini= i0; ++ini; ++i0; }
    return ini;
}


//! Check if a sequence is sorted according to comparison predicate @p less .
template <typename Iterator, typename Compare>
inline bool is_sorted (Iterator ini, Iterator fin, Compare less) {
    if (ini == fin) return true;
    Iterator prev= ini++;
    for (; ini != fin; ++ini, ++prev) {
        if (!less(*prev,*ini)) return false;
    }
    return true;
}

//! Check if a sequence is sorted according to <code>operator<</code>.
//! @return @c bool .
template <typename Iterator>
inline bool is_sorted (Iterator ini, Iterator fin) {
    std::less<typename std::iterator_traits<Iterator>::value_type> less;
    return is_sorted(ini,fin,less);
}


//
// minmax, minmax_element
//

//! return a @c std::pair (min,max) from two arguments and a comparator @a Less .
template <typename T, typename Comparator>
std::pair<T const&, T const&> minmax (T const& a, T const& b, Comparator Less) {
    return Less(b,a) ? 
    std::make_pair(b, a) : std::make_pair(a, b)
    ;
}

//! @overloads minmax
template <typename T>
std::pair<T const&, T const&> minmax (T const& a, T const& b)  {
    return (b < a) ? 
    std::pair<T const&,T const&>(b, a) : std::pair<T const&,T const&>(a, b)
    ;
}

//! Returns the pair (minimum,maximum) for the given sequence and comparator @p less .
template <typename FIterator, typename Comparator>
std::pair<FIterator,FIterator> 
minmax_element (FIterator ini, FIterator fin, Comparator less) {
    std::pair<FIterator, FIterator> result(ini, fin);
 
    if (ini == fin) return result;
    if (++ini == fin) return result;

    if (less(*ini, *result.ini)) {
        result.second = result.ini;
        result.ini = ini;
    } else {
        result.second = ini;
    }
    while (++ini != fin) {
        FIterator i = ini;
        if (++ini == fin) {
            if (less(*i, *result.ini)) result.ini = i;
            else if (!(less(*i, *result.second))) result.second = i;
            break;
        } else {
            if (less(*ini, *i)) {
                if (less(*ini, *result.ini)) result.ini = ini;
                if (!(less(*i, *result.second))) result.second = i;
            } else {
                if (less(*i, *result.ini)) result.ini = i;
                if (!(less(*ini, *result.second))) result.second = ini;
            }
        }
    }
    return result;

}

template <typename FIterator>
std::pair<FIterator,FIterator> 
minmax_element (FIterator ini, FIterator fin) {
    std::less <typename std::iterator_traits<FIterator>::value_type> less;
    return minmax_element(ini, fin, less);
}


// detail helpers for shuffle
namespace detail_algorithm {

    template <typename URNG, typename E>
    E uniform_in (URNG& u, E m1, E m2) {
        //typedef typename std::result_of<URNG>::type T;
        E output = m1 + (u() % (E)(m2 - m1 + 1));
        return output;
    }

} // detail_algorithm


/*
 * Shuffles a sequence according to a generator call g().
 * Requires support from <random>.
 */
template< class RAIterator, class URNG >
void shuffle( RAIterator ini, RAIterator fin, URNG& g ) {
    typedef typename std::iterator_traits<RAIterator>::difference_type diff_t;
    diff_t n = fin - ini; // guaranteed for RAIterator
    for (diff_t i = n-1; i > 0; --i) {
        using std::swap;
        //swap(ini[i], ini[D(g, param_t(0, i))]);
        swap (ini[i], ini[ detail_algorithm::uniform_in(g, 0, i) ]);
    }

}

// for_each_n, introduced in C++17
template<class II, class Size, class UnaryFunction>
II for_each_n (II first, Size n, UnaryFunction f) {
    for (Size i = 0; i < n; ++first, (void) ++i) {
        f(*first);
    }
    return first;
}

/**
 * @}
 */

} //~namespace algorithm
} //~namespace cxxomfort


#define CXXOMFORT_IMPLEMENTS_n1990 CXXO_BACKPORT()

// These are in their own files
//#include "impl/03-minmax.hpp"
// included in c++11 onwards
#include "impl/11-is_xxx_of.hpp"
#include "impl/11-permutations.hpp"
// c++14 onwards
#include "impl/14-algorithm-equal.hpp"
// pending: #include "impl/modifying.hpp"
// c++17 onwards(?)
#include "impl/17-clamp.hpp"

#if (defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1))
#pragma message CXXO_NOTICE("enabled <algorithm> support.")
#endif


#if (CXXOMFORT_CXX_STD < 2011) && (CXXO_COMPILER_SUPPORT_std_cxx11_algorithms == 0)

namespace std {

    //! using copy_if and others when in C++03.
    using ::cxxomfort::algorithm::copy_if;
    using ::cxxomfort::algorithm::copy_n;
    using ::cxxomfort::algorithm::partition_copy;

    using ::cxxomfort::algorithm::find_if_not;
    using ::cxxomfort::algorithm::iota;

    using ::cxxomfort::algorithm::is_sorted;
    using ::cxxomfort::algorithm::minmax;
    using ::cxxomfort::algorithm::minmax_element;
    using ::cxxomfort::algorithm::shuffle;
    
    using ::cxxomfort::algorithm::for_each_n;
    
}


#endif // using emulation

#endif
