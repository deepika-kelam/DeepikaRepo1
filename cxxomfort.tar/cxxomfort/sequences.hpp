#ifndef CXXOMFORT_SEQUENCES_HPP
#define CXXOMFORT_SEQUENCES_HPP
/**
 * @file cxxomfort/sequences.hpp
 * @brief Improvements for <array>, <valarray> and generic containers in C++03, C++11.
 * 
 * Interfaces defined in this file:
 * 
 * * @c is_std_array
 * * @c is_sequence_container
 * * @c is_indexable_like_array
 * * @c is_iterator
 * * @c make_array
 * * @c seq_ , @c generic_sequence_t
 * 
 * Pending:
 * 
 * * @c array<> in C++03 mode with NO_TR1 defined
 *
 */

#include "config.hpp"
#include <array>
#include <vector>
#include <type_traits>
#include "library/i12n.hpp"
#include "using.hpp"


//
// is_std_array
//

namespace cxxomfort {

/**
 * @brief Type identification trait for <code>std::array<...></code> types.
 */
template <typename T> struct is_std_array 
: std::false_type {};

template <typename T, size_t N> struct is_std_array< std::array<T,N> > 
: std::true_type {};

} // cxxomfort

//
// is_indexable_like_array operator
//
// A type is considered indexable like an array if it exposes a value_type 
// and a []-operator (returning value_type [const] &).
namespace cxxomfort {
namespace detail {

template <typename T> struct bracket_indexable_helper {

    typedef struct { int a; } yes;
    typedef char no;

    private:
    template <typename U, U> struct really_has;

    template <typename C> static yes& Test_op(really_has <typename C::value_type const& (C::*)() const,
                            &C::operator[] >*);

    template <typename> static no& Test_op(...);
    
    public:
    static const bool has_op    = (sizeof(Test_op<T>(0)) == sizeof(yes));

};


} // detail

/**
 * @brief Type identification trait for types that 
 * are indexable via an array-like <code>operator[]</code>.
 */
template <typename T> struct is_indexable_like_array 
: std::conditional< detail::bracket_indexable_helper<T>::has_op, std::true_type, std::false_type>::type
{};

template <typename T, size_t N> struct is_indexable_like_array< T[N] >
: std::true_type 
{};


} //cxxomfort::

// sequence_t and seq_ generator
#include "impl/seq_.hpp"

//
// is_sequence -- for specializations based on ability to provide 
// access to a sequence of objects
//
#include <iterator>
#include <type_traits>

namespace cxxomfort {

//
// is_iterator
//

namespace detail {

// detect iterator_category member
template <typename T> struct has_member_iterator_category {
private:
    typedef char                      yes;
    typedef yes no[2];

    template <typename C> static yes& test_ic(typename C::iterator_category*);
    template <typename C> static no&  test_ic(...);

    public:
    // iterator_category
    static const bool value = sizeof(test_ic<T>(0)) == sizeof(yes);
};

} // detail::

// Given a type @p T , inherit from @c true_type  if @p T  is a type 
// considered an iterator by iterator_traits.
/*
template<typename T, typename = void>
 struct is_iterator : std::false_type {};

template<typename T>
struct is_iterator<
    T, typename std::enable_if<
        detail::has_member_iterator_category< std::iterator_traits<T> >::value 
        and !std::is_same<typename std::iterator_traits<T>::value_type, void>::value 
    >::type> : std::true_type {};
*/


/**
 * @brief Type identification trait for iterator types
 * as defined by the <code><iterator></code> interface.
 */
template<class T>
struct is_iterator {   
    static T makeT();
    typedef void * twoptrs[2];  // sizeof(twoptrs) > sizeof(void *)
    static twoptrs & test(...); // Common case
    template<class R> static typename R::iterator_category * test(R); // Iterator
    template<class R> static void * test(R *); // Pointer

    static const bool value = sizeof(test(makeT())) == sizeof(void *); 
};



/* A type S is considered a sequence if:
 * * the calls std::begin(s) and std::end(s) make sense
 * * the return type of those calls is specialized by iterator_traits
 * * alternatively, S is a native C array
 */

namespace detail {

    template <typename T> struct has_sequence_members {
    private:
        typedef char                      yes;
        typedef yes no[2];

        template <typename C> static yes& test_ci(typename C::const_iterator*);
        template <typename C> static no&  test_ci(...);
        template <typename C> static yes& test_vt(typename C::value_type*);
        template <typename C> static no&  test_vt(...);

        public:
        // const_iterator
        static const bool value_ci = sizeof(test_ci<T>(0)) == sizeof(yes);
        // value_type
        static const bool value_vt = sizeof(test_vt<T>(0)) == sizeof(yes);
        typedef T type;

        private:
        template <typename U, U> struct really_has;

        template <typename C> static yes& Test_begin(really_has <typename C::const_iterator (C::*)() const,
                                            &C::begin>*);

        template <typename C> static yes& Test_begin(really_has <typename C::iterator (C::*)() const,
                                            &C::begin>*);

        template <typename C> static yes& Test_end(really_has <typename C::const_iterator (C::*)() const,
                                            &C::end>*);

        template <typename C> static yes& Test_end(really_has <typename C::iterator (C::*)() const,
                                            &C::end>*);

        template <typename> static no& Test_begin(...);
        template <typename> static no& Test_end(...);
        
        public:
        static bool const value_begin_end = (
            sizeof(Test_begin<T>(0)) == sizeof(yes) )
            && ( sizeof(Test_end<T>(0)) == sizeof(yes)
            );

    };

template <typename T, bool=false>
struct is_sequence_impl: traits::false_type {};

template <typename T> struct is_sequence_impl<T,true> 
: traits::integral_constant<bool, is_iterator<typename T::const_iterator>::value > {};

} // detail::

// at present, a type S is a sequence if:
// 1.- has a const_iterator and value_type member types
// 1b.- has begin, end member functions returning type iterator or const_iterator (other overloads are ignored)
// 2.- or is a C array.

/**
 * @brief Type identification trait for sequence-like types:
 * * have a @c const_iterator member type.
 * * have a @c begin  and @c end  member function.
 */
template <typename S> struct is_sequence 
: detail::is_sequence_impl<S, 
    detail::has_sequence_members<S>::value_ci 
    && detail::has_sequence_members<S>::value_vt
    && detail::has_sequence_members<S>::value_begin_end 
> {};

// arrays are sequences
template <typename T, size_t N>
struct is_sequence< T[N] > : traits::true_type {};

// starting C++11, valarrays are sequences

#if (CXXOMFORT_CXX_STD >= 2011)
template <typename T>
struct is_sequence< std::valarray<T> >: std::true_type {};
#endif

} // cxxomfort

// make_array
#include "impl/n4031_make_array.hpp"
// fixed_vector
#include "library/fixed_vector.hpp"


#endif
