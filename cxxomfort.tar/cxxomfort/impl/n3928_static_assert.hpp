#ifndef CXXOMFORT_IMPL_n3928_HPP
#define CXXOMFORT_IMPL_n3928_HPP

#include <../base/static_assert.hpp>

// partial implementation of n3928: 
// static_assert without message
#define CXXOMFORT_IMPLEMENTS_n3928 1
#define static_assert0(test) static_assert(test,#test)


#endif
