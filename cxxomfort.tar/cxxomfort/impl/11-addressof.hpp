#ifndef CXXOMFORT_IMPL_ADDRESSOF_HPP
#define CXXOMFORT_IMPL_ADDRESSOF_HPP
/**
 * @file addressof.hpp
 * @brief Implements std::addressof in C++03.
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 *
 */

#include "../config.hpp"

#if (CXXOMFORT_CXX_STD < 2011 && CXXOMFORT_CXX_EMULATION==0)
    #define CXXOMFORT_USING_addressof
#endif // c++11

namespace cxxomfort {

template <typename T> inline
T* addressof (T& arg) {
    return reinterpret_cast<T*>(&reinterpret_cast<char&> (arg) );
}

//! @overloads addressof
template <typename T> inline
T const* addressof (T const& arg) {
    return reinterpret_cast<T const*>(&reinterpret_cast<char const&> (arg) );
}

} // cxxomfort


#if defined(CXXOMFORT_USING_addressof)

namespace std {
    using ::cxxomfort::addressof;
}

#else
    // nothing to do
#endif

#endif // file
