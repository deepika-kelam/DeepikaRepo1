#ifndef CXXOMFORT_IMPL_n3668_HPP
#define CXXOMFORT_IMPL_n3668_HPP

#include "../config.hpp"
#include "../base.hpp" // move emulation
#include <utility>

/*
 * N3608, N3668: exchange
 * 
 * @brief assign new value and return old
 * @see N3608, N3668
 */


#if (CXXOMFORT_CXX_STD < 2014)
#define CXXOMFORT_IMPLEMENTS_n3668 1

namespace cxxomfort {
/**
 * @brief Replaces a variable's value, returns the old value.
 * @sa N3668
 * @ingroup utility
 * @ref cxx03-backports
 * @ref cxx11-backports
 */
template <typename T, typename U>
T exchange (T& obj, CXXO_RV_REF(U) nval) {
    T oval = std::move(obj);
    obj= std::forward<U>(nval);
    return oval;
}

/**
 * @brief Replaces a variable's value, returns the old value.
 * @sa N3668
 * @ingroup utility
 * @ref cxx03-backports
 * @ref cxx11-backports
 */
template <typename T>
T exchange (T& obj, CXXO_RV_REF(T) nval) {
    T oval = std::move(obj);
    obj= std::forward<T>(nval);
    return oval;
}

} //cxxomfort::

namespace std {
    //! @ingroup utility
    using ::cxxomfort::exchange;
} // std::

#endif


#endif
