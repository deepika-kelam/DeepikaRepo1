#ifndef CXXOMFORT_UNIQUE_PTR_HPP
#define CXXOMFORT_UNIQUE_PTR_HPP
/**
 * @file cxxomfort/unique_ptr.hpp
 * @brief Implements @c unique_ptr as a comfort utility for C++03.
 * @version 2012-04-04
 *
 * This file implements the @c unique_ptr smart pointer system
 * in a similar, but not fully equivalent manner,
 * to the @c unique_ptr feature of C++11,
 * thus reducing code rewrite when back/forthporting programs.
 *
 * @c unique_ptr is provided by the C++11 Standard Library.
 *
 * This implementation is based off Howard Hinnant's 2009 implementation,
 * but Boost dependencies are replaced by C++03-TR1 dependencies where
 * possible.
 *
 * Interfaces defined in this header:
 *
 * * @c unique_ptr<> (also for namespace std)
 * * swap (for unique_ptr)
 * * hash<> specialization (for unique_ptr)
 * * make_unique (from "N3656 make_unique")
 * 
 */

#include "../config.hpp"

#if ((CXXOMFORT_CXX_STD < 2011) && (CXXO_COMPILER_SUPPORT_unique_ptr==0))
    #define CXXOMFORT_USING_unique_ptr
#endif

#if (defined (CXXOMFORT_USING_unique_ptr))
#include "../base.hpp" // nullptr, static_assert, move, forward
#include "../util/meta.hpp"
#include "../util/type_traits.hpp"
#include CXXO_INCLUDE_SYS(cstddef) // this brings eg.: shared_ptr
#include CXXO_INCLUDE_SYS(memory) // this brings eg.: shared_ptr
#if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
    #pragma message CXXO_NOTICE("enabled unique_ptr emulation")
#endif

/*
 * Dependencies from type_traits:
 * is_reference
 * add_reference
 * remove_reference
 * is_const
 * enable_if (provided by meta.hpp)
 * is_empty
 */


namespace cxxomfort {
namespace memory {

//
// implementation details
//
namespace detail_unique_ptr {


typedef char one;
struct two {one _[2];};

// An is_convertible<From, To> that considers From an rvalue (consistent with C++0X).
//   This is a simplified version neglecting the types function, array, void and abstract types
//   I had to make a special case out of is_convertible<T,T> to make move-only
//   types happy.

namespace is_conv_imp {
    template <class T> one test1(const T&);
    template <class T> two test1(...);
    template <class T> one test2(T);
    template <class T> two test2(...);
    template <class T> T source();
}

template <class T1, class T2>
struct is_convertible {
    static const bool value = sizeof(is_conv_imp::test1<T2>(is_conv_imp::source<T1>())) == 1;
};

template <class T>
struct is_convertible<T, T> {
    static const bool value = sizeof(is_conv_imp::test2<T>(is_conv_imp::source<T>())) == 1;
};

//
// rv wrapper class
//
template <class T>
class rv {
    T& r_;
public:
    explicit rv(T& r) : r_(r) {}
    T* operator->() {return &r_;}
    T& operator*() {return r_;}
};

}  //~detail_unique_ptr

using ::cxxomfort::traits::is_reference;
using ::cxxomfort::traits::add_reference;
using ::cxxomfort::traits::remove_reference;

/*
 * These functions conflict with move/forward
 *

template <class T> inline
typename ::cxxomfort::enable_if
<
    !detail_unique_ptr::is_convertible<T, detail_unique_ptr::rv<T> >::value,
    T&
>::type
move(T& t) { return t; }

template <class T> inline
typename ::cxxomfort::enable_if
<
    !detail_unique_ptr::is_convertible<T, detail_unique_ptr::rv<T> >::value,
    const T&
>::type
move(const T& t) { return t; }

template <class T> inline
typename ::cxxomfort::enable_if
<
    detail_unique_ptr::is_convertible<T, detail_unique_ptr::rv<T> >::value,
    T
>::type
move(T& t) {
    return T(detail_unique_ptr::rv<T>(t));
}

template <class T>
inline
typename cxxomfort::enable_if
<
    is_reference<T>::value,
    T
>::type
forward(typename identity<T>::type t) {
    return t;
}

template <class T> inline
typename cxxomfort::enable_if
<
    !is_reference<T>::value,
    T
>::type
forward(typename identity<T>::type& t) {
    return move(t);
}

template <class T> inline
typename cxxomfort::enable_if
<
    !is_reference<T>::value,
    T
>::type
forward(const typename identity<T>::type& t) {
    return move(const_cast<T&>(t));
}
*/

namespace detail_unique_ptr {

using ::cxxomfort::traits::is_empty;
using ::cxxomfort::traits::is_reference;
using ::cxxomfort::traits::add_reference;
using ::cxxomfort::traits::remove_reference;


// A move-aware but stripped-down compressed_pair which only optimizes storage for T2
template <class T1, class T2, bool = is_empty<T2>::value>
class unique_ptr_storage {
    private:
    T1 t1_;
    T2 t2_;

    typedef typename add_reference<T2>::type T2_reference;
    typedef typename add_reference<const T2>::type T2_const_reference;

    unique_ptr_storage(const unique_ptr_storage&);
    unique_ptr_storage& operator=(const unique_ptr_storage&);
public:
    operator rv<unique_ptr_storage>() {return rv<unique_ptr_storage>(*this);}

    unique_ptr_storage() : t1_(), t2_() {}

    explicit unique_ptr_storage(T1 t1)
        : t1_(move(t1)), t2_() {}

    unique_ptr_storage(T1 t1, T2 t2)
        : t1_(move(t1)), t2_(forward<T2>(t2)) {}

          T1& first()       {return t1_;}
    const T1& first() const {return t1_;}

          T2_reference second()       {return t2_;}
    T2_const_reference second() const {return t2_;}
};

template <class T1, class T2>
class unique_ptr_storage<T1, T2, true>
: private T2 {
    T1 t1_;
    typedef T2 t2_;

    unique_ptr_storage(const unique_ptr_storage&);
    unique_ptr_storage& operator=(const unique_ptr_storage&);
public:
    operator rv<unique_ptr_storage>() {return rv<unique_ptr_storage>(*this);}

    unique_ptr_storage() : t1_() {}

    explicit unique_ptr_storage(T1 t1)
        : t1_(move(t1)) {}

    unique_ptr_storage(T1 t1, T2 t2)
        : t2_(move(t2)), t1_(move(t1)) {}

          T1& first()       {return t1_;}
    const T1& first() const {return t1_;}

          T2& second()       {return *this;}
    const T2& second() const {return *this;}
};

template <class T1, class T2, bool b> inline
void
swap(unique_ptr_storage<T1, T2, b>& x, unique_ptr_storage<T1, T2, b>& y) {
    using std::swap;
    swap(x.first(), y.first());
    swap(x.second(), y.second());
}

}  // detail_unique_ptr

template <class T>
struct default_delete {

    default_delete() {}
    virtual ~default_delete () {};

    template <class U>
    default_delete ( const default_delete<U>&
    , typename std::enable_if<detail_unique_ptr::is_convertible<U*, T*>::value, void>::type* = 0 )  {
    }

    void operator() (T* ptr) const     {
        static_assert (sizeof(T) > 0, "T must be a complete type");
        delete ptr;
    }
};

template <class T>
struct default_delete<T[]> {
    void operator() (T* ptr) const {
        static_assert (sizeof(T) > 0, "T must be a complete type");
        delete [] ptr;
    }

private:

    template <class U> void operator()(U*) const;
};

namespace detail_unique_ptr {

namespace pointer_type_imp {

struct one { char x[1]; };
struct two { char x[2]; };
template <class U> static two test(...);
template <class U> static one test(typename U::pointer* = 0);

}  //~namespace pointer_type_imp

template <class T>
struct has_pointer_type {
    static const bool value = sizeof(pointer_type_imp::test<T>(0)) == 1;
};

namespace pointer_type_imp {

template <class T, class D, bool = has_pointer_type<D>::value>
struct pointer_type {
    typedef typename D::pointer type;
};

template <class T, class D>
struct pointer_type<T, D, false> {
    typedef T* type;
};

}  //~namespace pointer_type_imp

template <class T, class D>
struct pointer_type {
    typedef typename pointer_type_imp::pointer_type<T,
    typename std::remove_reference<D>::type>::type type;
};

}  //~namespace detail_unique_ptr


//
// unique_ptr
//
/**
 * @brief unique_ptr: a scoped, movable smart pointer.
 * Emulation of the unique_ptr implementation in C++11 for C++03 compilers.
 * Original backport by Howard Hinnant.
 */
template <typename T, typename D = default_delete<T> >
class unique_ptr {
public:
    typedef T element_type;
    typedef D deleter_type;
    typedef typename detail_unique_ptr::pointer_type<element_type, deleter_type>::type pointer;

private:
    CXXO_NONCOPYABLE_MOVABLE(unique_ptr);
private:
    detail_unique_ptr::unique_ptr_storage<pointer, deleter_type> ptr_;

    typedef typename cxxomfort::traits::add_reference<deleter_type>::type deleter_reference;
    typedef typename cxxomfort::traits::add_reference<const deleter_type>::type deleter_const_reference;

    struct nat {int for_bool_;};

    //unique_ptr(unique_ptr&);
    //unique_ptr& operator=(unique_ptr&);

public:
    //! Converts @c unique_ptr to its rvalue-wrapper (for eg.: @e move ).
    operator detail_unique_ptr::rv<unique_ptr>() {
        return detail_unique_ptr::rv<unique_ptr>(*this);
    }

    //! Creates from a rvalue-wrapper (from eg.: @e move ).
    //unique_ptr(detail_unique_ptr::rv<unique_ptr> r)
    unique_ptr( CXXO_RV_REF(unique_ptr) r)
    : ptr_(r.release(), std::forward<deleter_type>(r.get_deleter())) {
    }
    //unique_ptr& operator=(detail_unique_ptr::rv<unique_ptr> r) {
    unique_ptr& operator=( CXXO_RV_REF(unique_ptr) r) {
        reset(r.release());
        ptr_.second() = std::move(r.get_deleter());
        return *this;
    }

    //! Default constructor.
    unique_ptr() : ptr_(nullptr) {
        static_assert (!cxxomfort::traits::is_reference<deleter_type>::value, "Trying to use the deleter of a reference type.");
        static_assert (!cxxomfort::traits::is_pointer<deleter_type>::value, "Trying to use the deleter of a pointer type.");
    }

    //! Creates a @c unique_ptr wrapping the allocated pointer @a p .
    explicit unique_ptr(pointer p) : ptr_(p) {
        static_assert (!cxxomfort::traits::is_reference<deleter_type>::value, "Trying to use the deleter of a reference type.");
        static_assert (!cxxomfort::traits::is_pointer<deleter_type>::value, "Trying to use the deleter of a pointer type.");
    }

    //! Creates a @c unique_ptr given a pointer and a deleter, which is stored unreferenced.
    unique_ptr(pointer p, typename std::conditional<cxxomfort::traits::is_reference<D>::value
        , volatile typename cxxomfort::traits::remove_reference<D>::type&, D
    >::type d)
    : ptr_(std::move(p), std::forward<D>(const_cast<typename cxxomfort::traits::add_reference<D>::type>(d))) {}

    //! Creates a @c unique_ptr from a convertible pointer and deleter
    template <class U, class E>
    unique_ptr(unique_ptr<U, E> u, typename std::enable_if<
        !cxxomfort::traits::is_array<U>::value
        && detail_unique_ptr::is_convertible<typename unique_ptr<U>::pointer, pointer>::value
        && detail_unique_ptr::is_convertible<E, deleter_type>::value
        && ( !cxxomfort::traits::is_reference<deleter_type>::value || cxxomfort::traits::is_same<deleter_type, E>::value )
        , void
    >::type* = 0)
    : ptr_(u.release(), std::forward<D>(std::forward<E>(u.get_deleter()))) {
    }

    // Destructor
    ~unique_ptr() {
        reset();
    }

    //! reset a @c unique_ptr by assigning null pointer literal
    unique_ptr& operator=(std::nullptr_t) {
        reset();
        return *this;
    }

    //! Assignment (moves resource to this object).
    template <class U, class E>
    unique_ptr& operator=(unique_ptr<U, E> u) {
        reset(u.release());
        ptr_.second() = std::move(u.get_deleter());
        return *this;
    }

    //! Provide access to member.
    typename cxxomfort::traits::add_reference<T>::type operator*() const {return *get();}
    //! Provides access to member.
    pointer operator->() const {return get();}
    //! Provides access to member.
    pointer get() const {return ptr_.first();}
    //! Provides access to deleter.
    deleter_reference       get_deleter()       {return ptr_.second();}
    deleter_const_reference get_deleter() const {return ptr_.second();}
    // (safe-bool conversion)
    operator int nat::*() const {return get() ? &nat::for_bool_ : 0;}

    //! Resets / reassigns the @c unique_ptr to another allocated pointer.
    void reset (pointer p = pointer()) {
        pointer t = get();
        if (t != pointer())
            get_deleter()(t);
        ptr_.first() = p;
    }

    //! Returns the owned pointer and releases its ownership.
    pointer release() {
        pointer tmp = get();
        ptr_.first() = pointer();
        return tmp;
    }

    //! Swap
    void swap(unique_ptr& u) {
        detail_unique_ptr::swap(ptr_, u.ptr_);
    }

};

template <class T, class D>
class unique_ptr<T[], D> {
public:
    typedef T element_type;
    typedef D deleter_type;
    typedef typename detail_unique_ptr::pointer_type<element_type, deleter_type>::type pointer;

private:
    detail_unique_ptr::unique_ptr_storage<pointer, deleter_type> ptr_;

    typedef typename cxxomfort::traits::add_reference<deleter_type>::type deleter_reference;
    typedef typename cxxomfort::traits::add_reference<const deleter_type>::type deleter_const_reference;

    struct nat {int for_bool_;};

    unique_ptr(unique_ptr&);
    unique_ptr& operator=(unique_ptr&);

public:
    operator detail_unique_ptr::rv<unique_ptr>() {
        return detail_unique_ptr::rv<unique_ptr>(*this);
    }
    unique_ptr( CXXO_RV_REF(unique_ptr) r) : ptr_(r->release(), std::forward<deleter_type>(r->get_deleter())) {
    }
    unique_ptr& operator=(detail_unique_ptr::rv<unique_ptr> r) {
        reset(r->release());
        ptr_.second() = std::move(r->get_deleter());
        return *this;
    }

    unique_ptr() {
        static_assert (!cxxomfort::traits::is_reference<deleter_type>::value, "Trying to use the deleter of a reference type.");
        static_assert (!cxxomfort::traits::is_pointer<deleter_type>::value, "Trying to use the deleter of a pointer type.");
    }

    explicit unique_ptr(pointer p) : ptr_(p) {
        static_assert (!cxxomfort::traits::is_reference<deleter_type>::value, "Trying to use the deleter of a reference type.");
        static_assert (!cxxomfort::traits::is_pointer<deleter_type>::value, "Trying to use the deleter of a pointer type.");
    }

    unique_ptr(pointer p, typename std::conditional<cxxomfort::traits::is_reference<D>::value,
                          volatile typename cxxomfort::traits::remove_reference<D>::type&, D>::type d)
        : ptr_(move(p), std::forward<D>(const_cast<typename cxxomfort::traits::add_reference<D>::type>(d))) {}

    ~unique_ptr() {
        reset();
    }

    pointer get() const {
        return ptr_.first();
    }
    element_type& operator[] (size_t i) const {
        return get()[i];
    }
    deleter_reference       get_deleter()       {return ptr_.second();}
    deleter_const_reference get_deleter() const {return ptr_.second();}
    operator int nat::*() const {return get() ? &nat::for_bool_ : 0;}

    void reset(pointer p = pointer()) {
        pointer t = get();
        if (t != pointer())
            get_deleter()(t);
        ptr_.first() = p;
    }

    pointer release() {
        pointer tmp = get();
        ptr_.first() = pointer();
        return tmp;
    }

    void swap(unique_ptr& u) {
        detail_unique_ptr::swap(ptr_, u.ptr_);
    }

private:
    template <class U>
    explicit unique_ptr(U,
        typename std::enable_if
        <detail_unique_ptr::is_convertible<U, pointer>::value
        , void
        >::type* = 0);

    template <class U>
    unique_ptr(U, typename std::conditional<cxxomfort::traits::is_reference<D>::value,
                volatile typename cxxomfort::traits::remove_reference<D>::type&, D>::type,
                typename std::enable_if< detail_unique_ptr::is_convertible<U, pointer>::value, void>::type* = 0);
};

template<class T, class D>
inline void swap (unique_ptr<T, D>& x, unique_ptr<T, D>& y) {
    x.swap(y);
}

template<class T1, class D1, class T2, class D2>
inline bool operator==(const unique_ptr<T1, D1>& x, const unique_ptr<T2, D2>& y) {
    return x.get() == y.get();
}

template<class T1, class D1, class T2, class D2>
inline bool operator!=(const unique_ptr<T1, D1>& x, const unique_ptr<T2, D2>& y) {
    return !(x == y);
}

template<class T1, class D1, class T2, class D2>
inline bool operator<(const unique_ptr<T1, D1>& x, const unique_ptr<T2, D2>& y) {
    return x.get() < y.get();
}

template<class T1, class D1, class T2, class D2>
inline bool operator<=(const unique_ptr<T1, D1>& x, const unique_ptr<T2, D2>& y) {
    return !(y < x);
}

template<class T1, class D1, class T2, class D2>
inline bool operator>(const unique_ptr<T1, D1>& x, const unique_ptr<T2, D2>& y) {
    return y < x;
}

template<class T1, class D1, class T2, class D2>
inline bool operator>=(const unique_ptr<T1, D1>& x, const unique_ptr<T2, D2>& y) {
    return !(x < y);
}

} //~namespace memory
} //~namespace cxxomfort

namespace std {
    using ::cxxomfort::memory::unique_ptr;
}


#if (!defined(CXXOMFORT_NO_TR1) && !defined(NO_TR1))
//
// specialize std::tr1::hash for unique_ptr<>
// (this is allowed)
// define either NO_TR1 or CXXOMFORT_NO_TR1 to disable 
// using this TR1 extension in C++03
//
#include <functional> // std::hash, from Tr1
namespace std { namespace tr1 {
    template <typename T>
    struct hash< unique_ptr<T> > : private hash<T*> {
        private:
        typedef hash<T*> base_type;
        public:
        size_t operator() (unique_ptr<T> const& t) const {
            return static_cast<base_type>(*this).operator()(t.get());
        }
    };
} /* tr1 */ }
#endif

#else
    // nothing to do, we're in C++11
#endif // impl.

#endif  // guard
