#ifndef CXXOMFORT_IMPL_CLAMP_HPP
#define CXXOMFORT_IMPL_CLAMP_HPP
/**
 * @file impl/17-clamp.hpp
 * @brief Header file providing implementation of C++17's "clamp" algorithm.
 * @sa http://en.cppreference.com/w/cpp/algorithm/clamp
 * 
 */

#if (CXXOMFORT_CXX_STD < 2017)

namespace cxxomfort {
namespace algorithm {

/**
 * @brief Clamps a value.
 * @ingroup algorithm
 * @ref cxx03-backports
 * @ref cxx11-backports
 * @ref cxx14-backports
 */
template<class T, class Compare>
CXXO_CONSTEXPR
T const& clamp ( T const& val, T const& lo, T const& hi, Compare comp) {
    return assert( !comp(hi, lo) ),
        comp(val, lo) ? lo : comp(hi, val) ? hi : val;
}

//! @overloads clamp
template<class T>
CXXO_CONSTEXPR
T const& clamp ( T const& val, T const& lo, T const& hi) {
    return clamp (val, lo, hi, std::less<T>() );
}

} // algorithm
} // cxxomfort

namespace std {
    using ::cxxomfort::algorithm::clamp;
}


#endif // c++17

#endif
