#ifndef CXXOMFORT_IMPL_PSEUDOVARIADIC_HPP
#define CXXOMFORT_IMPL_PSEUDOVARIADIC_HPP

#if (CXXOMFORT_CXX_STD >= 2011)
#define CXXO_PSEUDOVARIADIC_MEMBER(pre,mfun,post) \
    template <typename... Args>              \
    pre mfun (Args&&...) post ;              \

#else
#define CXXO_PSEUDOVARIADIC_MEMBER(pre,mfun,post) \
    pre   mfun () post;                 \
    template <typename A1>              \
    pre   mfun (A1) post;               \
    template <typename A1, typename A2>      \
    pre   mfun (A1,A2) post;                 \
    template <typename A1, typename A2, typename A3>  \
    pre   mfun (A1,A2,A3) post;              \
    template <typename A1, typename A2, typename A3, typename A4>  \
    pre   mfun (A1,A2,A3,A4) post;              \
    template <typename A1, typename A2, typename A3, typename A4, typename A5>  \
    pre   mfun (A1,A2,A3,A4,A5) post;              \
    
#endif


#endif
