#ifndef CXXOMFORT_IMPL_TUPLEGETTYPE_HPP
#define CXXOMFORT_IMPL_TUPLEGETTYPE_HPP
/*
 * Support for getting elements of a tuple by type
 * (C++14 proposal n3584 "Wording for Addressing Tuples by Type")
 * based off of n3404 and n3584
 * http://www.open-std.org/JTC1/SC22/WG21/docs/papers/2013/n3584.html
 * 
 * Interfaces defined in this header:
 * 
 * * std::get <T> (std::tuple<...>)
 * 
 */

#include <cxxomfort/base.hpp>
#define CXXOMFORT_IMPLEMENTS_n3584 CXXO_EMULATION()
#define CXXOMFORT_IMPLEMENTS_n3670 CXXO_EMULATION()

#include <type_traits>
#include <tuple>

#if (defined(CXXOMFORT_NOTICES))
    #pragma message CXXO_NOTICE("enabled tuple get<type> implementation")
#endif


//#define CXXO_TI_STRI0(x) #x
//#define CXXO_TI_STRI(x) CXXO_TI_STRI0(x)

namespace cxxomfort {
namespace tuple {

namespace detail {

/*
 * Check if an element of type T is already in Tuple, 
 * if so, returns its index
 */
template <typename C, int N, int M, typename Tuple>
struct tuple_element2index_helper {
    enum { rec = (0 <= N && N < M) };
    typedef typename std::enable_if<rec, bool>::type still_has_arguments_t;
    enum { value = 
    (std::is_same<C, typename std::tuple_element<N,Tuple>::type>::value
    ? N : tuple_element2index_helper<C,N+1,M,Tuple>::value
    ) 
    };
};


template <typename C, int N, typename Tuple>
struct tuple_element2index_helper<C,N,N,Tuple> {
    enum { value = -1 };
};

// this makes recursion stop, as the "value" needed to keep computing is not found.
template <typename C, int N, typename Tuple>
struct tuple_element2index_helper<C,-1,N,Tuple> {
};

// this *also* makes recursion stop, as the "value" needed to keep computing is not found.
template <typename C, int N, typename Tuple>
struct tuple_element2index_helper<C,-2,N,Tuple> {
};

template <typename T1,typename T2>
struct tuple_element2index_helper_pair {
    enum { value= (0==std::is_same<T1,T2>::value) };
    static_assert (value, "Tuple get<type> interface for pair requires pair of distinct types");
};

/*
 * Count the number of times type C appears in Tuple
 */
template <typename C, int N, int M, typename Tuple>
struct tuple_count_type_helper {
    enum { value =
    std::is_same< C, typename std::tuple_element<N,Tuple>::type>::value 
    + tuple_count_type_helper<C,N+1,M,Tuple>::value
    };
};

template <typename C, int N, typename Tuple>
struct tuple_count_type_helper<C,N,N,Tuple> {
    enum { value = 0 };
};

} // namespace detail

template <typename C, typename Tuple>
struct tuple_count_type {
    enum { value = detail::tuple_count_type_helper<C,0,std::tuple_size<Tuple>::value,Tuple>::value };
};

/*
 * Given a type C and tuple type Tuple
 * set ::value to the index of the type C in Tuple.
 * If C does not appear in Tuple or appears more than once, fail with compilation error.
 */
template <typename C, typename Tuple>
struct tuple_index {
    typedef typename std::remove_reference<Tuple>::type T;
    static const size_t va= tuple_count_type<C,T>::value;
    static_assert ((va < 2), "Type (C in template) is repeated in tuple.");
    static_assert ((va != 0), "Type (C in template) does not exist in tuple.");
    enum { value = detail::tuple_element2index_helper<C,0,std::tuple_size<T>::value,T>::value };
};

} // namespace tuple
} // namespace cxxomfort

// This probably has to go in namespace std
// because otherwise we can get a "already using" error instead of an overload

namespace std {
#if (CXXOMFORT_CXX_STD >= 2014 || CXXOMFORT_CXX_EMULATION == 2014)
    // already available, do nothing
#elif (CXXOMFORT_CXX_STD == 2011 || (CXXO_COMPILER_SUPPORT_variadic && CXXO_COMPILER_SUPPORT_rvref) )

// three overloads as per cppreference

template <typename C, typename... Targs
/* , typename = std::enable_if< cxxomfort::tuple::tuple_index<C,std::tuple<Targs...> >::value != -1 */
> 
C&& get (std::tuple<Targs...>&& t) CXXO_NOEXCEPT {
    enum { N = cxxomfort::tuple::tuple_index<C, std::tuple<Targs...> >::value };
    return std::forward<C>(get<N>(t));
}

template <typename C, typename... Targs
/* , typename = std::enable_if< cxxomfort::tuple::tuple_index<C,std::tuple<Targs...> >::value != -1  */
>
C const& get (std::tuple<Targs...> const& t) CXXO_NOEXCEPT {
    enum { N = cxxomfort::tuple::tuple_index<C, std::tuple<Targs...> >::value };
    return (get<N>(t));
}

template <typename C, typename... Targs
, typename = std::enable_if< cxxomfort::tuple::tuple_index<C,std::tuple<Targs...> >::value != -1> 
>
C& get (std::tuple<Targs...> & t) CXXO_NOEXCEPT {
    enum { N = cxxomfort::tuple::tuple_index<C, std::tuple<Targs...> >::value };
    return (get<N>(t));
}

#else
// at this point, c++03

template <typename C, typename Tuple>
typename std::enable_if< cxxomfort::tuple::is_tuple<Tuple>::value ,
    typename std::tuple_element< cxxomfort::tuple::tuple_index<C,Tuple>::value, Tuple>::type
>::type
const& get (Tuple const& t) {
    enum { N = cxxomfort::tuple::tuple_index<C,Tuple>::value }; 
    return get<N>(t);
}

template <typename C, typename Tuple>
typename std::enable_if< cxxomfort::tuple::is_tuple<Tuple>::value && (cxxomfort::tuple::tuple_index<C,Tuple>::value != -1), 
    typename std::tuple_element< cxxomfort::tuple::tuple_index<C,Tuple>::value, Tuple>::type&
>::type
get (Tuple& t) {
    enum { N = cxxomfort::tuple::tuple_index<C,Tuple>::value }; 
    return get<N>(t);
}

#endif
}


// Implement interface for std::pair

/*
namespace std {

template <typename C, typename T2>
C const& get(std::pair<C,T2> const& p) { 
    enum { value= detail::tuple_element2index_helper_pair<C,T2>::value };
    return p.first; 
}
template <typename C, typename T1>
C const& get(std::pair<T1,C> const& p) { 
    enum { value= detail::tuple_element2index_helper_pair<T1,C>::value };
    return p.second;
}

template <typename C, typename T2>
C & get(std::pair<C,T2> & p) { 
    enum { value= detail::tuple_element2index_helper_pair<C,T2>::value };
    return p.first; 
}
template <typename C, typename T1>
C & get(std::pair<T1,C> & p) { 
    enum { value= detail::tuple_element2index_helper_pair<T1,C>::value };
    return p.second;
}

}
*/

// bring the new names to namespace std
namespace std {
    //using ::cxxomfort::tuple::get;
    using ::cxxomfort::tuple::tuple_index;
}

//#undef CXXO_TI_STRI0(x)
//#undef CXXO_TI_STRI(x)

#endif // CXXOMFORT_EXTRAS_LOCALFN_HPP


