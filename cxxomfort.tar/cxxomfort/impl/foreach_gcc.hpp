// A stripped down version of FOREACH for
// illustration purposes. NOT FOR GENERAL USE.
// For a complete implementation, see BOOST_FOREACH at
// http://boost-sandbox.sourceforge.net/vault/index.php?directory=eric_niebler
//
// Copyright 2004 Eric Niebler.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

//#include <functional>
#include <cxxomfort/config.hpp>
#include <cxxomfort/base/iterator.hpp> // global begin, end
#include <cxxomfort/util/type_traits.hpp>
#include <cxxomfort/util/meta.hpp>
#include <cxxomfort/memory.hpp> // alignof, aligned_storage

namespace cxxomfort {
namespace extras {

struct seq2iter_base {
    operator bool () const { return false; }
};

template <typename T, bool B=false>
struct seq2iter_impl {
    typedef typename T::iterator iterator;
};

template <typename T>
struct seq2iter_impl<T const,false> {
    typedef typename T::const_iterator iterator;
};

// T is an array
template <typename T, size_t N>
struct seq2iter_impl<T[N],true> {
    typedef T* iterator;
};

// T is an array
template <typename T, size_t N>
struct seq2iter_impl<T const[N],true> {
    typedef T const* iterator;
};

template <typename T>
struct seq2iter 
: seq2iter_base {
    private:
    typedef typename seq2iter_impl< T, std::is_array<T>::value >::iterator iterator;
    public:
    mutable iterator _i;
    seq2iter (typename seq2iter_impl< T, std::is_array<T>::value >::iterator const& i)
    : _i(i) {}
    
};

// for compilers that support __typeof__

#define CXXO_FOREACH(item,container)    \
if (::cxxomfort::extras::seq2iter< __typeof__(container) > const& bX = ::std::begin(container)) {} else \
if (::cxxomfort::extras::seq2iter< __typeof__(container) > const& eX = ::std::end(container))   {} else \
for (bool more=true; more && (bX._i != eX._i)                                     \
    ; more ? (void)++bX._i : (void)0 )                                               \
    if ((more=false)!=0) {} else                                            \
    for( item = *bX._i; !more; more=true)


}
}

