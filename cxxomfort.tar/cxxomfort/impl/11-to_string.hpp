#ifndef CXXOMFORT_IMPL_STRING_HPP
#define CXXOMFORT_IMPL_STRING_HPP
/**
 * @file impl/11-to_string.hpp
 * @brief Implements the "to_string" functionality.
 *
 * This file implements the template function "to_string", 
 * which converts a builtin integral type to a decimal representation 
 * in a @c std::string , and the template functions "stoul" and "stoi" which 
 * perform the inverse function.
 * 
 * Interfaces defined in this file:
 * 
 * @arg @c std::to_string  (for integral types)
 * @arg @c std::sto[u]l[l] (for integral types)
 * 
 * This version of "to_string" has only support for integral types, 
 * eg.: @c int , @c short and similar. Floating-point type support 
 * or wstring support are not yet available.
 * 
 */

#include <cxxomfort/cxxomfort.hpp>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <stdlib.h> // for MSVC?
#include <stdexcept>
#include <limits>
#include <vector>
#include <cerrno>

#if (CXXOMFORT_CXX_STD >= 2011)
#else
    #define CXXOMFORT_USING_to_string
#endif

#if defined(CXXOMFORT_USING_to_string)

#if (defined(CXXOMFORT_NOTICES))
    #if (CXXOMFORT_NOTICES > 1)
    #pragma message CXXO_NOTICE("enabled to_string helper.")
    #endif
#endif

#define CXXO_INTEGERDIGITS(T) std::numeric_limits< T >::digits10 + 3
#define CXXO_FLOATDIGITS(T) std::numeric_limits< T >::digits10 + 8

//
// MSVC <= 2010 is missing strtoll, strtoull definitions, but has the 
// functions proper under other names
//
#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_MSC \
    && CXXOMFORT_COMPILER_VERSION >= 130 && CXXOMFORT_COMPILER_VERSION <= 160)
//namespace std {
    static inline unsigned long long strtoull (const char* np, char ** ep, int b=10) {
        return _strtoui64(np,ep,b);
    }
    static inline signed long long strtoll (const char* np, char ** ep, int b=10) {
        return _strtoi64(np,ep,b);
    }
//}

#endif // MSVC fix

//
// MSVC 2010 implements incorrect to_string, with only three overloads
// https://stackoverflow.com/questions/10664699/stdto-string-more-than-instance-of-overloaded-function-matches-the-argument
//

namespace cxxomfort {
namespace string {

namespace detail_string {

template <typename T> struct printfmask {};

template <> struct printfmask<signed int> {
    static char const * /*const*/ mask () { return "%d"; };
    static const uint16_t len= CXXO_INTEGERDIGITS(signed int);
};
//char const * const printfmask<signed int>::mask = "%d";

template <> struct printfmask<signed short> : printfmask<signed int> {};


template <> struct printfmask<signed long> {
    static char const * /*const*/ mask () { return "%ld"; };
    static const uint16_t len= CXXO_INTEGERDIGITS(signed long);
};
//char const * const printfmask<signed long>::mask= "%ld";

template <> struct printfmask<signed long long> {
    static char const * /*const*/ mask () { return  "%lld"; };
    static const uint16_t len= CXXO_INTEGERDIGITS(signed long long);
};
//char const * const printfmask<signed long long>::mask= "%lld";

template <> struct printfmask<unsigned int> {
    static char const * /*const*/ mask () { return "%u"; };
    static const uint16_t len= CXXO_INTEGERDIGITS(unsigned int);
};
//char const * const printfmask<unsigned int>::mask= "%u";

template <> struct printfmask<unsigned short> : printfmask<unsigned int> {};

template <> struct printfmask<unsigned long> {
    static char const * /*const*/ mask () { return "%lu"; };
    static const uint16_t len= CXXO_INTEGERDIGITS(unsigned long);
};
//char const * const printfmask<unsigned long>::mask= "%lu";

template <> struct printfmask<unsigned long long> {
    static char const * /*const*/ mask () { return "%llu"; };
    static const uint16_t len= CXXO_INTEGERDIGITS(unsigned long long);
};
//char const * const printfmask<unsigned long long>::mask= "%llu";

template <> struct printfmask<float> {
    static char const * /*const*/ mask () { return "%f"; };
    static const uint16_t len= CXXO_FLOATDIGITS(float);
};
//char const * const printfmask<float>::mask= "%f";

template <> struct printfmask<double> {
    static char const * /*const*/ mask () { return "%f"; };
    static const uint16_t len= CXXO_FLOATDIGITS(double);
};
//char const * const printfmask<double>::mask= "%f";

template <> struct printfmask<long double> {
    static char const * /*const*/ mask () { return "%Lf"; };
    static const uint16_t len= CXXO_FLOATDIGITS(long double);
};
//char const * const printfmask<long double>::mask= "%Lf";

//! @internal
template <typename I, typename T>
inline void fill (I a, I b, T const& v) {
    for (; a != b; ++a) { *a= v; }
}


template <typename Numeric> std::string stringexpr (Numeric t) {
    static_assert ( ::cxxomfort::traits::is_arithmetic<Numeric>::value, "to_string requires a numeric type.");
    char buf [ printfmask<Numeric>::len ] = {'\0'};
    int srv = ::sprintf(buf, printfmask<Numeric>::mask(), t);
    if (srv < 0) return "";
    else return std::string(buf);
}

template <typename Integral> struct fn_s_to_i {};
template <> struct fn_s_to_i<unsigned long> {
    typedef unsigned long (*fn_t)(const char*, char**, int);
    static fn_t fn () { return strtoul; }
};
template <> struct fn_s_to_i<unsigned long long> {
    typedef unsigned long long (*fn_t)(const char*, char**, int);
    static fn_t fn () { return strtoull; }
};
template <> struct fn_s_to_i<signed long> {
    typedef signed long (*fn_t)(const char*, char**, int);
    static fn_t fn () { return strtol; }
};
template <> struct fn_s_to_i<signed long long> {
    typedef signed long long (*fn_t)(const char*, char**, int);
    static fn_t fn () { return strtoll; }
};


template <typename Integral> struct  string_to_integral {
    typedef Integral(*convertfn)(const char*, char**, int);

    string_to_integral (std::string const& str, size_t *pinv, int base)
    : _s(str), _p(pinv), _b(base), _pfn( fn_s_to_i<Integral>::fn() ) {
    }
    
    operator Integral () const {
        using namespace std;
        Integral ret= 0;
        // we do here the job of conversion. 
        if (_s.empty()) throw invalid_argument("string2integral: empty string to convert to integral");
        vector<char> vstr (_s.begin(), _s.end());
        vstr.push_back('\0');
        char *eipos;
        char *b= &(vstr[0]);
        //char *e= b + vstr.size();
        ret = _pfn( b, &eipos, _b);
        int err= errno;
        const std::string throwmsg= std::string("string2integral: conversion of string \"") + _s + "\" to integral";
        if (err==ERANGE) throw out_of_range( throwmsg );
        else if (err==EINVAL || eipos==b) throw invalid_argument( "string2integral: invalid argument in call to");
        //std::cerr<< "[err="<< err<< "]"<< std::endl;
        if (_p) *_p = (eipos - b);
        return ret;
    }

    private:
    std::string const& _s;
    string_to_integral& operator= (string_to_integral const&);

    size_t* _p;
    const int _b;
    convertfn _pfn;
};


} //cxxomfort::string::detail_string


/**
 * @ingroup string
 * @{
 */

static inline std::string to_string (unsigned short u) {
    return detail_string::stringexpr(u);
}
//! @overloads to_string
static inline std::string to_string (long long i) {
    return detail_string::stringexpr(i);
}
//! @overloads to_string
static inline std::string to_string (unsigned long long u) {
    return detail_string::stringexpr(u);
}
//! @overloads to_string
static inline std::string to_string (long double i) {
    return detail_string::stringexpr(i);
}
//! @overloads to_string
static inline std::string to_string (unsigned int u) {
    return detail_string::stringexpr(u);
}
//! @overloads to_string
static inline std::string to_string (short i) {
    return detail_string::stringexpr(i);
}
//! @overloads to_string
static inline std::string to_string (long i) {
    return detail_string::stringexpr(i);
}
//! @overloads to_string
static inline std::string to_string (int i) {
    return detail_string::stringexpr(i);
}
//! @overloads to_string
static inline std::string to_string (unsigned long u) {
    return detail_string::stringexpr(u);
}
//! @overloads to_string
static inline std::string to_string (float i) {
    return detail_string::stringexpr(i);
}
//! @overloads to_string
static inline std::string to_string (double i) {
    return detail_string::stringexpr(i);
}

/*
std::wstring to_wstring (unsigned int i) {
    return detail::stringexpr(i);
}

std::wstring to_wstring (int i) {
    return detail::stringexpr(i);
}
*/



static inline unsigned long       stoul (std::string const& str, size_t* pinv, int base=10) {
    return detail_string::string_to_integral<unsigned long>(str,pinv,base);
//    return strtoul (str.c_str(), pinv, base);
}

static inline unsigned long long  stoull (std::string const& str, size_t* pinv, int base=10) {
    return detail_string::string_to_integral<unsigned long long>(str,pinv,base);
//    return strtoull (str.c_str(), pinv, base);
}

static inline signed long         stol (std::string const& str, size_t * pinv, int base=10) {
    return detail_string::string_to_integral<signed long>(str,pinv,base);
//    return strtol (str.c_str(), pinv, base);
}

static inline signed long long    stoll (std::string const& str, size_t * pinv, int base=10) {
    return detail_string::string_to_integral<signed long long>(str,pinv,base);
//    return strtoll (str.c_str(), pinv, base);
}

/**
 * @}
 */

} //~namespace string
} //~namespace cxxomfort


#if (CXXOMFORT_CXX_STD >= 2011)
#elif (CXXOMFORT_CXX_EMULATION==0)
namespace std {

    //! using to_string (backport to c++03)
    //! @ref cxx03-backports
    using ::cxxomfort::string::to_string;

    using ::cxxomfort::string::stoul;
    using ::cxxomfort::string::stol;
    using ::cxxomfort::string::stoull;
    using ::cxxomfort::string::stoll;
}
#elif (CXXOMFORT_CXX_EMULATION>0)
namespace std {
    // GCC already brings those names
    #if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC)
    // MSC brings some of them
    #elif (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_MSC)
        #if (CXXOMFORT_COMPILER_VERSION==160)
        // MSVC 2010 has failing overloads for to_string
            #if (CXXOMFORT_NOTICES > 2)
                #pragma message CXXO_NOTICE("adding missing overloads to to_string")
            #endif
        using ::cxxomfort::string::to_string;
    // MSVC 2010 already has stol, stoul, but lacks the long long versions
        #elif (CXXOMFORT_COMPILER_VERSION < 160)
        using ::cxxomfort::string::stol;
        using ::cxxomfort::string::stoul;
        using ::cxxomfort::string::to_string;
        #endif
    using ::cxxomfort::string::stoll;
    using ::cxxomfort::string::stoull;
    #endif
}
#endif // (c++11)

#endif

#endif
