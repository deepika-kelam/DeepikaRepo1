#ifndef CXXOMFORT_IMPL_PERMUTATIONS_HPP
#define CXXOMFORT_IMPL_PERMUTATIONS_HPP

#include <algorithm>
#include <utility>

namespace cxxomfort {
namespace algorithm {

/* Returns true if range [iniA,finA] (with internally calculated finA) 
 * is a permutation of range [ini1,fin1).
 * Source: cppreference.com
 */
template <typename It1, typename ItA>
bool is_permutation (It1 ini1, It1 fin1, ItA iniA) {
    using namespace std;
    // skip common prefix
    pair<It1&,ItA&>(ini1,iniA) = mismatch(ini1,fin1,iniA);
    if (ini1!=fin1) {
        // there is a mismatch
        ItA movA = iniA;
        advance(movA, distance(ini1,fin1) );
        for (It1 i = ini1; i != fin1; ++i) {
            if (i != find(ini1, i, *i)) continue; // already counted
            typename iterator_traits<ItA>::difference_type d = count(iniA,movA,*i);
            typename iterator_traits<It1>::difference_type q = count(i,fin1,*i);
            if (d == 0 || q != d) return false;
        }
    }
    return true;
}

// next_permutation
template<typename BidirIt, typename Compare>
bool next_permutation (BidirIt ini, BidirIt fin, Compare Less) {
    if (ini == fin) return false;
    BidirIt i = fin;
    if (ini == --i) return false;
 
    while (true) {
        BidirIt i1, i2;
 
        i1 = i;
        if ( Less(*--i , *i1)) {
            i2 = fin;
            while (!Less(*i , *--i2));
            std::iter_swap(i, i2);
            std::reverse(i1, fin);
            return true;
        }
        if (i == ini) {
            std::reverse(ini, fin);
            return false;
        }
    }
}

template<typename BidirIt>
bool next_permutation (BidirIt ini, BidirIt fin) {
    std::less<typename std::iterator_traits<BidirIt>::value_type> less;
    return next_permutation(ini, fin, less);
}

// prev_permutation

template<typename BidirIt, typename Compare>
bool prev_permutation (BidirIt ini, BidirIt fin, Compare less) {
    if (ini == fin) return false;
    BidirIt i = fin;
    if (ini == --i) return false;
 
    while (true) {
        BidirIt i1, i2;
        i1 = i;
        if (less(*i1 , *--i)) {
            i2 = fin;
            while (!less(*--i2 , *i)) ;
            std::iter_swap(i, i2);
            std::reverse(i1, fin);
            return true;
        }
        if (i == ini) {
            std::reverse(ini, fin);
            return false;
        }
    }
}

template<typename BidirIt>
bool prev_permutation (BidirIt ini, BidirIt fin) {
    std::less<typename std::iterator_traits<BidirIt>::value_type> less;
    return prev_permutation(ini, fin, less);
}

} // cxxomfort::algo
} // cxxomfort

// These were added in c++11
#if (CXXOMFORT_CXX_STD < 2011)
namespace std {
// [next,prev]_permutation already present in GCC >= 4.4 as an extension
#if (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_GCC && CXXOMFORT_COMPILER_VERSION < 404)
    using ::cxxomfort::algorithm::is_permutation;
    using ::cxxomfort::algorithm::prev_permutation;
    using ::cxxomfort::algorithm::next_permutation;
#endif

}
#endif // c++11

#endif
