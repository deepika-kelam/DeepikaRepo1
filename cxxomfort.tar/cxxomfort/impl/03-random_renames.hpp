#ifndef CXXOMFORT_IMPL_RANDOM_RENAMES_HPP
#define CXXOMFORT_IMPL_RANDOM_RENAMES_HPP

#include "./base.hpp"
#include CXXO_INCLUDE_SYS(random)

// fix renamed functors in <random> between C++03 TR1 and C++11
#if (CXXOMFORT_CXX_STD < 2011)
namespace std {
namespace tr1 {

// These are only "good enough to work" fixes.

template <typename II, II _w, II _s, II _r>
class subtract_with_carry_engine 
: public subtract_with_carry<II,_w,_s,_r> {
    public:
    typedef typename subtract_with_carry<II,_w,_s,_r>::result_type result_type;
    subtract_with_carry_engine(result_type s=0) 
    : subtract_with_carry<II,_w,_s,_r>(s) {}
};

typedef subtract_with_carry_engine<uint_fast32_t, 24,10,24> ranlux24_base;

template <typename II>
class uniform_int_distribution
: public uniform_int<II> {
    public:
    uniform_int_distribution(II a, II b)
    : uniform_int<II>(a,b) {}
};

template <typename Real>
class uniform_real_distribution
: public uniform_real<Real> {
    public:
    uniform_real_distribution(Real a, Real b)
    : uniform_real<Real>(a,b) {}
};


} // namespace tr1
} // namespace std

#endif // fix

#endif
