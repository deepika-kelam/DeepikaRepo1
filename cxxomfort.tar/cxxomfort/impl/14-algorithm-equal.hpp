#ifndef CXXOMFORT_IMPL_ALGORITHM_14EQUAL_HPP
#define CXXOMFORT_IMPL_ALGORITHM_14EQUAL_HPP

#include <cxxomfort/base.hpp>
#include <type_traits>
#include "../algorithms.hpp"
// <algorithm> should have been included already

namespace cxxomfort {

//
// explicit sized ranges for equal, from C++14
//
namespace detail_algorithm {
template <typename T1, typename T2> struct heterogenous_equal_to {
    bool operator() (T1 const& t1, T2 const& t2) const { return t1 == t2; }
};

template <typename RangeIt1, typename RangeIt2, typename Compare> inline 
bool equal_impl (RangeIt1 ini1, RangeIt1 fin1, RangeIt2 ini2, RangeIt2 fin2, Compare c, traits::false_type /*iterator_tags are non-random-access*/) {
    for (; ini1 != fin1 && ini2 != fin2 ; ++ini1, ++ini2) {
        if (!c(*ini1, *ini2)) return false;
    }
    if ( (ini1 != fin1)|| (ini2 != fin2) ) return false;
    return true;
}

template <typename RangeIt1, typename RangeIt2, typename Compare> inline 
bool equal_impl (RangeIt1 ini1, RangeIt1 fin1, RangeIt2 ini2, RangeIt2 fin2, Compare c, traits::true_type) {
    if ((fin1-ini1)!=(fin2-ini2)) return false; // ranges are of different size
    return std::equal( ini1, fin1, ini2, c);
}


} //detail_algorithm

/**
 * @addtogroup cxx11-backports
 * @{
 */

//! Compare two sequences [ini1,fin1) and [ini2,fin2) for 
//! equality given comparator @p eq .
template <typename RangeIt1, typename RangeIt2, typename Compare> inline 
bool 
equal (RangeIt1 ini1, RangeIt1 fin1, RangeIt2 ini2, RangeIt2 fin2, Compare eq) {
    typedef typename std::iterator_traits<RangeIt1>::iterator_category cat_1;
    typedef typename std::iterator_traits<RangeIt2>::iterator_category cat_2;
    typedef std::random_access_iterator_tag rtag;
    using traits::is_same;
    typedef typename std::conditional< 
        (is_same<cat_1,rtag>::value and is_same<cat_2,rtag>::value)
        , traits::true_type, traits::false_type
    >::type dispatcher_t;
    return detail_algorithm::equal_impl(ini1,fin1,ini2,fin2,eq,dispatcher_t());
}

//! Compare two sequences for equality.
//! @overloads equal(ini1,fin1,ini2,fin2,eq)
template <typename RangeIt1, typename RangeIt2> inline 
bool 
equal (RangeIt1 ini1, RangeIt1 fin1, RangeIt2 ini2, RangeIt2 fin2) {
    typedef typename std::iterator_traits<RangeIt1>::value_type T1;
    typedef typename std::iterator_traits<RangeIt2>::value_type T2;
    detail_algorithm::heterogenous_equal_to< T1, T2 > this_eq;
    return detail_algorithm::equal_impl(ini1, fin1, ini2, fin2, this_eq);
}

//
// explicit sized ranges for mismatch, from C++14
//

//! Finds the first difference (dif1,dif2) between two
//! sequences [ini1,fin1) and [ini2,fin2), given comparator @p eq .
template<class InputIt1, class InputIt2, class BinaryPredicate>
std::pair<InputIt1, InputIt2>
mismatch (InputIt1 ini1, InputIt1 fin1, InputIt2 ini2, InputIt2 fin2, BinaryPredicate p) {
    while (ini1 != fin1 && ini2 != fin2 && p(*ini1, *ini2)) {
        ++ini1, ++ini2;
    }
    return std::make_pair(ini1, ini2);
}

//! Finds the first difference (dif1,dif2) between two sequences.
template<class InputIt1, class InputIt2>
std::pair<InputIt1, InputIt2>
mismatch (InputIt1 ini1, InputIt1 fin1, InputIt2 ini2, InputIt2 fin2) {
    typedef typename std::iterator_traits<InputIt1>::value_type T1;
    typedef typename std::iterator_traits<InputIt2>::value_type T2;
    detail_algorithm::heterogenous_equal_to< T1, T2 > this_eq;
    return mismatch(ini1, fin1, ini2, fin2, this_eq);
}

/**
 * @}
 */

} // cxxomfort

#endif
