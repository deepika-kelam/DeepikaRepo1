#ifndef CXXOMFORT_EXTRAS_REGEX_HPP
#define CXXOMFORT_EXTRAS_REGEX_HPP
#include <cxxomfort/config.hpp>
/**
 * @file extras/regex.hpp
 * @brief Escape de secuencias regex
 * 
 * Awesome trick to write raw regexes in C++03, also works in C++11:
 * http://stackoverflow.com/questions/3978351/how-to-avoid-backslash-escape-when-writing-regular-expression-in-c-c
 * 
**/

/* Usage mode:

CXXO_R(re, "\w\d");
preg_match(re, "Hello, world0!");

*/ 


#if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
    #pragma message CXXO_NOTICE("enabled regex CXXO_R() escape helper")
#endif

#define CXXO_PAR(a) (a)
#define CXXO_R(var, re)  static char var##_ [] = CXXO_STRINGIZE(re);\
const char * var = ( var##_[ sizeof(var##_) - 2] = '\0',  (var##_ + 1) );

#endif
