#ifndef CXXOMFORT_IMPL_AS_CONST_HPP
#define CXXOMFORT_IMPL_AS_CONST_HPP
/**
 * @file impl/17-as_const.hpp
 * @brief Implements "as_const" proposal.
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 *
 */

// http://www.open-std.org/JTC1/SC22/WG21/docs/papers/2015/n4380.html

#define CXXOMFORT_IMPLEMENTS_n4380 1

#include "../config.hpp"
#include <utility>
#include <type_traits>
#include <cxxomfort/using.hpp>

// would go in <utility>
// works with l-values only

namespace cxxomfort {

/**
 * @ingroup utility
 * @ref cxx03-backports
 * @ref cxx11-backports
 * @ref cxx14-backports
 * @{
 */

//! returns a @c const  view of object @p t .
template< typename T >
inline CXXO_CONSTEXPR typename std::add_const< T >::type & 
as_const( T &t ) CXXO_NOEXCEPT {
    return t;
}

/**
 * @}
 */

} // cxxomfort


#endif // file
