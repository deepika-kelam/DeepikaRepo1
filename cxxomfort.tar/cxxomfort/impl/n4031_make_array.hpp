#ifndef CXXOMFORT_IMPL_n4031_HPP
#define CXXOMFORT_IMPL_n4031_HPP

#include "../config.hpp"
#include "../base.hpp" // move emulation
#include <utility>
#include <array>
#include <iostream>

//
// make_array
// contructs an object of std::array<T,N> type with automatically calculated N.
// See proposal:  http://www.open-std.org/JTC1/SC22/WG21/docs/papers/2014/n4031.html
//
// http://stackoverflow.com/questions/6114067/how-to-emulate-c-array-initialization-int-arr-e1-e2-e3-behaviou
//

namespace cxxomfort {

#if (CXXOMFORT_CXX_STD >= 2011) 

// zero-size array. Needs the type given explicitly.
template <typename T>
constexpr std::array<T,0>
make_array () {
    return {{ }};
}

namespace detail_make_array {
    template <typename T>
    struct id { typedef T type; };
    
}


// Here type can be deduced (via common_type) or given explicitly.
template <typename V = void, typename... T>
constexpr auto 
make_array (T&&... t)
-> std::array <
    typename std::conditional<
        std::is_void<V>::value, typename std::common_type<T...>::type, V
    >::type
, sizeof...(T)>
{
    using namespace std;
//    typedef typename std::conditional<
//        std::is_void<V>::value, typename std::common_type<T...>::type, V
//    >::type A_Type;
    return {{ std::forward<T>(t)... }};
}

#else
// c++03 versions, with forwarding emulation
// for this implementation, the type should be given explicitly

template <typename T> inline
std::array<T,0> make_array() {
    return std::array<T,0>();
}

template <typename T> inline
std::array<T,1> make_array(CXXO_FWD_REF(T) t1) {
    std::array<T,1> ret= { {std::forward<T>(t1)} };
    return ret;
}

// make_array : 2 args

template <typename V, typename T0, typename T1> inline
std::array<V,2>  
make_array (CXXO_FWD_REF(T0) t0, CXXO_FWD_REF(T1) t1
) {
	using namespace std;
    array<V,2> ret= { {forward<T0>(t0), forward<T1>(t1)} };
    return ret;
}

// make_array : 3 args

template <typename V, typename T0, typename T1, typename T2> inline
std::array<V,3> 
make_array (CXXO_FWD_REF(T0) t0, CXXO_FWD_REF(T1) t1, CXXO_FWD_REF(T2) t2
) {
    using namespace std;
    //enum { test = ~is_same<V,T0>::value or ~is_same<V,T2>::value };
    //static_assert( test, "make_array<V,3>: same types" );
    array<V,3> ret= { {forward<T0>(t0), forward<T1>(t1), forward<T2>(t2)} };
    return ret;
}

template <typename T> inline 
std::array< typename std::decay<T const>::type ,3>
make_array (T const& t0, T const& t1, T const& t2
) {
    using namespace std;
    array< typename std::decay<T const>::type ,3> ret= { {t0, t1, t2 } };
    return ret;
}

// make_array : 4 args

template <typename V, typename T0, typename T1, typename T2, typename T3> inline
std::array<V,4> 
make_array (CXXO_FWD_REF(T0) t0, CXXO_FWD_REF(T1) t1, CXXO_FWD_REF(T2) t2
        , CXXO_FWD_REF(T3) t3
) {
    using namespace std;
    array<V,4> ret= { {forward<T0>(t0),forward<T1>(t1),forward<T2>(t2)
        , forward<T3>(t3)} };
    return ret;
}

template <typename T> inline 
std::array< typename std::decay<T>::type ,4>
make_array (T& t0, T& t1, T& t2, T& t3
) {
    using namespace std;
    array< typename std::decay<T>::type ,4> ret= { {t0, t1, t2, t3 } };
    return ret;
}


// make_array : 5 args

template <typename V, typename T0, typename T1, typename T2, typename T3, typename T4> inline
std::array<V,5> 
make_array (CXXO_FWD_REF(T0) t0, CXXO_FWD_REF(T1) t1, CXXO_FWD_REF(T2) t2
        , CXXO_FWD_REF(T3) t3, CXXO_FWD_REF(T4) t4
) {
    using namespace std;
    array<V,5> ret= { {forward<T0>(t0),forward<T1>(t1),forward<T2>(t2)
        , forward<T3>(t3), forward<T4>(t4)} };
    return ret;
}


// make_array : 6 args

template <typename V, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5> inline
std::array<V,6> make_array(
    CXXO_FWD_REF(T0) t0, CXXO_FWD_REF(T1) t1, CXXO_FWD_REF(T2) t2
  , CXXO_FWD_REF(T3) t3, CXXO_FWD_REF(T4) t4, CXXO_FWD_REF(T5) t5
) {
    using namespace std;
    std::array<V,6> ret= { {forward<T0>(t0), forward<T1>(t1), forward<T2>(t2)
      , forward<T3>(t3), forward<T4>(t4), forward<T5>(t5)} };
    return ret;
}

// make_array : 7 args

template <typename V, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6> inline
std::array<V,7> make_array(
    CXXO_FWD_REF(T0) t0, CXXO_FWD_REF(T1) t1, CXXO_FWD_REF(T2) t2
  , CXXO_FWD_REF(T3) t3, CXXO_FWD_REF(T4) t4, CXXO_FWD_REF(T5) t5
  , CXXO_FWD_REF(T6) t6
) {
    using namespace std;
    std::array<V,7> ret= { {forward<T0>(t0), forward<T1>(t1), forward<T2>(t2)
      , forward<T3>(t3), forward<T4>(t4), forward<T5>(t5)
      , forward<T6>(t6)} };
    return ret;
}

// make_array : 8 args

template <typename V, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7> inline
std::array<V,8> make_array(
    CXXO_FWD_REF(T0) t0, CXXO_FWD_REF(T1) t1, CXXO_FWD_REF(T2) t2
  , CXXO_FWD_REF(T3) t3, CXXO_FWD_REF(T4) t4, CXXO_FWD_REF(T5) t5
  , CXXO_FWD_REF(T6) t6, CXXO_FWD_REF(T7) t7
) {
    using namespace std;
    std::array<V,8> ret= { {forward<T0>(t0), forward<T1>(t1), forward<T2>(t2)
      , forward<T3>(t3), forward<T4>(t4), forward<T5>(t5)
      , forward<T6>(t6), forward<T7>(t7) } };
    return ret;
}

#endif // c++ mode

// to_array
#if (CXXOMFORT_CXX_STD >= 2011) || ((CXXO_COMPILER_SUPPORT_auto==1 && CXXO_COMPILER_SUPPORT_rvref==1 && CXXO_COMPILER_SUPPORT_constexpr==1))

namespace detail_array {

    template <size_t... I>
    struct _indices {};
     
    template <size_t N, size_t... I>
    struct _build_indices : _build_indices<N - 1, N - 1, I...> {};
    template <size_t... I>
    struct _build_indices<0, I...> : _indices<I...> {};
     

    template <typename T, size_t N, size_t... I>
    constexpr auto _to_array(T (&arr)[N], _indices<I...>)
    -> std::array< typename std::remove_cv<T>::type , N> {
        return {{ arr[I]... }};
    }
 
} // detail_array

template <typename T, size_t N>
constexpr auto to_array(T (&arr)[N])
-> std::array<typename std::remove_cv<T>::type , N> {
    return _to_array(arr, detail_array::_build_indices<N>());
} 

#else // c++03
template <typename T> inline
std::array< typename std::remove_cv<T>::type, 1> to_array (T(&arr)[1]) {
    std::array< typename std::remove_cv<T>::type, 1> ret= {{ arr[0] }};
    return ret;
}

template <typename T> inline
std::array< typename std::remove_cv<T>::type, 2> to_array (T(&arr)[2]) {
    std::array< typename std::remove_cv<T>::type, 2> ret= {{ arr[0],arr[1] }};
    return ret;
}

template <typename T> inline
std::array< typename std::remove_cv<T>::type, 3> to_array (T(&arr)[3]) {
    std::array< typename std::remove_cv<T>::type, 3> ret= {{ arr[0],arr[1],arr[2] }};
    return ret;
}

template <typename T> inline
std::array< typename std::remove_cv<T>::type, 4> to_array (T(&arr)[4]) {
    std::array< typename std::remove_cv<T>::type, 4> ret= {{ arr[0],arr[1],arr[2],arr[3] }};
    return ret;
}

#endif
  

} // cxxomfort

#endif
