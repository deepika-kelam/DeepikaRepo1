// A stripped down version of FOREACH for
// illustration purposes. NOT FOR GENERAL USE.
// For a complete implementation, see BOOST_FOREACH at
// http://boost-sandbox.sourceforge.net/vault/index.php?directory=eric_niebler
//
// Copyright 2004 Eric Niebler.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

//#include <functional>
#include <cxxomfort/config.hpp>
#include <cxxomfort/base/iterator.hpp> // global begin, end
#include <cxxomfort/util/meta.hpp>
#include <valarray>

namespace cxxomfort {
namespace detail {

///////////////////////////////////////////////////////////////////////////////
// auto_any

struct auto_any_base {
    operator bool() const { return false; }
    //virtual ~auto_any_base() {}
};


template<typename T> struct auto_any : auto_any_base {
    auto_any(T const& t) : item(t) {}
    mutable T item;
};

template<typename T> T& auto_any_cast(auto_any_base const& any) {
    return static_cast<auto_any<T> const&>(any).item;
}

///////////////////////////////////////////////////////////////////////////////
// type2type

// a simple type wrapper
template< typename T > struct type2type {};

// convert an expression of type T to an
// expression of type type2type<T>
template< class T > type2type< T > encode_type( T const & ) {
  return type2type< T >();
}

// convertible to type2type<T> for any T
struct any_type {
    template< typename T > operator type2type< T > () const {
        return type2type< T >();
    }
};

// convert an expression of type T to an
// expression of type type2type<T> without
// evaluating the expression
#define ENCODED_TYPEOF( container ) \
  ( true ? ::cxxomfort::detail::any_type() : ::cxxomfort::detail::encode_type( container ) )


///////////////////////////////////////////////////////////////////////////////
// FOREACH helper function

template <typename T>
struct type2iterator {
    typedef T container_type;
    typedef type2iterator<T> type;
    typedef typename T::value_type value_type;
    typedef typename T::iterator iterator;
    typedef typename T::const_iterator const_iterator;
};

template <> struct type2iterator <char const*> {
    typedef char const* container_type;
    typedef type2iterator<char const*> type;
    typedef char value_type;
    typedef char const* iterator;
    typedef char const* const_iterator;
};

template <typename T, size_t N> struct type2iterator <T [N]> {
    typedef T container_type[N];
    typedef type2iterator<T (&)[N]> type;
    typedef T value_type;
    typedef T * iterator;
    typedef T const* const_iterator;
};

template <typename T> struct type2iterator <std::valarray<T> > {
    typedef std::valarray<T> container_type;
    typedef T value_type;
    typedef T* iterator;
    typedef T const* const_iterator;
};


template<typename T>
auto_any<typename type2iterator<T>::const_iterator> begin(T const& t) {
    return ::cxxomfort::iterator::begin(t);
}

template<typename T>
auto_any<typename type2iterator<T>::const_iterator> end(T const& t) {
    return ::cxxomfort::iterator::end(t);
}

template<typename T>
bool done(auto_any_base const& cur, auto_any_base const& end, type2type<T>) {
    typedef typename type2iterator<T>::const_iterator iter_type;
    return auto_any_cast<iter_type>(cur) == auto_any_cast<iter_type>(end);
}

template<typename T>
void next(auto_any_base const& cur, type2type<T>) {
    typedef typename type2iterator<T>::const_iterator iter_type;
    ++auto_any_cast<iter_type>(cur);
}


template<typename T>
typename type2iterator<T>::value_type & deref(auto_any_base const& cur, type2type<T>) {
    typedef typename type2iterator<T>::iterator iter_type;
    //typedef typename T::const_iterator iter_type;
    return *auto_any_cast<iter_type>(cur);
}


} // detail::
}

///////////////////////////////////////////////////////////////////////////////
// FOREACH



#if defined(_MSC_VER)
// use a modified version with pragmas to suppress
// "assignment within conditional" warnings
#define CXXO_FOREACH(item, container)                  \
__pragma(warning(suppress:4706)) __pragma(warning(suppress:6001)) \
if(::cxxomfort::detail::auto_any_base const& bX = ::cxxomfort::detail::begin(container)) {} else   \
if(::cxxomfort::detail::auto_any_base const& eX = ::cxxomfort::detail::end(container)) {} else     \
for(bool more = true;                                   \
    more && !::cxxomfort::detail::done(bX,eX,ENCODED_TYPEOF(container));                       \
    more ? ::cxxomfort::detail::next(bX,ENCODED_TYPEOF(container)) : (void)0)                 \
    __pragma(warning(suppress:4706))                       \
    if ((more = false)!=0) {} else                           \
    for(item = ::cxxomfort::detail::deref(bX,ENCODED_TYPEOF(container)); !more; more = true)

#else
// all other compilers
#define CXXO_FOREACH(item, container)                  \
if(::cxxomfort::detail::auto_any_base const& bX = ::cxxomfort::detail::begin(container)) {} else   \
if(::cxxomfort::detail::auto_any_base const& eX = ::cxxomfort::detail::end(container)) {} else     \
for(bool more = true;                                   \
    more && !::cxxomfort::detail::done(bX,eX,ENCODED_TYPEOF(container));                       \
    more ? ::cxxomfort::detail::next(bX,ENCODED_TYPEOF(container)) : (void)0)                 \
    if ((more = false)!=0) {} else                           \
    for(item = ::cxxomfort::detail::deref(bX,ENCODED_TYPEOF(container)); !more; more = true)

#endif // foreach macro definition

#undef Suppress_

