#ifndef CXXOMFORT_IMPL_TO_BASIC_STRING_V_HPP
#define CXXOMFORT_IMPL_TO_BASIC_STRING_V_HPP
/**
 * @file cxxomfort/impl/to_basic_string_variadic.hpp
 * @brief Implements the variadic "to_basic_string" proposal in http://open-std.org/jtc1/sc22/wg21/docs/papers/2015/p0117r0.html .
 *
 * 
 * Interfaces defined in this file:
 * 
 * In namespace cxxomfort::string:
 * 
 */

#include <cxxomfort/base.hpp>
#include <string>
#include <cstring>
#include <sstream>


/*
 * The functionality of the proposal is implemented with some modifications, 
 * such that it can be used with C++03:
 * 
 * * in c++03, to_basic_string<...> requires passing all three 
 * template arguments (Ch, char_traits<Ch> and allocator<Ch>) 
 * because c++03 does not support default template arguments.
 * * to palliate the above, the function to_basic_string_defaults<...> 
 * is provided that only requires argument Ch, and deduces 
 * char_traits<Ch> and allocator<Ch> from that.
 * * in c++11 onwards, both functions are equivalent
 * 
 */

#if (CXXOMFORT_CXX_STD >= 2011)

namespace cxxomfort {
namespace string {

template<class Ch, class Tr = std::char_traits<Ch>, class Alloc = std::allocator<Ch>, class... Args>
std::basic_string<Ch,Tr,Alloc> 
to_basic_string(Args&&... args)
{
    using namespace std;
    basic_ostringstream<Ch,Tr,Alloc> stream;
    stream.exceptions(ios_base::failbit | ios_base::badbit);
//    stream << ... << forward<Args>(args); <-- c++17-specific
    int dummy[sizeof...(Args)] = { (stream << std::forward<Args>(args), 0)... }; 
    (void)dummy;
    return stream.str();
}

template<class Ch, class... Args>
std::basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> > 
to_basic_string_defaults (Args&&... args)
{
    using namespace std;
    return to_basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> >
    (forward<Args>(args)...);
}

template<class... Args>
std::string to_string(Args&&... args)
{
    using std::forward;
    return to_basic_string<char>
    (forward<Args>(args)...);
}

template<class... Args>
std::wstring to_wstring(Args&&... args)
{
    using std::forward;
    return to_basic_string<wchar_t>
    (forward<Args>(args)...);
}

} // cxxomfort::string
} // cxxomfort

#else
#include "to_basic_string_cxx03.hpp"
#endif

#if defined(DOXYGEN_DOC)

/**
 * @brief Provides a string expression of its arguments.
 * @ingroup independent-utilities
 * @ingroup cxx03-backports
 * @ingroup cxx11-backports
 * @ingroup string
 */
template<class Ch, class Tr = std::char_traits<Ch>, class Alloc = std::allocator<Ch>, class... Args>
std::basic_string<Ch,Tr,Alloc> 
to_basic_string(Args&&... args);

#endif // docs

#endif
