
//#include "../extras/optional.hpp"

namespace cxxomfort {
namespace string {
namespace detail_string {

const struct no_t {
    template <typename Ch, typename Tr, typename Alloc>
    friend std::basic_ostringstream<Ch,Tr,Alloc>& 
    operator<< (std::basic_ostringstream<Ch,Tr,Alloc>& os, no_t const& n) {
        return os;
}

} noitem = {};


template <
typename Stream
>
struct streamizer {
    streamizer (Stream& s)
    : stream(s) 
    {
        using namespace std;
        stream.exceptions(ios_base::failbit | ios_base::badbit);
    }

    template <typename T>
    streamizer& operator<< (T const& t) const {
        stream<< t;
        return *this;
    }

    Stream& stream;
    
};


} // cxxomfort::string::detail_string


template <typename Ch, typename Tr, typename Alloc
, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8, typename T9
>
std::basic_string<Ch,Tr,Alloc> 
to_basic_string
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4, T5 const& t5, T6 const& t6, T7 const& t7, T8 const& t8, T9 const& t9) {
    using namespace std;
    typedef basic_ostringstream<Ch,Tr,Alloc> stream_t;
    stream_t stream;
    //detail_string::streamizer<stream_t> s(stream);
    int dummy[] = { (stream<< t0, 0)
        , (stream<< t1, 0), (stream<< t2, 0), (stream<< t3, 0)
        , (stream<< t4, 0), (stream<< t5, 0), (stream<< t6, 0)
        , (stream<< t7, 0), (stream<< t8, 0), (stream<< t9, 0)
    }; 
    (void)dummy;
    return stream.str();

}

// 9 arguments
template <typename Ch, typename Tr, typename Alloc
, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8
>
std::basic_string<Ch,Tr,Alloc> 
to_basic_string
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4, T5 const& t5, T6 const& t6, T7 const& t7, T8 const& t8) {
    return to_basic_string<Ch,Tr,Alloc> (t0,t1,t2,t3,t4,t5,t6,t7,t8,detail_string::noitem);
}

// 8 arguments
template <typename Ch, typename Tr, typename Alloc
, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7
>
std::basic_string<Ch,Tr,Alloc> 
to_basic_string
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4, T5 const& t5, T6 const& t6, T7 const& t7) {
    return to_basic_string<Ch,Tr,Alloc> (t0,t1,t2,t3,t4,t5,t6,t7,detail_string::noitem, detail_string::noitem);
}

// 7 arguments
template <typename Ch, typename Tr, typename Alloc
, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6
>
std::basic_string<Ch,Tr,Alloc> 
to_basic_string
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4, T5 const& t5, T6 const& t6) {
    return to_basic_string<Ch,Tr,Alloc> (t0,t1,t2,t3,t4,t5,t6, detail_string::noitem, detail_string::noitem, detail_string::noitem, detail_string::noitem);
}

// 6 arguments
template <typename Ch, typename Tr, typename Alloc
, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5
>
std::basic_string<Ch,Tr,Alloc> 
to_basic_string
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4, T5 const& t5) {
    return to_basic_string<Ch,Tr,Alloc> (t0,t1,t2,t3,t4,t5,
    detail_string::noitem, detail_string::noitem, detail_string::noitem, detail_string::noitem);
}


// 5 arguments
template <typename Ch, typename Tr, typename Alloc
, typename T0, typename T1, typename T2, typename T3, typename T4
>
std::basic_string<Ch,Tr,Alloc> 
to_basic_string
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4) {
    return to_basic_string<Ch,Tr,Alloc> (t0,t1,t2,t3,t4,
    detail_string::noitem, detail_string::noitem, detail_string::noitem, detail_string::noitem, detail_string::noitem);
}

// 4 arguments
template <typename Ch, typename Tr, typename Alloc
, typename T0, typename T1, typename T2, typename T3
>
std::basic_string<Ch,Tr,Alloc> 
to_basic_string
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3) {
    return to_basic_string<Ch,Tr,Alloc> (t0,t1,t2,t3,
    detail_string::noitem, detail_string::noitem, detail_string::noitem, 
    detail_string::noitem, detail_string::noitem, detail_string::noitem);
}

// 3 arguments
template <typename Ch, typename Tr, typename Alloc
, typename T0, typename T1, typename T2
>
std::basic_string<Ch,Tr,Alloc> 
to_basic_string
(T0 const& t0, T1 const& t1, T2 const& t2) {
    return to_basic_string<Ch,Tr,Alloc> (t0,t1,t2,
    detail_string::noitem, 
    detail_string::noitem, 
    detail_string::noitem, 
    detail_string::noitem, 
    detail_string::noitem, 
    detail_string::noitem, 
    detail_string::noitem);
}

// 2 arguments
template <typename Ch, typename Tr, typename Alloc
, typename T0, typename T1
>
std::basic_string<Ch,Tr,Alloc> 
to_basic_string
(T0 const& t0, T1 const& t1) {
    return to_basic_string<Ch,Tr,Alloc> (t0,t1,
    detail_string::noitem, detail_string::noitem, detail_string::noitem, 
    detail_string::noitem, detail_string::noitem, detail_string::noitem, 
    detail_string::noitem, detail_string::noitem);
}


//
// to_basic_string_defaults
//

template <typename Ch
, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8, typename T9
>
std::basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> > 
to_basic_string_defaults
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4, T5 const& t5, T6 const& t6, T7 const& t7, T8 const& t8, T9 const& t9) {
    return to_basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> >
    (t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);
}

// 9 arguments
template <typename Ch, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8>
std::basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> > 
to_basic_string_defaults
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4, T5 const& t5, T6 const& t6, T7 const& t7, T8 const& t8) {
    return to_basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> >
    (t0,t1,t2,t3,t4,t5,t6,t7,t8);
}

// 8 arguments
template <typename Ch, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7>
std::basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> > 
to_basic_string_defaults
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4, T5 const& t5, T6 const& t6, T7 const& t7) {
    return to_basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> >
    (t0,t1,t2,t3,t4,t5,t6,t7);
}

// 7 arguments
template <typename Ch, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6>
std::basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> > 
to_basic_string_defaults
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4, T5 const& t5, T6 const& t6) {
    return to_basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> >
    (t0,t1,t2,t3,t4,t5,t6);
}

// 6 arguments
template <typename Ch, typename T0, typename T1, typename T2, typename T3, typename T4, typename T5>
std::basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> > 
to_basic_string_defaults
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4, T5 const& t5) {
    return to_basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> >
    (t0,t1,t2,t3,t4,t5);
}

// 5 arguments
template <typename Ch, typename T0, typename T1, typename T2, typename T3, typename T4>
std::basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> > 
to_basic_string_defaults
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4) {
    return to_basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> >
    (t0,t1,t2,t3,t4);
}

// 4 arguments
template <typename Ch, typename T0, typename T1, typename T2, typename T3>
std::basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> > 
to_basic_string_defaults
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3) {
    return to_basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> >
    (t0,t1,t2,t3);
}

// 3 arguments
template <typename Ch, typename T0, typename T1, typename T2>
std::basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> > 
to_basic_string_defaults
(T0 const& t0, T1 const& t1, T2 const& t2) {
    return to_basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> >
    (t0,t1,t2);
}

// 2 arguments
template <typename Ch, typename T0, typename T1>
std::basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> > 
to_basic_string_defaults
(T0 const& t0, T1 const& t1) {
    return to_basic_string<Ch, std::char_traits<Ch>, std::allocator<Ch> >
    (t0,t1);
}

//
// to_string
//

/*
using namespace cxxomfort::extras::optional;

template <
typename T0, typename T1, typename T2, typename T3, typename T4, 
typename T5, typename T6, typename T7, typename T8, typename T9
>
std::string to_string (
optional<T0 const&> const& t0
, optional<T1> const& t1, optional<T2> const& t2= nullopt, optional<T3> const& t3= nullopt, optional<T4> const& t4= nullopt, optional<T5> const& t5= nullopt, optional<T6> const& t6= nullopt, optional<T7> const& t7= nullopt, optional<T8> const& t8= nullopt, optional<T9> const& t9= nullopt) {
    typedef std::basic_ostringstream<char, std::char_traits<char>, std::allocator<char> > stream_t;
    stream_t stream;
    //detail_string::streamizer<stream_t> s(stream);
    if (t0) stream<< t0;
    if (t1) stream<< t1;
    if (t2) stream<< t2;
    if (t3) stream<< t3;
    if (t4) stream<< t4;
    if (t5) stream<< t5;
    if (t6) stream<< t6;
    if (t7) stream<< t7;
    if (t8) stream<< t8;
    if (t9) stream<< t9;
    
    return stream.str();

    //return to_basic_string_defaults<char>(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);
}

*/

template <typename T0, typename T1, typename T2, typename T3, typename T4, typename T5, typename T6, typename T7, typename T8, typename T9
>
std::string to_string
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4, T5 const& t5, T6 const& t6, T7 const& t7, T8 const& t8, T9 const& t9) {
    return to_basic_string_defaults<char>(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);
}

// 6 arguments
template <typename T0, typename T1, typename T2, typename T3, typename T4, typename T5
>
std::string  to_string
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4, T5 const& t5) {
    return to_basic_string_defaults<char>(t0,t1,t2,t3,t4,t5);
}

// 5 arguments
template <typename T0, typename T1, typename T2, typename T3, typename T4>
std::string  to_string
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3, T4 const& t4) {
    return to_basic_string_defaults<char>(t0,t1,t2,t3,t4);
}

// 4 arguments
template <typename T0, typename T1, typename T2, typename T3>
std::string  to_string
(T0 const& t0, T1 const& t1, T2 const& t2, T3 const& t3) {
    return to_basic_string_defaults<char>(t0,t1,t2,t3);
}

// 3 arguments
template <typename T0, typename T1, typename T2>
std::string  to_string
(T0 const& t0, T1 const& t1, T2 const& t2) {
    return to_basic_string_defaults<char>(t0,t1,t2);
}

} // string
} // cxxomfort
