#ifndef CXXOMFORT_IMPL_VOID_T_HPP
#define CXXOMFORT_IMPL_VOID_T_HPP
/**
 * @file impl/17-void_t.hpp
 * @brief Header file providing implementation of the "void_t" concept.
 * 
 * @sa http://en.cppreference.com/w/cpp/types/void_t
 * @sa n3911
 * 
 */

#include <cxxomfort/config.hpp>
#define CXXOMFORT_IMPLEMENTS_n3911 CXXO_BACKPORT()

#if (CXXOMFORT_CXX_STD < 2017)

// void_t and make_void for c++03, c++11, c++14

namespace cxxomfort {
#if (CXXOMFORT_CXX_STD < 2011)
    //! @internal
    template <typename T0=void, typename T1=void, typename T2=void, typename T3=void, typename T4=void, typename T5=void, typename T6=void, typename T7=void, typename T8=void, typename T9=void>
#else
    //! @internal
    template <typename... Types>
#endif
    struct make_void {
        typedef void type;
    };
}

namespace std {
    using ::cxxomfort::make_void;
}

// "void_t" is an alias, so it doesn't work in c++03
// it has to go in std:: because it is use in template arguments
#if (CXXOMFORT_CXX_STD >= 2011)
namespace std {
template <typename... Ts> 
using void_t = typename make_void<Ts...>::type;
}
#endif


#endif // c++17

#endif
