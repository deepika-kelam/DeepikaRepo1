#ifndef CXXOMFORT_IMPL_ALIGNED_STORAGE_HPP
#define CXXOMFORT_IMPL_ALIGNED_STORAGE_HPP
/**
 * @file aligned_storage.hpp
 * @brief Implements std::aligned_storage in C++03 (partial).
 * @author Luis Machuca Bezzaza <luis [dot] machuca [at] gulix [dot] cl>
 *
 */

#include "../config.hpp"

/* For aligned_storage, we can usually do well if we have __alignof() available. 
 * That however is an intrinsic, so it has to be detected on a per-compiler basis.
 * For compilers without __alignof(), we can usually do "well enough" by reserving 
 * [2*sizeof(T)+1] for compound types, and [sizeof(T)] for fundamental types.
 */


namespace cxxomfort {

#if 0

#elif (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC)
    #if (CXXOMFORT_COMPILER_VERSION<=406) // align(N) can only take literals

template <size_t S, size_t A = -1> struct aligned_storage;
#define ALIGNED_STORAGE_ALIGN(N) \
template <size_t S> struct aligned_storage<S, N > { \
    typedef struct { unsigned char __attribute__((aligned( N ))) elem[S]; } type; \
}
ALIGNED_STORAGE_ALIGN(1);
ALIGNED_STORAGE_ALIGN(2);
ALIGNED_STORAGE_ALIGN(4);
ALIGNED_STORAGE_ALIGN(8);
ALIGNED_STORAGE_ALIGN(16);
ALIGNED_STORAGE_ALIGN(32);
ALIGNED_STORAGE_ALIGN(64);
ALIGNED_STORAGE_ALIGN(128);
ALIGNED_STORAGE_ALIGN(256);
#undef ALIGNED_STORAGE_ALIGN
    #define CXXO_DEFINED_ALIGNED_STORAGE

    #else // gcc > 4.6
template <size_t S, size_t A = -1> struct aligned_storage {
    typedef struct { unsigned char __attribute__((aligned(A))) data[S]; }
    type;
};
    #define CXXO_DEFINED_ALIGNED_STORAGE

    #endif // gcc

#elif (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_MSC) // declspec(N) can only take literals

template <size_t S, size_t A = -1> struct aligned_storage;
#define ALIGNED_STORAGE_ALIGN(N) \
template <size_t S> struct aligned_storage<S, N > { \
    typedef struct __declspec(align( N )) { unsigned char elem[S]; } type;  \
}

ALIGNED_STORAGE_ALIGN(1);
ALIGNED_STORAGE_ALIGN(2);
ALIGNED_STORAGE_ALIGN(4);
ALIGNED_STORAGE_ALIGN(8);
ALIGNED_STORAGE_ALIGN(16);
ALIGNED_STORAGE_ALIGN(32);
ALIGNED_STORAGE_ALIGN(64);
#undef ALIGNED_STORAGE_ALIGN
#define CXXO_DEFINED_ALIGNED_STORAGE

#else // unrecognized compiler
#error "Unknown support status for aligned_storage"

#endif // support for aligned_storage

} // cxxomfort


#endif // file
