#ifndef CXXOMFORT_IMPL_STD_BIT_HPP
#define CXXOMFORT_IMPL_STD_BIT_HPP

#include "./base.hpp"
#include CXXO_INCLUDE_SYS(functional)

// fix missing bit_and, bit_or, bit_xor in MSVC 2008
#if (CXXOMFORT_COMPILER_ID == CXXO_VALUE_COMPILER_MSC && CXXOMFORT_COMPILER_VERSION <= 150)

namespace std {

/**
 * @addtogroup functional
 * @{
 */

//! @ref cxx03-backports
template <typename T> struct bit_and {
    T operator() (T const& a, T const& b) const { return a&b; }
};

//! @ref cxx03-backports
template <typename T> struct bit_or {
    T operator() (T const& a, T const& b) const { return a|b; }
};

//! @ref cxx03-backports
template <typename T> struct bit_xor {
    T operator() (T const& a, T const& b) const { return a^b; }
};

} // namespace std

#endif // msvc

#endif
