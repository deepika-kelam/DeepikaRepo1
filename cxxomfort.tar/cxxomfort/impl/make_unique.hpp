#ifndef CXXOMFORT_UTIL_MAKE_UNIQUE_HPP
#define CXXOMFORT_UTIL_MAKE_UNIQUE_HPP

#include "../base.hpp"
#include "../impl/unique_ptr.hpp"

// this is included after unique_ptr

// Add make_unique

namespace std {

#if (CXXOMFORT_CXX_STD >= 2011)

template <typename T, typename ...Args> inline
unique_ptr<T> make_unique (Args&&... args) {
    return std::unique_ptr<T>( new T(std::forward<Args>(args)... ) );
}

#else
template <typename T> inline
unique_ptr<T> make_unique () {
    return unique_ptr<T> (new T());
}
template <typename T, typename A1> inline
unique_ptr<T> make_unique (CXXO_FWD_REF(A1) a1) {
    return unique_ptr<T> (new T( forward<A1>(a1) ));
}
template <typename T, typename A1, typename A2> inline
unique_ptr<T> make_unique (CXXO_FWD_REF(A1) a1, CXXO_FWD_REF(A2) a2) {
    return unique_ptr<T> (new T( forward<A1>(a1), forward<A2>(a2) ));
}
template <typename T, typename A1, typename A2, typename A3> inline
unique_ptr<T> make_unique (CXXO_FWD_REF(A1) a1, CXXO_FWD_REF(A2) a2, CXXO_FWD_REF(A3) a3) {
    return unique_ptr<T> (new T( 
       forward<A1>(a1), forward<A2>(a2), forward<A3>(a3) ));
}
template <typename T, typename A1, typename A2, typename A3, typename A4> inline
unique_ptr<T> make_unique (CXXO_FWD_REF(A1) a1, CXXO_FWD_REF(A2) a2, CXXO_FWD_REF(A3) a3, CXXO_FWD_REF(A4) a4) {
    return unique_ptr<T> (new T(
       forward<A1>(a1), forward<A2>(a2), forward<A3>(a3)
     , forward<A4>(a4) ));
}
template <typename T, typename A1, typename A2, typename A3, typename A4, typename A5> inline
unique_ptr<T> make_unique (CXXO_FWD_REF(A1) a1, CXXO_FWD_REF(A2) a2, CXXO_FWD_REF(A3) a3, CXXO_FWD_REF(A4) a4, CXXO_FWD_REF(A5) a5) {
    return unique_ptr<T> (new T(
      forward<A1>(a1), forward<A2>(a2), forward<A3>(a3), 
      forward<A4>(a4), forward<A5>(a5) ));
}

#endif
}

#endif

