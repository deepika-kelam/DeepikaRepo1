#ifndef CXXOMFORT_IMPL_SEQ_HPP
#define CXXOMFORT_IMPL_SEQ_HPP

// implementation of seq_<T>(), ...

#include <valarray>

namespace cxxomfort {

template <typename Ty>
struct generate_seq_t {
    private:
    struct p_notype;
    
    public:
    std::vector<Ty> elems;
    generate_seq_t () : elems() { }

    generate_seq_t& operator, (Ty const& t) {
        elems.push_back(t);
        return *this;
    }
    
    template <typename Uy>
    generate_seq_t& operator, (Uy y) {
        elems.push_back(static_cast<Ty>(y));
        return *this;
    }

    template <typename Container>
    operator Container () const {
        return Container(std::begin(elems), std::end(elems));
    }
    
    operator std::valarray<Ty> () const {
        return std::valarray<Ty> (&elems[0], elems.size());
    }
    
};

/**
 * @brief Shorthand to generate a sequence of elements of a given type.
 * @ingroup independent-features
 * 
 * Example usage:
 * @code
vector<int> vec = seq_<int>(), 4, 5, 6, 7, 8, 9;
 * @endcode
 */
template <typename Ty>
generate_seq_t<Ty> seq_() {
    return generate_seq_t<Ty>();
}


} // cxxomfort

#endif
