#ifndef CXXOMFORT_IMPL_14_INTEGER_SEQUENCE_HPP
#define CXXOMFORT_IMPL_14_INTEGER_SEQUENCE_HPP
#include <cxxomfort/config.hpp>
#define CXXOMFORT_IMPLEMENTS_n3658 CXXO_BACKPORT()

#if (CXXOMFORT_CXX_STD >= 2014)
    // nothing to do
#else
// room here for a possible c++03 implementation? I wish.
#if (CXXOMFORT_CXX_STD < 2011)


#elif (CXXOMFORT_CXX_STD == 2011 || (CXXOMFORT_CXX_EMULATION==2011 && CXXO_COMPILER_SUPPORT_variadic))

namespace cxxomfort {

/**
 * @ingroup utility
 * @{
 */
template <typename T, T... Elems>
struct integer_sequence {
    typedef T type;
    static const size_t size= sizeof...(Elems);
}; 

template <typename T, size_t N, size_t ...Is>
struct make_integer_sequence 
: make_integer_sequence<T, N-1, N-1, Is...> {};

template <typename T, size_t ...Is>
struct make_integer_sequence<T, 0, Is...>
: integer_sequence<T, Is...> {};

template <size_t... Is>
struct index_sequence
: integer_sequence<size_t, Is...> {};

template <size_t N, size_t ...Is>
struct make_index_sequence
: make_index_sequence<N-1,N-1,Is...> {};

template <size_t ...Is>
struct make_index_sequence<0, Is...>
: index_sequence<Is...> {};

template <typename ...Types>
struct index_sequence_for 
: make_index_sequence<sizeof...(Types)> {};

# if 0
// https://gist.github.com/sahchandler/8d13f0935a0511af8d1d/520903a0b187a87be66cf99977126cc4db4e431a

//! integer_sequence
template <typename T, T... I> 
struct integer_sequence {
    template <T N> struct append : integer_sequence<T, I..., N> {};
    static CXXO_CONSTEXPR std::size_t size () { return sizeof...(I); }
    static const size_t _size;
    typedef append<_size> next;
    typedef T type;
}; 

template <typename T, T... I>
const size_t integer_sequence<T,I...>::_size= sizeof...(I);

template <typename T, T Index, size_t N>
struct sequence_generator {
    struct type : sequence_generator<T, Index - 1, N - 1>::type::next {};
}; 

template <class T, T Index>
struct sequence_generator<T, Index, 0ul> { 
    struct type : integer_sequence<T> {}; 
};  

template <std::size_t... I>
struct index_sequence : integer_sequence<std::size_t, I...> {};
 
template <class T, T N>
struct make_integer_sequence : sequence_generator<T, N, N>::type {};
 
template <std::size_t N>
struct make_index_sequence : make_integer_sequence<std::size_t, N> {}; 

#endif

/**
 * @}
 */

} // cxxomfort::


namespace std {
    using cxxomfort::integer_sequence;
    using cxxomfort::index_sequence;
    using cxxomfort::make_integer_sequence;
    using cxxomfort::make_index_sequence;

} // namespace std

#endif // c++11

#endif // support
#endif


