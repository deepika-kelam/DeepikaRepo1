#ifndef CXXOMFORT_IMPL_FUNCTIONAL_14FUNCTORS_HPP
#define CXXOMFORT_IMPL_FUNCTIONAL_14FUNCTORS_HPP
/**
 * @file impl/14-functors.hpp
 * @brief Partial implementation of N3421 "Easier <functional> syntax" aka: Transparent Functors
 * 
 * @see http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2012/n3421.htm
 * @see http://stackoverflow.com/questions/17737132/transparent-operator-functors
 * 
 * This header should be included @b after <functional> has been included.
 * 
 * Interfaces exported in this header:
 * 
 * * @c std::less<void>
 * * @c std::greater<void>
 * * @c std::less_equal<void>
 * * @c std::greater_equal<void>
 * * @c std::equal_to<void>
 * * @c std::not_equal_to<void>
 * * @c std::bit_and<void>
 * * @c std::bit_or<void>
 * * @c std::bit_xor<void>
 * 
 */


#include <cxxomfort/config.hpp>
#define CXXOMFORT_IMPLEMENTS_n3431 CXXO_BACKPORT()

#include CXXO_INCLUDE_SYS(functional)
// <functional> needs to be #included for this to make any sense
#if defined(CXXOMFORT_NOTICES) && (CXXOMFORT_NOTICES > 1)
#pragma message CXXO_NOTICE("enabled <functional> transparent functors")
#endif

#include <type_traits> // common_type
#include "../type_traits.hpp"
#include "../util/traits_ct.hpp"

namespace cxxomfort {
namespace functional {

/**
 * @addtogroup functional
 * @{
 */
template <typename T = void> struct less 
: std::less<T> {};
template <typename T = void> struct greater 
: std::greater<T> {};
template <typename T = void> struct less_equal 
: std::less_equal<T> {};
template <typename T = void> struct greater_equal 
: std::greater_equal<T> {};
template <typename T = void> struct equal_to 
: std::equal_to<T> {};
template <typename T = void> struct not_equal_to 
: std::not_equal_to<T> {};

#define LPP_SPEC_FUNCTIONAL_VOID(Op,Sym) \
/**   \
 * @brief Transparent functor for '@c Op ', to be used as <code>Op<void></code>. \
 *  \
 * These operators permit transparent (not type-dependent) comparators \
 * to be used in the contexts where eg.: <code>std::less</code> is expected. \
 *  \
 * @ref cxx03-backports   \
 * @ref cxx11-backports   \
 */   \
template <> struct Op <void> :  \
std::Op <int> { \
    typedef bool result_type; \
    template <typename T, typename U> \
    inline bool operator() (T const& t, U const& u) const { return t Sym u; } \
}; \

LPP_SPEC_FUNCTIONAL_VOID(less,<);
LPP_SPEC_FUNCTIONAL_VOID(less_equal,<=);
LPP_SPEC_FUNCTIONAL_VOID(greater,>);
LPP_SPEC_FUNCTIONAL_VOID(greater_equal,>=);
LPP_SPEC_FUNCTIONAL_VOID(equal_to,==);
LPP_SPEC_FUNCTIONAL_VOID(not_equal_to,!=);

#undef LPP_SPEC_FUNCTIONAL_VOID

template <typename T = void> struct bit_and 
: std::bit_and<T> {};
template <typename T = void> struct bit_or 
: std::bit_or<T> {};
template <typename T = void> struct bit_xor 
: std::bit_xor<T> {};
// this was missing from the original STL
template <typename T = void> struct bit_not {
    typedef T result_type;
    typedef T argument_type;
    inline T operator() (T const& t) const { return ~t; }
};

template <typename T = void> struct plus 
: std::plus<T> {};
template <typename T = void> struct minus 
: std::minus<T> {};
template <typename T = void> struct multiplies 
: std::multiplies<T> {};
template <typename T = void> struct divides 
: std::divides<T> {};
template <typename T = void> struct modulus 
: std::modulus<T> {};


#if (CXXOMFORT_CXX_STD < 2011)

// Under C++03, one can not trust that std::common_type is available 
// (because no decltype), so we assume that heterogeneous functors 
// return homogeneously to the left (aka: they return the type of 1st operand).

    #define LPP_SPEC_FUNCTIONAL_VOID(Op,Sym) \
template<> struct Op <void> :   \
std:: Op< int> {    \
    template <typename T1, typename T2>     \
    inline typename \
    std::remove_reference<T1>::type operator() (T1 const& a, T2 const& b) const { return a Sym b; } \
    template <typename T> struct result { typedef T type; }; \
    static const bool is_transparent = true;  \
}; \
template <typename T1, typename T2> struct Op<void>:: result< Op<void>(T1,T2) > { \
    typedef T1 type; \
}; \


#else

    #define LPP_SPEC_FUNCTIONAL_VOID(Op,Sym) \
template<> struct Op <void> { \
    template <typename T1, typename T2>  \
    decltype( std::declval<T1>() Sym std::declval<T2>()  )  \
    operator() (T1 const& a, T2 const& b) const { return a Sym b; }  \
    template <typename T> struct result { typedef void type; };  \
    static const bool is_transparent = true;  \
}; \
template <typename T1, typename T2> struct Op<void>:: result< Op<void>(T1,T2) > { \
    typedef typename std::common_type<T1,T2>::type type; \
}; \

#endif

LPP_SPEC_FUNCTIONAL_VOID(bit_and,&);
LPP_SPEC_FUNCTIONAL_VOID(bit_or,|);
LPP_SPEC_FUNCTIONAL_VOID(bit_xor,^);

LPP_SPEC_FUNCTIONAL_VOID(plus,+);
LPP_SPEC_FUNCTIONAL_VOID(minus,-);
LPP_SPEC_FUNCTIONAL_VOID(multiplies,*);
LPP_SPEC_FUNCTIONAL_VOID(divides,/);
LPP_SPEC_FUNCTIONAL_VOID(modulus,%);

template<> struct bit_not<void> {
    template <typename T>
    inline T operator() (T const& t) const { return ~t; }
};

#undef LPP_SPEC_FUNCTIONAL_VOID


/**
 * @}
 */

} //cxxomfort::extras
} //cxxomfort

/*
 * Transparent functors were established in C++14
 */
#if (CXXOMFORT_CXX_STD < 2014)
namespace std {
    //! Transparent @em equal_to functor.
    template<> struct equal_to<void>  : ::cxxomfort::functional::equal_to<void> {}; ///< transparent specialization for @c std::equal_to
    //! Transparent @em not_equal_to functor.
    template<> struct not_equal_to<void>  : ::cxxomfort::functional::not_equal_to<void> {};
    //! Transparent @em less functor.
    template<> struct less<void>      : ::cxxomfort::functional::less<void> {};
    //! Transparent @em greater functor.
    template<> struct greater<void>   : ::cxxomfort::functional::greater<void> {};
    //! Transparent @em less_equal functor.
    template<> struct less_equal<void>    : ::cxxomfort::functional::less_equal<void> {};
    //! Transparent @em greater_equal functor.
    template<> struct greater_equal<void> : ::cxxomfort::functional::greater_equal<void> {};
    //! Transparent @em bit_or functor.
    template<> struct bit_or<void>    : ::cxxomfort::functional::bit_or<void> {};
    //! Transparent @em bit_and functor.
    template<> struct bit_and<void>   : ::cxxomfort::functional::bit_and<void> {};
    //! Transparent @em bit_xor functor.
    template<> struct bit_xor<void>   : ::cxxomfort::functional::bit_xor<void> {};

    template<> struct plus<void>   : ::cxxomfort::functional::plus<void> {};
    template<> struct minus<void>   : ::cxxomfort::functional::minus<void> {};
    template<> struct multiplies<void>   : ::cxxomfort::functional::multiplies<void> {};
    template<> struct divides<void>   : ::cxxomfort::functional::divides<void> {};
    template<> struct modulus<void>   : ::cxxomfort::functional::modulus<void> {};


    
    
}
#endif // c++14

#endif // CXXOMFORT_EXTRAS_14FUNCTORS_HPP

