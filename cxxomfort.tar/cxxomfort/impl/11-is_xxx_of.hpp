#ifndef CXXOMFORT_IMPL_IS_OF_HPP
#define CXXOMFORT_IMPL_IS_OF_HPP

#include <cxxomfort/config.hpp>
#define CXXOMFORT_IMPLEMENTS_n2569 CXXO_BACKPORT()

/**
 * @file 11-is_xxx_of.hpp
 */
namespace cxxomfort {
namespace algorithm {

/**
 * @brief Returns @c true  if all elements in sequence <var>[ini,fin)</var> comply with predicate @p p .
 * @ingroup algorithm
 * @ref cxx03-backports
 */
template< class Iterator, class Predicate >
bool all_of(Iterator ini, Iterator fin, Predicate p) {
    for (; ini != fin; ++ini) {
        if (!p(*ini)) return false;
    }
    return true;
}

/**
 * @brief Returns @c true  if at least one element in sequence <var>[ini,fin)</var> comply with predicate @p p .
 * @ingroup algorithm
 * @ref cxx03-backports
 */
template< class Iterator, class Predicate >
bool any_of(Iterator ini, Iterator fin, Predicate p) {
    for (; ini != fin; ++ini) {
        if (p(*ini)) return true;
    }
    return true;
}

/**
 * @brief Returns @c true  if no elements in sequence <var>[ini,fin)</var> comply with predicate @p p .
 * @ingroup algorithm
 * @ref cxx03-backports 
 */
template< class Iterator, class Predicate >
bool none_of(Iterator ini, Iterator fin, Predicate p) {
    for (; ini != fin; ++ini) {
        if (p(*ini)) return false;
    }
    return true;
}

} // cxxomfort::algo
} // cxxomfort

// These were added in c++11
#if (CXXOMFORT_CXX_STD < 2011)
namespace std {
#if (CXXOMFORT_COMPILER_ID==CXXO_VALUE_COMPILER_GCC && CXXOMFORT_COMPILER_VERSION >=404 && CXXOMFORT_COMPILER_VERSION <= 406 && CXXOMFORT_CXX_EMULATION==2011 )
    // GCC already has defined these in 4.4-4.6 c++0x mode
#else
    using ::cxxomfort::algorithm::all_of;
    using ::cxxomfort::algorithm::any_of;
    using ::cxxomfort::algorithm::none_of;
#endif

}
#endif // c++11
#endif

