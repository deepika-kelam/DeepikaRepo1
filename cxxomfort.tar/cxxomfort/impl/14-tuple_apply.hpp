#ifndef CXXOMFORT_IMPL_TUPLEAPPLY_HPP
#define CXXOMFORT_IMPL_TUPLEAPPLY_HPP
/*
 * Support for applying a tuple as arguments to a function
 * (C++14 proposals n3829 and n3915)
 * http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2014/n3829.pdf
 * 
 * Interfaces defined in this header:
 * 
 * * std::apply (function_type, tuple<...>)
 * 
 */

#if (defined(CXXOMFORT_NOTICES))
    #pragma message CXXO_NOTICE("enabled tuple apply(fn,tuple) implementation")
#endif

#include <cxxomfort/base.hpp>
#include <cxxomfort/utility.hpp> // index_sequence
#include <cxxomfort/various.hpp> // is_tuple
#include <tuple> // ...duh

namespace cxxomfort {
namespace tuple {


//
// tuple_apply
// (call a function using an unpacked tuple as arguments)
//

#if (CXXOMFORT_CXX_STD >= 2011) || \
    (CXXOMFORT_CXX_EMULATION == 2011 && CXXO_EMULATION_rvref && CXXO_EMULATION_variadic)

// http://stackoverflow.com/questions/687490/how-do-i-expand-a-tuple-into-variadic-template-functions-arguments/12650100#12650100

//
// tuple unpack
// (solution presented in n3658 "Integer Sequences")
//
template<typename F, typename Tuple, size_t... I>
  auto
  apply_(F&& f, Tuple&& args, std::index_sequence<I...>)
  -> decltype(std::forward<F>(f)(std::get<I>(std::forward<Tuple>(args))...))
  {
    return std::forward<F>(f)(std::get<I>(std::forward<Tuple>(args))...);
  }

template<typename F, typename Tuple,
    typename Dec= typename std::decay<Tuple>::type, 
    typename Indices = std::make_index_sequence<std::tuple_size<Dec>::value>>
  auto
  apply(F&& f, Tuple&& args)
  -> decltype(apply_(std::forward<F>(f), std::forward<Tuple>(args), Indices()))
  {
    return apply_(std::forward<F>(f), std::forward<Tuple>(args), Indices());
  }


#else
//implementation for c++03 for up to 10 elements

template <typename Sig> struct FnReturnType { typedef typename Sig::result_type type; };
template <typename R, typename A0> struct FnReturnType<R(A0)> {
    typedef R type;
};
template <typename R, typename A0> struct FnReturnType<R(*)(A0)> {
    typedef R type;
};
template <typename R, typename A0, typename A1> struct FnReturnType<R(A0,A1)> 
: FnReturnType<R(A0)> {};
template <typename R, typename A0, typename A1> struct FnReturnType<R(*)(A0,A1)> 
: FnReturnType<R(A0)> {};

template <typename R, typename A0, typename A1, typename A2> struct FnReturnType<R(A0,A1,A2)> 
: FnReturnType<R(A0)> {};
template <typename R, typename A0, typename A1, typename A2> struct FnReturnType<R(*)(A0,A1,A2)> 
: FnReturnType<R(A0)> {};

template <typename R, typename A0, typename A1, typename A2
    , typename A3> struct FnReturnType<R(A0,A1,A2,A3)> 
: FnReturnType<R(A0)> {};
template <typename R, typename A0, typename A1, typename A2
    , typename A3> struct FnReturnType<R(*)(A0,A1,A2,A3)> 
: FnReturnType<R(A0)> {};

template <typename R, typename A0, typename A1, typename A2
    , typename A3, typename A4> 
struct FnReturnType<R(A0,A1,A2,A3,A4)> 
: FnReturnType<R(A0)> {};
template <typename R, typename A0, typename A1, typename A2
    , typename A3, typename A4> 
struct FnReturnType<R(*)(A0,A1,A2,A3,A4)> 
: FnReturnType<R(A0)> {};

template <typename R, typename A0, typename A1, typename A2
    , typename A3, typename A4, typename A5> 
struct FnReturnType<R(A0,A1,A2,A3,A4,A5)> 
: FnReturnType<R(A0)> {};
template <typename R, typename A0, typename A1, typename A2
    , typename A3, typename A4, typename A5> 
struct FnReturnType<R(*)(A0,A1,A2,A3,A4,A5)> 
: FnReturnType<R(A0)> {};


template <typename R, typename A0, typename A1, typename A2
    , typename A3, typename A4, typename A5> 
struct FnReturnType<R(A0,A1,A2,A3,A4,A5,...)> 
: FnReturnType<R(A0)> {};
template <typename R, typename A0, typename A1, typename A2
    , typename A3, typename A4, typename A5> 
struct FnReturnType<R(*)(A0,A1,A2,A3,A4,A5,...)> 
: FnReturnType<R(A0)> {};



template <typename F, typename Tuple, unsigned int S= std::tuple_size< typename std::remove_cv<Tuple>::type>::value> 
struct call_impl {
};

#define GET_(x) get<x>(t)

template <typename F, typename Tuple> struct call_impl<F, Tuple,1> {
    static void call (F& f, Tuple& t) {
        using std::get;
        f(GET_(0));
    }
};

template <typename F, typename Tuple> struct call_impl<F,Tuple,2> {
    template <typename R>
    static R call (F& f, Tuple& t) {
        using std::get;
        return f(GET_(0), GET_(1));
    }
};

template <typename F, typename Tuple> struct call_impl<F,Tuple,3> {
    template <typename R> static R call (F& f, Tuple& t) {
        using std::get;
        return f(GET_(0), GET_(1), GET_(2));
    }
};

template <typename F, typename Tuple> struct call_impl<F,Tuple,4> {
    template <typename R> static R call (F& f, Tuple& t) {
        using std::get;
        return f(GET_(0), GET_(1), GET_(2), GET_(3));
    }
};

template <typename F, typename Tuple> struct call_impl<F,Tuple,5> {
    template <typename R>
    static R call (F& f, Tuple& t) {
        using std::get;
        return f(GET_(0), GET_(1), GET_(2), GET_(3), GET_(4));
    }
};

template <typename F, typename Tuple> struct call_impl<F,Tuple,6> {
    template <typename R>
    static R call (F& f, Tuple& t) {
        using std::get;
        return f(GET_(0), GET_(1), GET_(2), GET_(3), GET_(4), GET_(5));
    }
};

template <typename F, typename Tuple> struct call_impl<F,Tuple,7> {
    template <typename R>
    static R call (F& f, Tuple& t) {
        using std::get;
        return f(GET_(0), GET_(1), GET_(2), GET_(3), GET_(4), GET_(5), GET_(6));
    }
};

template <typename F, typename Tuple> struct call_impl<F,Tuple,8> {
    template <typename R>
    static R call (F& f, Tuple& t) {
        using std::get;
        return f(GET_(0), GET_(1), GET_(2), GET_(3), GET_(4), GET_(5), GET_(6), GET_(7));
    }
};

template <typename F, typename Tuple> struct call_impl<F,Tuple,9> {
    template <typename R>
    static R call (F& f, Tuple& t) {
        using std::get;
        return f(GET_(0), GET_(1), GET_(2), GET_(3), GET_(4), GET_(5), GET_(6), GET_(7), GET_(8));
    }
};

template <typename F, typename Tuple> struct call_impl<F,Tuple,10> {
    template <typename R>
    static R call (F& f, Tuple& t) {
        using std::get;
        return f(GET_(0), GET_(1), GET_(2), GET_(3), GET_(4), GET_(5), GET_(6), GET_(7), GET_(8), GET_(9));
    }
};

#undef GET_

template <typename F, typename Tuple>
typename FnReturnType<F>::type
apply (F f, Tuple& t) {
    //typedef typename FnReturnType< typename std::remove_pointer<F>::type >::type ret_type;
    typedef typename FnReturnType<F>::type R;
    //std::cerr<< "[call (Tuple const&) [return_type= "<< cxxomfort::typeid_demangle(typeid(ret_type))<< "] ]"<< std::endl;
    //std::cerr<< "[call (Tuple const&) [Tuple="<< cxxomfort::typeid_demangle(typeid(Tuple))<< "] ]"<< std::endl;
    return call_impl<F,Tuple>::template call<R>( f, t );
}

template <typename F, typename Tuple>
typename FnReturnType<F>::type
apply (F f, Tuple const& t) {
    typedef typename FnReturnType<F>::type R;
    return call_impl<F,Tuple const>::template call<R>( f, t );
}



#endif

//
// tuple_visit
// (apply a function to all members of a tuple)
//

#if 0
template <typename F, typename Tuple, int I= 0, int S = std::tuple_size< typename std::remove_const<Tuple>::type >::value>
struct tuple_apply_t {
    static_assert (cxxomfort::is_tuple<Tuple>::value, "tuple_apply: passed type must be a tuple<...>");
    public:
    //typedef typename F::result_type result_type;
    tuple_apply_t (F& f, Tuple& t) : _f(f), _tuple(t) {
        using std::get;
        _f (get<I>(_tuple));
        tuple_apply_t<F,Tuple,I+1,S>(_f,_tuple);
    }

    private:
    F& _f;
    Tuple& _tuple;
    tuple_apply_t& operator= (tuple_apply_t const&);
};

template <typename F, typename Tuple, int S>
struct tuple_apply_t<F,Tuple,S,S> {
    public:
    //typedef typename F::result_type result_type;
    tuple_apply_t (F const&, Tuple const&) {
        // intentionally empty
    }

    private:
    tuple_apply_t& operator= (tuple_apply_t const&);
};

//! apply function @p f  to all members of tuple @p t .
template <typename F, typename Tuple> inline 
Tuple& apply (F f, Tuple& t) {
    tuple_apply_t<F,Tuple>(f,t);
    return t;
}
#endif




} //detail_tuple::
}

namespace std {
    using cxxomfort::tuple::apply;
}



#endif
