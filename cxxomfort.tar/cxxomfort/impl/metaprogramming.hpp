#ifndef CXXOMFORT_IMPL_11METAPROGRAMMING_HPP
#define CXXOMFORT_IMPL_11METAPROGRAMMING_HPP

#include <cxxomfort/base.hpp>

#if (CXXOMFORT_CXX_STD < 2011)
namespace cxxomfort {


}
#endif // c++03 mode

#endif
