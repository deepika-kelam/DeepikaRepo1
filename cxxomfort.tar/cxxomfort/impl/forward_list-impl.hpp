#ifndef CXXOMFORT_IMPL_FORWARD_LIST_IMPL_HPP
#define CXXOMFORT_IMPL_FORWARD_LIST_IMPL_HPP

#include "../config.hpp"
#include <stdexcept>
#include <iterator>
#include <utility>
#include <memory>
#include <functional>
#include <algorithm>
#include <stdexcept>
#include <cassert>
#include <new>


#define LDEBUG(msg) if (!LDEBUG_ENABLED) {} \
                   else std::cerr << "[forward_list::"<< msg<< " ]"<< std::endl;
#ifndef LDEBUG_ENABLED
    #define LDEBUG_ENABLED 0
#endif

namespace cxxomfort {
namespace detail_fwlist {


template <typename T> struct sl_node
: public sl_node_base {
    T value;
    sl_node (sl_node_base const& p) : sl_node_base(p), value() {}
    T const& operator* () const { return value; }
};

template <typename T> inline
bool operator< (sl_node<T> const& a, sl_node<T> const& b) {
    return a.value < b.value;
}

/*
 *  Tipo base para un iterador de una lista enlazada simple
 */
template <typename T, bool Constness>
class iterator_base
: public std::iterator< std::forward_iterator_tag, T > {
    public:
    friend class forward_list<T>;
    //typedef std::forward_iterator_tag iterator_category;
    typedef T value_type;
    typedef typename std::conditional<Constness, T const&, T&>::type reference;
    typedef typename std::conditional<Constness, T const*, T*>::type pointer;
    typedef typename std::conditional<Constness, /*const*/ sl_node_base *, sl_node_base*>::type nodeptr;
    
    iterator_base (nodeptr x, const nodeptr* s) : cur(x), src(s) {}
    reference       operator*() const { return static_cast<sl_node<T>*>(cur)->value; }
    pointer         operator->() const { return static_cast<sl_node<T>*>(cur)->value; }
    iterator_base&  operator++ () { 
        if (cur) { cur= (nodeptr)(cur->next); }
        return *this; 
    }
    iterator_base   operator++ (int) { iterator_base t(*this); ++*this; return t; }
    operator iterator_base<T, true> () { return iterator_base<T,true>(cur,src); }
    
    friend bool operator== (iterator_base const& a, iterator_base const& b) {
        return a.cur == b.cur;
    }
    friend bool operator!= (iterator_base const& a, iterator_base const& b) {
        return !(a==b);
    }
    
private:
    nodeptr cur;
    const nodeptr* src;
};


// this is not exposed
template <typename A> 
typename A::pointer alloc_new (A& a) {
    return a.allocate(1);
}

template <typename T, typename C>
sl_node<T>* points_to_max(sl_node<T>* ini, sl_node<T>* fin) {
    while (ini != fin) {
        ++ini;
    }
}

} // end namespace


// default constructor
template <typename T, typename A>
forward_list<T,A>::forward_list ()
: _p_bb(nullptr), _p_last(nullptr),  alloc(A())  {
}

template <typename T, typename A>
forward_list<T,A>::forward_list (forward_list<T,A> const& l) 
: _p_bb(nullptr), _p_last(nullptr), alloc(l.alloc) {
    if (l.empty()) return;
    this->in_uninitialized_copy(l.begin(), l.end());
}

template <typename T, typename A>
forward_list<T,A>::forward_list (size_t count, T const& t, A const& a)
: alloc(a), _p_bb(nullptr), _p_last(nullptr) {
    this->in_uninitialized_fill_n(count, t);
}

template <typename T, typename A>
template <typename I>
forward_list<T,A>::forward_list (I ini, I fin, A const& a)
: alloc(a), _p_bb(nullptr), _p_last(nullptr) {
    if (ini==fin) return;
    this->in_uninitialized_copy(ini,fin);    
}

// move constructor
template <typename T, typename A>
forward_list<T,A>::forward_list (CXXO_RV_REF(forward_list) p) 
: alloc (std::move(p.alloc)), _p_bb(p._p_bb), _p_last(p._p_last) {
    // relink the list's nodes to this _head
    p._p_last.next = 0;
    p._p_bb= 0;
}

template <typename T, typename A>
forward_list<T,A>::~forward_list () {
    this->clear();
    _p_last=0;
}

// copy assignment
template <typename T, typename A>
forward_list<T,A>& forward_list<T,A>::operator= (CXXO_COPY_ASSIGN_REF(forward_list) p) {
    LDEBUG("copy assignment - called");
    this->clear();
    this->in_uninitialized_copy(p.begin(), p.end());
    LDEBUG("copy assignment - done");
    return *this;
}

// move assignment
template <typename T, typename A>
forward_list<T,A>& forward_list<T,A>::operator= (CXXO_RV_REF(forward_list) p) {
    LDEBUG("move assignment - called");
    this->clear();
    LDEBUG("move assignment - done clearing");
    this->_p_bb.next= p._p_bb.next;
    this->_p_last= std::move(p._p_last);
    this->alloc= std::move(p.alloc);

    p._p_last= 0;
    p._p_bb= 0;
    LDEBUG("move assignment - done");
    return *this;
}

// assign n elements of value v
template <typename T, typename A>
void forward_list<T,A>::assign (size_type n, T const& v) {
    LDEBUG("assign(n,v) - called");
    forward_list newlist(n,v);
    this->swap(newlist);
    LDEBUG("assign - done");
}

// assign elements from a range
template <typename T, typename A>
template <typename Iterator>
void forward_list<T,A>::assign (Iterator ini, Iterator fin) {
    LDEBUG("assign(begin,end) - called");
    forward_list newlist(ini,fin);
    this->swap(newlist);
    LDEBUG("assign - do");
}


template <typename T, typename A>
bool forward_list<T,A>::empty () const {
    return ( _p_bb.next==nullptr );
}

template <typename T, typename A>
typename forward_list<T,A>::size_type forward_list<T,A>::max_size () const {
    return alloc_traits::max_size(alloc);
}

template <typename T, typename A>
typename forward_list<T,A>::const_iterator forward_list<T,A>::cbegin () const CXXO_NOEXCEPT {
    return const_iterator(_p_bb.next, &_p_last);
}

template <typename T, typename A>
typename forward_list<T,A>::iterator forward_list<T,A>::begin () CXXO_NOEXCEPT {
    return iterator(_p_bb.next, &_p_last);
}

template <typename T, typename A>
typename forward_list<T,A>::const_iterator forward_list<T,A>::cend () const CXXO_NOEXCEPT {
    return const_iterator(nullptr, &_p_last);
}

template <typename T, typename A>
typename forward_list<T,A>::iterator forward_list<T,A>::end () CXXO_NOEXCEPT {
    return iterator (nullptr, &_p_last);
}

template <typename T, typename A>
typename forward_list<T,A>::const_reference forward_list<T,A>::front () const {
    return *cbegin();
}


template <typename T, typename A>
typename forward_list<T,A>::reference forward_list<T,A>::front () {
    return *begin();
}


template <typename T, typename A>
typename forward_list<T,A>::const_iterator forward_list<T,A>::before_begin () const {
    return const_iterator(&_p_bb, &_p_last);
}


template <typename T, typename A>
typename forward_list<T,A>::iterator forward_list<T,A>::before_begin () {
    return iterator(&_p_bb, &_p_last);
}


//
// Add elements by the front
//

/*
 * List is p_bb -> i1 -> ... -> null
 * List becomes p_bb -> t -> i1 -> ... -> null
 * 
 * If list is p_bb -> null
 * List becomes p_bb -> t -> null
 */
template <typename T, typename A>
void forward_list<T,A>::push_front (T const& t) {
    LDEBUG("push_front - called");
    using namespace std;
    //LDEBUG("push_front - allocating and constructing");
    nodeT_t *n = alloc_traits::allocate(alloc,1);
    ::new (&n->value) T(t);
    // if list is empty, we have to update link to last
    if (empty()) _p_last= n;
    this->in_link_after(&_p_bb,n);
    this->_p_bb.next= n;
    LDEBUG("push_front - next -> "<< (void*)_p_bb.next<< " .");
    LDEBUG("push_front - ended H:"<< (void*)this);
}

template <typename T, typename A>
void forward_list<T,A>::push_front (CXXO_RV_REF(T) mv) {

    using namespace std;
    LDEBUG("push_front - allocating and constructing");
    nodeT_t *n = alloc_traits::allocate(alloc,1);
    ::new (&n->value) T( std::move(mv) );
    // if list is empty, we have to update link to last
    if (empty()) _p_last= n;
    this->in_link_after(&_p_bb,n);
    this->_p_bb.next= n;

    LDEBUG("push_front - ended H:"<< (void*)this);
}

#if 0
//
// Add elements to the back
// needs to update link to last
//

template <typename T, typename A>
void forward_list<T,A>::push_back (T const& t) {
    LDEBUG("push_back - called");
    using namespace std;
    if (empty()) {
    LDEBUG("push_back - first element");
        push_front(t);
    } else {
        nodeT_t *n= detail_fwlist::alloc_new(alloc);
        ::new (&n->value) T(t);
        // insert after _end; this will update _end
        this->in_link_after(_p_last,U(n));
    }
    //LDEBUG("push_front - ended H&"<< std::addressof(_head));
}

template <typename T, typename A>
void forward_list<T,A>::push_back (CXXO_RV_REF(T) mv) {
    LDEBUG("push_back (move) - called");
    using namespace std;
    if (empty()) {
    LDEBUG("push_back (move) - first elem");
        this->push_front(mv);
    } else {
        nodeT_t *n= detail_fwlist::alloc_new(alloc);
        ::new (&n->value) T(std::move(mv));
        // insert after _end; this will update _end
        this->in_link_after(_p_last,U(n));
    }
    //LDEBUG("push_front - ended H&"<< std::addressof(_head));
}

#endif

//
// Remove element from the front
//

/*
 * List is p_bb -> i0 -> i1 -> ... -> null
 * List becomes p_bb -> i1 -> ... -> null
 */

template <typename T, typename A>
void forward_list<T,A>::pop_front () {
    //allocator_type C;
    using namespace std;
    if (empty()) return;
    // unlink the element
    // at this stage, _p_last points to the last element and _p_last->next is the first
    
    node_t* f = _p_bb.next;
    //LDEBUG("pop_front - removing node at next -> "<< (void*)f<< " .");
    _p_bb.next= (f ? f->next : nullptr);
    // we might need to update pointer to last if what we removed was the last element
    if (!_p_bb.next) _p_last= nullptr;

    this->in_destroy(N(f));
}


//
// emplace family of functions
//


#if (CXXOMFORT_CXX_STD >= 2011)
template <typename T, typename A>
template <typename... Args>
void forward_list<T,A>::emplace_front (Args&&... args) {
    using namespace std;
    nodeT_t *n = alloc_traits::allocate(alloc,1);
    ::new (&n->value) T(args...);
    this->in_link_after(&_p_bb,n);
    this->_p_bb.next= n;
}

#else
template <typename T, typename A>
void forward_list<T,A>::emplace_front () {
    using namespace std;
    nodeT_t *n = alloc_traits::allocate(alloc,1);
    ::new (&n->value) T();
    this->in_link_after(&_p_bb,n);
    this->_p_bb.next= n;
}

template <typename T, typename A>
template <typename Arg1>
void forward_list<T,A>::emplace_front (Arg1 a1) {
    using namespace std;
    nodeT_t *n = alloc_traits::allocate(alloc,1);
    ::new (&n->value) T(a1);
    this->in_link_after(&_p_bb,n);
    this->_p_bb.next= n;
}

template <typename T, typename A>
template <typename Arg1, typename Arg2>
void forward_list<T,A>::emplace_front (Arg1 a1, Arg2 a2) {
    using namespace std;
    nodeT_t *n = alloc_traits::allocate(alloc,1);
    ::new (&n->value) T(a1,a2);
    this->in_link_after(&_p_bb,n);
    this->_p_bb.next= n;
}

template <typename T, typename A>
template <typename Arg1, typename Arg2, typename Arg3>
void forward_list<T,A>::emplace_front (Arg1 a1, Arg2 a2, Arg3 a3) {
    using namespace std;
    nodeT_t *n = alloc_traits::allocate(alloc,1);
    ::new (&n->value) T(a1,a2,a3);
    this->in_link_after(&_p_bb,n);
    this->_p_bb.next= n;
}

template <typename T, typename A>
template <typename Arg1, typename Arg2, typename Arg3, typename Arg4>
void forward_list<T,A>::emplace_front (Arg1 a1, Arg2 a2, Arg3 a3, Arg4 a4) {
    using namespace std;
    nodeT_t *n = alloc_traits::allocate(alloc,1);
    ::new (&n->value) T(a1,a2,a3,a4);
    this->in_link_after(&_p_bb,n);
    this->_p_bb.next= n;
}

template <typename T, typename A>
template <typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5>
void forward_list<T,A>::emplace_front (Arg1 a1, Arg2 a2, Arg3 a3, Arg4 a4, Arg5 a5) {
    using namespace std;
    nodeT_t *n = alloc_traits::allocate(alloc,1);
    ::new (&n->value) T(a1,a2,a3,a4,a5);
    this->in_link_after(&_p_bb,n);
    this->_p_bb.next= n;
}


#endif

#if (CXXOMFORT_CXX_STD < 2011)
#if 0
template <typename T, typename A>
template <typename Arg1>
typename forward_list<T,A>::iterator forward_list<T,A>::emplace_after (const_iterator pos
, CXXO_FWD_REF(Arg1) a1) {
    node_t *p = pos.cur;
    //assert (p != &_head && "list::insert_after can not use _head node");
    nodeT_t *n= std::allocator_traits<node_alloc_t>::allocate(alloc,1) /*new nodeT_t(t)*/;
    ::new (&n->value) T(a1);
    this->in_link_after(p, n);
    return iterator(n);
}

template <typename T, typename A>
template <typename Arg1, typename Arg2>
typename forward_list<T,A>::iterator forward_list<T,A>::emplace_after (const_iterator pos
, CXXO_FWD_REF(Arg1) a1, CXXO_FWD_REF(Arg2) a2) {
    node_t * p = pos.cur;
    //assert (p != &_head && "list::insert_after can not use _head node");
    nodeT_t *n= std::allocator_traits<node_alloc_t>::allocate(alloc,1) /*new nodeT_t(t)*/;
    ::new (&n->value) T(a1,a2);
    this->in_link_after(p, n);
    return iterator(n);
}

template <typename T, typename A>
template <typename Arg1, typename Arg2, typename Arg3>
typename forward_list<T,A>::iterator forward_list<T,A>::emplace_after (const_iterator pos
, CXXO_FWD_REF(Arg1) a1, CXXO_FWD_REF(Arg2) a2, CXXO_FWD_REF(Arg3) a3) {
    node_t *p = pos.cur;
    //assert (p != &_head && "list::insert_after can not use _head node");
    nodeT_t *n= std::allocator_traits<node_alloc_t>::allocate(alloc,1) /*new nodeT_t(t)*/;
    ::new (&n->value) T(a1,a2,a3);
    this->in_link_after(p, n);
    return iterator(n);
}

template <typename T, typename A>
template <typename Arg1, typename Arg2, typename Arg3, typename Arg4>
typename forward_list<T,A>::iterator forward_list<T,A>::emplace_after (const_iterator pos
, CXXO_FWD_REF(Arg1) a1, CXXO_FWD_REF(Arg2) a2, CXXO_FWD_REF(Arg3) a3, CXXO_FWD_REF(Arg4) a4) {
    node_t *p = pos.cur;
    //assert (p != &_head && "list::insert_after can not use _head node");
    nodeT_t *n= std::allocator_traits<node_alloc_t>::allocate(alloc,1) /*new nodeT_t(t)*/;
    ::new (&n->value) T(a1,a2,a3,a4);
    this->in_link_after(p, n);
    return iterator(n);
}

template <typename T, typename A>
template <typename Arg1, typename Arg2, typename Arg3, typename Arg4, typename Arg5>
typename forward_list<T,A>::iterator forward_list<T,A>::emplace_after (const_iterator pos
, CXXO_FWD_REF(Arg1) a1, CXXO_FWD_REF(Arg2) a2, CXXO_FWD_REF(Arg3) a3, CXXO_FWD_REF(Arg4) a4, CXXO_FWD_REF(Arg5) a5) {
    node_t *p = pos.cur;
    //assert (p != &_head && "list::insert_after can not use _head node");
    nodeT_t *n= std::allocator_traits<node_alloc_t>::allocate(alloc,1) /*new nodeT_t(t)*/;
    ::new (&n->value) T(a1,a2,a3,a4,a5);
    this->in_link_after(p, n);
    return iterator(n);
}

#endif

#else
template <typename T, typename A>
template <typename... Args>
typename forward_list<T,A>::iterator forward_list<T,A>::emplace_after (const_iterator pos, Args&&... a) {
    node_t *p = pos.N;
    //assert (p != &_head && "list::insert_after can not use _head node");
    nodeT_t *n= std::allocator_traits<node_alloc_t>::allocate(alloc,1) /*new nodeT_t(t)*/;
    ::new (&n->value) T(std::forward<Args>(a)...);
    this->in_link_after(p, n);
    return iterator(n);
}

template <typename T, typename A>
template <typename... Args>
typename forward_list<T,A>::iterator forward_list<T,A>::emplace_back (Args&&... a) {
    nodeT_t *n= std::allocator_traits<node_alloc_t>::allocate(alloc,1) /*new nodeT_t(t)*/;
    ::new (&n->value) T(std::forward<Args>(a)...);
    this->in_link_after(_end, n);
    return iterator(n);
}

template <typename T, typename A>
template <typename... Args>
typename forward_list<T,A>::iterator forward_list<T,A>::emplace_front (Args&&... a) {
    nodeT_t *n= std::allocator_traits<node_alloc_t>::allocate(alloc,1) /*new nodeT_t(t)*/;
    ::new (&n->value) T(std::forward<Args>(a)...);
    this->in_link_after(0, n);
    return iterator(n);
}

#endif

//
// erase_after
//

// TBD: check for update of last node
template <typename T, typename A>
typename forward_list<T,A>::iterator 
forward_list<T,A>::erase_after (typename forward_list<T,A>::const_iterator pr) {
    iterator ret(begin());
    if (empty()) {
        return end();
    } else {
        LDEBUG("erase_after - begin");
        node_t * p= pr.cur;
        node_t * n= this->in_unlink_after(p);
        if (n)  {
            this->in_destroy(N(n));
        }
        ret= iterator(pr.cur,&_p_last);
        ++ret;
        LDEBUG("erase_after - done");
        return ret;
    }
}

#if 0
template <typename T, typename A>
typename forward_list<T,A>::iterator 
forward_list<T,A>::erase (typename forward_list<T,A>::const_iterator n) {
    iterator ret;
    if (n == end()) ret= end(); // nothing to remove after
    else {
        // make a pointer pr that gets the node that points to n
        node_t prb(0); prb.next= _head;
        node_t * pr= &prb;
        while (pr != _end && pr->next != n.cur) { pr= pr->next; }
        node_t * n= this->in_unlink_after(pr);
        if (n == nullptr) {
            ret= end();
        } else {
            ret= N(n->next);
            // destroy the node n
            this->in_destroy(N(n));
        }
    }
    return ret;
}
#endif

template <typename T, typename A> inline
void forward_list<T,A>::clear () {
    while (!empty()) pop_front();
}

template <typename T, typename A> inline
void forward_list<T,A>::swap (forward_list<T,A>& other) {
    using std::swap;
    swap(_p_bb, other._p_bb);
    swap(_p_last, other._p_last);
    swap( alloc, other.alloc);
}


#if 0
template <typename T, typename A>
template <typename Compare>
void forward_list<T,A>::sort (Compare c) {
    LDEBUG("sort - begin for H&"<< (void*)this);
    if (empty()) return;
    forward_list<T,A> temp;
    // we use insertion sort on the node pointers
    using std::max_element;
    using std::swap;
    nodeT_t *oldh= N(_p_last->next), *oldl= N(_p_last);
    node_t new_head(0);
    node_t orig_before_head(0);
    orig_before_head.next= _p_bb.next;
    LDEBUG("sort -sorting H&"<< (void*)this);

    const_iterator it= begin(), fin= end(), pivot= ++begin();
    size_type i=1;
    while (it != fin) {
        it= this->begin();
        fin= this->cend();
        LDEBUG("sort - pass "<< i++);
        // find the max_element mc
        const_iterator mc= max_element(it, fin, c);
        if (mc==fin) break;
        // find the node pr anterior to its node mn
        node_t *mn= mc.cur;
        node_t *pr= &_p_bb; 
        while (pr && pr->next != mn) { pr= pr->next; }
        LDEBUG("sort - unlink "<< static_cast<void*>(mn)<< " with value "<< N(mn)->value);
        // use pr to unlink mn and add it to new_head by front
        this->in_unlink_after(pr);
        LDEBUG("sort - relink "<< static_cast<void*>(mn)<< " to T&"<< (void*)&temp);
        temp.in_link_after(&temp._p_bb,mn);
        LDEBUG("sort - re-iterate");
    }
    this->swap(temp);
    //_head= N(new_head.next);
    LDEBUG("sort - done for H&"<< (void*)this);
}

template <typename T, typename A>
void forward_list<T,A>::sort () {
    std::less<T> compare;
    this->sort(compare);
}

#endif


/*
 * remove, remove_if
 */


template <typename T, typename A>
template <typename Condition>
void forward_list<T,A>::remove_if (Condition c) {
    if (empty()) return;
    node_t  *x= _p_bb.next;
    while ( x->next ) {
        if ( c(N(x->next)->value) ) {
            nodeT_t *t = N(in_unlink_after(x));
            if (t) in_destroy(t);
        }
        x= x->next;
    }
}

template <typename T, typename A>
void forward_list<T,A>::remove (T const& t) {
    using namespace std;
    //const std::equal_to<T> eq;
    remove ( bind(equal_to<T>(), placeholders::_1, t) );
}

/*
template <typename T, typename A>
template<typename Comparison>
void forward_list<T,A>::unique (Comparison p) {
    // No need to unique a list with at most one element
    if (empty() or _p_bb.next->next==nullptr) return;
 
    nodeT_t *xn=_p_bb.next->next, cur=_p_bb.next;
    while (xn != nullptr) {
        cur= xn;
        xn= xn->next;
    }
    while (++first != last) {
        if (!p(*result, *first) && ++result != first) {
            *result = std::move(*first);
        }
    }
    return ++result;
}
*/


//
// -- private assist section
//

template <typename T, typename A>
void forward_list<T,A>::in_readjust_last() {
    if (empty()) { 
        _p_last= nullptr;
    } else {
        node_t *x = _p_bb.next;
        while (x->next) x=x->next;
        _p_last= x;
    }
    
}

template <typename T, typename A>
template <typename Iter>
void forward_list<T,A>::in_uninitialized_copy(Iter ini, Iter fin) {
    LDEBUG("in_uninitialized_copy - called");
    nodeT_t *n, *ant= 0, *pri=0;
    for (; ini != fin; ++ini) {
        n= detail_fwlist::alloc_new(alloc);
        if (!pri) pri= n;
        ::new (&n->value) T(*ini);
        if (!ant) {
            ant= n;
        } else {
            ant->next= n;
        }
        ant= n;
    }
    // at this point, 'n' is the last element
    _p_bb.next= pri;
    _p_last= n;
    n->next= nullptr;
    LDEBUG("in_uninitialized_copy -done");
}


template <typename T, typename A>
void forward_list<T,A>::in_uninitialized_fill_n (size_t count, T const& t) {
    LDEBUG("in_uninitialized_fill - called");
    nodeT_t *n, *ant= 0, *pri=0;
    while (count --> 0) {
        //LDEBUG("in_uninitialized_copy - allocating room for "<< *ini);
        n= detail_fwlist::alloc_new(alloc);
        if (!pri) pri= n;
        ::new (&n->value) T(t);
        if (!ant) {
            ant= n;
        } else {
            ant->next= n;
        }
        ant= n;
    }
    // at this point, 'n' is the last element
    _p_bb.next= pri;
    _p_last= n;
    n->next= nullptr;
    LDEBUG("in_uninitialized_fill -done");
}

template <typename T, typename A>
void forward_list<T,A>::in_link_after (node_t * const pre, node_t *n) {
    // list is ....-> pre -> s
    // list becomes ....-> pre -> n -> s
    n->next= pre->next;
    if (pre==_p_last) n=_p_last;
    pre->next= n;

}

// Unlinks node pr->next from the list and return it as ret
template <typename T, typename A>
typename forward_list<T,A>::node_t * forward_list<T,A>::in_unlink_after (node_t *pr) {
    // list is ...-> pr -> u -> s
    // list becomes ...-> pr -> s
    // if pre is last-sentry, we do nothing
    // if pre is before_begin, we want to unlink from the front
    if (empty()) {
        return nullptr;
    }
    
    node_t *ret= pr->next;
    // actual node exists beyond pr
    if (!ret) { return ret; }
    if (pr==&_p_bb) {
        _p_bb.next= (_p_bb.next ? _p_bb.next->next : nullptr);
    } else {
        // list is last -> 1 -> 2 -> ... -> pr -> u -> s ->
        if (pr->next) pr->next= pr->next->next;
    }
    ret->next= nullptr; // remove dangling link
    return ret;
}

template <typename T, typename A> inline
typename forward_list<T,A>::node_t* forward_list<T,A>::in_destroy (nodeT_t *p) {
    if (!p) return p;
    (p->value).~T();
    alloc_traits::deallocate(alloc,p,1);
    return p;
}


template <typename T1, typename A1, typename T2, typename A2>
inline bool operator== (forward_list<T1,A1> const& a, forward_list<T2,A2> const& b) {
    using std::equal;
    return a.size() == b.size() ? equal(a.begin(), a.end(), b.begin()) : false;
}

template <typename T1, typename A1, typename T2, typename A2>
inline bool operator!= (forward_list<T1,A1> const& a, forward_list<T2,A2> const& b) {
    return !(a==b);
}

} // cxxomfort

#undef LDEBUG

#endif 
